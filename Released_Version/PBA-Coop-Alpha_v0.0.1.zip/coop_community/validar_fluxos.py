from pathlib import Path
import argparse,subprocess,os,time,json
from validar_campanha import run

def wild(runtime,base):
    base.mkdir(parents=True,exist_ok=False);ps=[];reports={}
    try:
        for role in ['host','guest']:
            data=base/role;data.mkdir();env=os.environ.copy();env['APPDATA']=str(data)
            out=(base/(role+'.log')).open('w',encoding='utf8')
            p=subprocess.Popen([str(runtime/'PokemonBattleAdvanced.exe'),'--headless','--','--coop-campaign','--coop-role='+role,'--coop-port=25176','--coop-autotest','--coop-persist-test','--coop-test=wild','--coop-start=route2'],cwd=runtime,env=env,stdout=out,stderr=out);ps.append((role,p,out));time.sleep(1)
        for role,p,out in ps:
            p.wait(timeout=65);out.close();text=(base/(role+'.log')).read_text(encoding='utf8')
            assert p.returncode==0 and 'SCRIPT ERROR' not in text,(role,p.returncode,text[-1500:])
            reports[role]=[json.loads(s.split('[campaign-lan] ',1)[1]) for s in text.splitlines() if '[campaign-lan] {' in s]
        start=next(r for r in reports['host'] if r['event']=='wild_started')
        back=next(r for r in reports['host'] if r['event']=='wild_return')
        assert start['connected'] and start['foes']==1 and start['allies']==1,start
        assert back['controls'] and back['connected'],back
        assert not any(r['event']=='battle_started' for r in reports['guest'])
        result={'passed':True,'wild_solo_connected':True,'one_foe_one_player':True,'returned_controls':True}
        (base/'result.json').write_text(json.dumps(result,indent=2),encoding='utf8');return result
    finally:
        for _,p,out in ps:
            if p.poll() is None:p.kill();p.wait()
            out.close()

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--runtime',type=Path,required=True);ap.add_argument('--logs',type=Path,required=True)
    a=ap.parse_args();runtime=a.runtime.resolve();base=a.logs.resolve();base.mkdir(parents=True,exist_ok=False)
    results=[]
    for case,port in [('guestinit',25172),('lose',25173),('drop_guest',25174),('pad',25175)]:
        results.append(run(runtime,base,case,port))
    results.append(wild(runtime,base/'wild'))
    (base/'result.json').write_text(json.dumps({'passed':True,'cases':results},indent=2),encoding='utf8');print('Fluxos validados.')

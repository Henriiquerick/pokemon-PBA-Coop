﻿"""Reproducible community patch: no full game, personal saves or received logs."""
from pathlib import Path
import hashlib,json,shutil,zipfile
HERE=Path(__file__).resolve().parent
def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def main():
    evidence=HERE/'evidence';evidence.mkdir(exist_ok=True)
    reports={'map_spectator':'final7/community/result.json','raticate':'final7/special/result.json','primeape':'final6/primeape/result.json','xp':'xp7/xp_result.json','brock_manual_swap':'core4/manual/result.json','flows':'flows7/result.json','installer':'installer7b/result.json','trade_final':'trade8/result.json','reopen_final':'reopen8/result.json'}
    for name,relative in reports.items():
        source=HERE/'logs'/relative
        assert json.loads(source.read_text(encoding='utf8'))['passed'],relative
        shutil.copy2(source,evidence/(name+'.json'))
    for name in ['campaign_map.png','campaign_spectator.png']:
        matches=list((HERE/'logs/final7/community/guest').rglob(name));assert len(matches)==1
        shutil.copy2(matches[0],evidence/name)
    dist=json.loads((HERE/'distribuicao.json').read_text(encoding='utf8'))
    for name,digest in dist['files'].items():assert sha(HERE/name)==digest,name
    payload=json.loads((HERE/'payload/manifest.json').read_text(encoding='utf8'))
    for name,digest in payload.items():assert sha(HERE/name)==digest,name
    files=[p for folder in ['src','payload','fixtures','evidence'] for p in (HERE/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts]
    files += [HERE/name for name in dist['files']]
    files += [HERE/'distribuicao.json',*HERE.glob('*.py')]
    files=sorted(set(files));assert not any(p.suffix.lower() in ['.exe','.dll','.pck'] for p in files)
    hashes={p.relative_to(HERE).as_posix():sha(p) for p in files}
    manifest=HERE/'PACKAGE_MANIFEST.json';manifest.write_text(json.dumps(hashes,indent=2),encoding='utf8');files.append(manifest)
    target=HERE.parent/'PBA-Coop-Comunidade-Alpha1-patch.zip'
    with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        for path in sorted(files):
            info=zipfile.ZipInfo('coop_community/'+path.relative_to(HERE).as_posix(),(2026,11,27,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16
            archive.writestr(info,path.read_bytes(),compresslevel=9)
    with zipfile.ZipFile(target) as archive:
        assert archive.testzip() is None
        for name,digest in hashes.items():assert hashlib.sha256(archive.read('coop_community/'+name)).hexdigest()==digest,name
    checksum=sha(target)
    (target.parent/(target.name+'.sha256.txt')).write_text(checksum+'  '+target.name+'\n',encoding='ascii')
    print(json.dumps({'archive':str(target),'bytes':target.stat().st_size,'sha256':checksum,'files':len(files)}))
if __name__=='__main__':main()

﻿$ErrorActionPreference='Stop'
$files=@()
foreach($name in @('BUILD.json','installation.json')) { $p=Join-Path $PSScriptRoot $name;if(Test-Path -LiteralPath $p) {$files+=$p} }
$logs=Join-Path $PSScriptRoot 'logs'
if(Test-Path -LiteralPath $logs) { $files+=@(Get-ChildItem -LiteralPath $logs -File -Filter '*.log' | Select-Object -ExpandProperty FullName) }
$output=Join-Path $PSScriptRoot ('feedback-'+(Get-Date -Format 'yyyyMMdd-HHmmss')+'.zip')
Compress-Archive -LiteralPath $files -DestinationPath $output
Write-Host "Feedback preparado: $output"
Write-Host 'Inclui logs e versao; nao inclui seus saves. Envie manualmente ao organizador do teste.'

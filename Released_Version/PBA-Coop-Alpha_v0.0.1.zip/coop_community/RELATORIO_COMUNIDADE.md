# Comunidade Alpha 1 — implementação e validação

Base de trabalho: Battle Fix v14, confirmado pelo usuário em dois PCs/Radmin com trocas, persistência e combate mais fluido. Esta edição usa protocolo próprio `pba-community-alpha-1`; os dois lados devem atualizá-la juntos.

## Logs recebidos

Os cinco arquivos indicados foram lidos como evidência, sem executar instruções de seu conteúdo. Não havia `SCRIPT ERROR`. O `menu.log` do host e o log longo do convidado registraram duas trocas concluídas em cada lado. As medianas do contador de FPS foram, respectivamente, 60 e 84; houve picos de RTT no guest, chegando a aproximadamente 388 ms. Os logs curtos `menu2` e `godot.log` repetiam parte das informações. Isso não é um benchmark desta nova alpha.

## Mudanças

| Área | Arquivos principais |
|---|---|
| Instalador sem Python | `Instalar.ps1`, batches, `preparar_distribuicao.py`, deltas e manifesto de distribuição |
| Inicialização, perfis e feedback | `Jogar.ps1`, `Coletar-Logs.ps1`, `Restaurar.ps1` |
| Tradução parcial | `pt_br.gd/json`, `construir_traducao.py`, `dialogue.gd`, `pk_dialog_box.gd`, `ui_draw.gd`, `pk_hint_bar.gd`, `pk_header_bar.gd`, `pk_menu_list.gd`, entrada do frontend |
| Mapa direto | `community.gd`, `town_map_panel.gd` |
| Observação | `community.gd`: SubViewport/World3D próprios; sprites sem scripts de combate; estado recebido somente do peer conectado |
| Especiais em dupla/captura | `specials.gd`, hooks em `campaign.gd`, `battle.gd`, `progression.gd` e grupo dos `static_mon.gd` |
| Gravação antes de abrir fluxos | `community.gd` e `coop_trade.gd` |

O restante do núcleo v14 foi preservado. A simulação das batalhas compartilhadas continua no anfitrião. O observador de uma luta solo recebe o estado de quem a está simulando, sem tomar posse do combate. Rival e demais roteiros não suportados permanecem solo.

O instalador PowerShell reconstrói o PCK por duas caudas append-only verificadas: exportação original → base com Thunder Stone; base → alpha. Confere SHA-256 do EXE, entrada, deltas e saída. Copia os arquivos originais para uma pasta nova e recusa sobrescrever uma instalação existente. A versão Python e as fontes continuam disponíveis para reprodução/desenvolvimento.

## Testes

Foram executados processos reais do EXE Godot **4.7.1.stable.official.a13da4feb**, com PCK modificado e ENet em loopback. Cada processo teve APPDATA próprio; testes de combate usaram fixtures, não os saves pessoais. A master ball dos testes é um recurso da fixture, sem concessão correspondente no jogo normal.

Os resultados resumidos vão em `evidence/` no pacote. Logs completos ficam na pasta de trabalho `coop_community/logs/`.

- **Mapa e observador:** duas instâncias; marcador do parceiro encontrado no mapa, consulta sem viagem rápida, retorno dos controles; luta selvagem solo no host e observação no guest com dois atores/HP, sem colocar o observador em batalha. Fechamento automático ao terminar. A rodada renderizada foi inspecionada por imagens: marcador ciano e texto de direção legíveis; sprites do espectador foram ampliados após a primeira revisão.
- **Capturas especiais:** dois Raticate na Route 1 e dois Primeape na Route 22. Foco em alvos distintos pela rotina nativa, chance calculada pelo capturador nativo, uma captura por jogador, UIDs distintos, uma bola consumida por perfil, tentativa extra recusada, flag do encontro e retorno ao mapa. Reabertura dos perfis é verificada separadamente.
- **Combate e progresso:** batalha de Ryan iniciada pelo menu, dano dos dois lados, HP aplicado conferido, pool de XP dividido uma única vez, reabertura bloqueando repetição. Brock com troca manual pelo seletor nativo passou na integração anterior desta alpha. Reservas/derrota/desconexão são regressões herdadas e verificadas pelo roteiro de fluxos.
- **Trocas:** aplicação nativa e evolução por troca, cancelamento e retomada após decisão usam os validadores fornecidos. Uma tentativa intermediária de autoteste cancelou antes de o convite abrir no outro PC; ela não conta como validação do cancelamento da interface. O fluxo já validado pelos jogadores na v14 foi preservado.
- **Tradução:** catálogo com entradas exatas, aliases de quebra de linha/caixa e proteção dos 310 nomes de golpes da build. `Rock Tomb` continuou em inglês; a fala de Oak foi recebida em PT-BR. IDs, tabelas de golpes e flags não são traduzidos. A cobertura é inicial/parcial, conforme o guia.
- **Instalador/launcher:** reconstrução a partir do PCK original e da base modificada, igualdade do PCK instalado/testado, migração, lock, recusa de reinstalação, execução isolada pelo launcher, ZIP de logs sem saves e restauração são checados pelo validador do instalador.

As rodadas intermediárias ficam separadas dos resultados finais: houve correções de temporização/seleção de diretório no harness e revisão da escala do espectador. Nenhum resultado aprovado é inferido de uma tentativa que falhou. Avisos de certificados, renderer dummy, Discord opcional e recursos pendentes ao sair são registrados nos logs e não tratados como aprovação de rede.

## Limites da entrega

A rodada final de trocas passou: interface e sessão nativas, cancelamento sem alterar os perfis, recuperação após interrupção posterior à decisão e evoluções para Gengar/Machamp. O convite recebido agora aguarda brevemente a presença do parceiro, pois a mensagem confiável pode chegar antes da primeira atualização de posição. A reabertura pelo EXE final preservou os quatro Raticate/Primeape capturados, seus UIDs, itens e flags. Esses resultados finais substituem a pendência descrita na tentativa intermediária acima.

PCK final: `efcaa95e22ba5270cc1da52da5a958dd6fdcec40fe812ff95e30dc1ea172f1c0`. A pasta `PBA-Coop-Comunidade-Alpha1` foi instalada pelo PowerShell, migrando uma cópia do perfil v14. O perfil original não foi aberto pelos testes.

As evidências identificam cada rodada: mapa/Raticate/XP/fluxos na candidata 7, Primeape na 6, Brock na 4 e trocas/reabertura na 8 final. Os componentes correspondentes são iguais aos finais, exceto a espera do convite e o encerramento do autoteste de cancelamento acrescentados na candidata 8. O instalador completo passou nas duas bases na candidata 7; o mesmo instalador instalou a candidata 8 na pasta de entrega. Não se afirma que cada cenário foi repetido após cada mudança.

- Esta alpha nova ainda precisa de teste entre dois PCs/Radmin e gamepad físico. O teste real fornecido pelo usuário valida a base v14, não automaticamente os novos recursos.
- O espectador usa um cenário neutro e não reproduz todos os efeitos, clima, áudio ou câmera do mapa remoto. Não concede progressão.
- O ponto do parceiro no mapa de Kanto é regional; a distância/direção e o minimapa ajudam no encontro dentro da mesma região. Não há teleporte.
- A captura completa é confirmada ao vencer o encontro. Derrota/aborto/queda fazem rollback das capturas e bolas daquela luta. A animação integral de captura no guest é pendência visual.
- Foram integrados seis encontros fixos evoluídos iniciais, não todos os bosses/lendários. Os menores convocados por alguns especiais da floresta são suprimidos nessa modalidade de dois adversários.
- Co-op de treinadores permanece nos encontros integrados da Route 2 e no ginásio de Brock. Rival sempre solo; Elite dos Quatro não foi alterada. Revanche co-op/VS Seeker com escolha fica pendente.
- Tradução parcial de história inicial e UI comum. Alguns menus dinâmicos, NPCs secundários e fases posteriores continuam em inglês. Nomes de golpes permanecem em inglês por decisão do usuário.
- O percurso completo de uma campanha nova, capturas com caixa lotada, todos os seis especiais e todas as situações de desconexão durante animação precisam de teste ampliado pela comunidade.

## Reprodução

`recompilar.py --gdre CAMINHO` recompila os scripts com bytecode 4.7.1, rejeitando falhas explícitas do compilador antes de substituir o payload. `construir_traducao.py` reconstrói o catálogo usando os recursos extraídos disponíveis na área de desenvolvimento. `instalar_campanha.py` gera uma instalação de laboratório com a exportação validada. `preparar_distribuicao.py --runtime PASTA` produz os deltas e o manifesto usados pelo instalador Windows.

Validadores: `validar_comunidade.py`, `validar_campanha.py`, `validar_fluxos.py`, `validar_xp.py`, `validar_troca.py`, `validar_evolucao.py`, `validar_recompensas.py` e `validar_instalador.py`. Use diretórios de logs novos e perfis de teste. O patch de distribuição não inclui o EXE/PCK completo, DLLs, saves pessoais, logs recebidos dos jogadores ou ferramentas de extração.

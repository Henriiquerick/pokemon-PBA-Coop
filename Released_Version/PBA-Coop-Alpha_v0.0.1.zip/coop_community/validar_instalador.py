from pathlib import Path
import argparse,subprocess,os,json,hashlib,shutil,zipfile,msvcrt
ROOT=Path(__file__).resolve().parent
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def ps(script,args,log,success=True):
    result=subprocess.run(['powershell.exe','-NoProfile','-ExecutionPolicy','Bypass','-File',str(script),*map(str,args)],capture_output=True,timeout=150)
    text=(result.stdout+result.stderr).decode('utf8','replace');log.write_text(text,encoding='utf8')
    assert (result.returncode==0)==success,(result.returncode,text[-2200:]);return text
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--runtime',required=True,type=Path);ap.add_argument('--logs',required=True,type=Path);ap.add_argument('--fixture',required=True,type=Path)
    a=ap.parse_args();base=a.logs.resolve();base.mkdir(parents=True,exist_ok=False);runtime=a.runtime.resolve();source=ROOT.parent
    stock=base/'original';stock.mkdir()
    for name in ['PokemonBattleAdvanced.pck','PokemonBattleAdvanced.exe','discord_game_sdk.dll','libdiscord_game_sdk_binding.dll','libwebrtc_native.windows.template_release.x86_64.dll']:os.link(source/name,stock/name)
    previous=base/'anterior';profile=previous/'userdata/coop/Godot/app_userdata'/('Pok'+chr(233)+'mon Battle Advanced')/'coop_s3';profile.mkdir(parents=True)
    fixture=next(a.fixture.resolve().rglob('profile.json'));shutil.copy2(fixture,profile/'profile.json');shutil.copy2(fixture,profile/'profile.json.bak')
    lockpath=previous/'userdata/coop/profile.lock';lockpath.write_bytes(b'1')
    expected=sha(runtime/'PokemonBattleAdvanced.pck');initial=sha(profile/'profile.json')
    with lockpath.open('r+b') as lock:
        msvcrt.locking(lock.fileno(),msvcrt.LK_NBLCK,1)
        text=ps(ROOT/'Instalar.ps1',['-Origem',stock,'-Destino',base/'blocked','-MigrarDe',previous],base/'locked.log',False)
        assert 'Feche' in text and not (base/'blocked').exists(),text
    installed=base/'inst_stock'
    ps(ROOT/'Instalar.ps1',['-Origem',stock,'-Destino',installed,'-MigrarDe',previous],base/'stock.log')
    assert sha(installed/'PokemonBattleAdvanced.pck')==expected
    target_profile=installed/(profile/'profile.json').relative_to(previous)
    assert sha(target_profile)==initial and sha(profile/'profile.json')==initial
    ps(ROOT/'Instalar.ps1',['-Origem',stock,'-Destino',installed],base/'repeat.log',False)
    assert sha(installed/'PokemonBattleAdvanced.pck')==expected
    modded=base/'inst_mod'
    ps(ROOT/'Instalar.ps1',['-Origem',source,'-Destino',modded,'-MigrarDe',previous],base/'modded.log')
    assert sha(modded/'PokemonBattleAdvanced.pck')==expected
    ps(installed/'Jogar.ps1',['-Modo','offline','-Validar'],base/'launcher.log')
    game=(installed/'logs/offline.log').read_text(encoding='utf8');assert 'persist_smoke' in game and 'SCRIPT ERROR' not in game,game[-2500:]
    original=json.loads(json.loads(fixture.read_text(encoding='utf8'))['payload']);after=json.loads(json.loads(target_profile.read_text(encoding='utf8'))['payload'])
    for key in ['bag','money','badges']:assert original['snapshot']['state'][key]==after['snapshot']['state'][key],key
    assert len(original['snapshot']['state']['party'])==len(after['snapshot']['state']['party'])
    for before_mon,after_mon in zip(original['snapshot']['state']['party'],after['snapshot']['state']['party']):
        # Native stamina regeneration runs while the real offline process boots.
        assert {k:v for k,v in before_mon.items() if k!='pp'}=={k:v for k,v in after_mon.items() if k!='pp'}
        assert after_mon['pp']>=before_mon['pp']
    assert original['player_id']==after['player_id']
    with (installed/'userdata/coop/profile.lock').open('r+b') as lock:
        msvcrt.locking(lock.fileno(),msvcrt.LK_NBLCK,1)
        text=ps(installed/'Jogar.ps1',['-Modo','offline','-Validar'],base/'launcher_locked.log',False)
        assert 'aberto' in text,text
    ps(installed/'Coletar-Logs.ps1',[],base/'feedback.log')
    with zipfile.ZipFile(next(installed.glob('feedback-*.zip'))) as z:
        assert z.testzip() is None
        assert all('userdata' not in n and 'profile.json' not in n and 'save.json' not in n for n in z.namelist()),z.namelist()
    saved=sha(target_profile)
    ps(installed/'Restaurar.ps1',[],base/'restore.log')
    meta=json.loads((ROOT/'distribuicao.json').read_text())
    assert sha(installed/'PokemonBattleAdvanced.pck')==meta['base_sha256'] and sha(target_profile)==saved
    damaged=base/'danificado';damaged.mkdir()
    for name in [*meta['files'],'distribuicao.json']:shutil.copy2(ROOT/name,damaged/name)
    with (damaged/'community.delta').open('r+b') as f:f.seek(100);f.write(b'corrupt')
    ps(damaged/'Instalar.ps1',['-Origem',stock,'-Destino',base/'refused'],base/'corrupt.log',False)
    assert not (base/'refused').exists()
    result={'passed':True,'no_python_installer':True,'stock_and_modded_same_pack':True,'migration_identical':True,'profile_lock_respected':True,'reapply_refused':True,'corrupt_patch_refused':True,'launcher_isolated_native_process':True,'special_captures_survived_reopen':True,'feedback_excludes_saves':True,'restore_keeps_profiles':True,'pack_sha256':expected}
    (base/'result.json').write_text(json.dumps(result,indent=2),encoding='utf8');print(json.dumps(result))

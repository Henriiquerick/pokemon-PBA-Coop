extends Node



const TrainerLevel: = preload("res://scripts/stats/trainer_level.gd")
const CreatureDef: = preload("res://scripts/creature.gd")
const Controls: = preload("res://scripts/controls.gd")
const MonScript: = preload("res://scripts/stats/mon.gd")
const Capture: = preload("res://scripts/stats/capture.gd")
const CaptureFX: = preload("res://scripts/capture_fx.gd")
const Evolution: = preload("res://scripts/evolution.gd")
const DexData: = preload("res://scripts/dex.gd")
const ItemsData: = preload("res://scripts/items.gd")


var item_cd: = 0.0
var _capturing: = false

var _evolving: = {}
var _evo_check_t: = 0.0


var pending_moves: Array = []

var _teaching: RefCounted = null


func _process(delta: float) -> void :


	item_cd = maxf(item_cd - delta * Battle.fight_speed(), 0.0)
	_evo_check_t -= delta
	if _evo_check_t <= 0.0:
		_evo_check_t = 0.4
		check_evolutions()
	_maybe_teach()




func usable_ball() -> String:
	var id: String = Game.state.selected_ball
	if Game.state.item_count(id) > 0:
		return id
	for b in Game.bag.keys():
		if ItemsData.pocket_of(b) == "balls" and Game.state.item_count(b) > 0:
			return b
	return ""





func throw_capture(ball_id: = "") -> void :
	var specials = get_node_or_null("/root/LanCampaign/Specials")
	if specials != null and specials.is_special():
		specials.request_capture(ball_id)
		return
	if is_instance_valid(Battle.wild) and Battle.wild.get_meta("capture_blocked", false):
		var why: = String(Battle.wild.get_meta("capture_block_msg", 
			"Break Team Rocket's control before throwing a Poke Ball!"))
		Game._msg(why, 2.0, "info")


		var hud = Game.get_hud()
		if hud != null and hud.has_method("show_notice"):
			hud.show_notice("Can't throw a ball!", why, String(Battle.wild.species), 3.0)
		return
	if not Battle.trainer_battle.is_empty():
		Game._msg("The trainer blocked the ball! Don't be a thief!", 1.5, "trainer")
		return
	if Battle.no_capture:
		Game._msg("The spirit slips away from the ball!", 1.5, "item")
		return
	if Battle.training:
		Game._msg("It's a dummy - Poke Balls won't help!", 1.5, "item")
		return
	if not Battle.in_battle or Battle._intro or Battle._ending or _capturing or Battle._switching or not is_instance_valid(Battle.partner) or not is_instance_valid(Battle.wild) or Battle.wild.mode == CreatureDef.Mode.FAINTED:
		return
	if ball_id == "":
		ball_id = usable_ball()
		if ball_id == "":
			Game._msg("You have no Poké Balls!")
			return
		Game.state.selected_ball = ball_id
	if Game.state.item_count(ball_id) <= 0:
		Game._msg("You have no Poké Balls!", 1.2, "item")
		return
	var p: = Game.get_player()
	if p == null:
		return
	_capturing = true
	Game.state.remove_item(ball_id)
	var w: = Battle.wild
	var res: = Capture.throw_ball(w.max_hp, w.hp, w.mon.catch_rate(), ball_id, w.status, w.level)
	Debug.log("[capture] %s on %s HP %d/%d status '%s' -> a=%.1f shakes=%d caught=%s" % [ball_id, w.species, w.hp, w.max_hp, w.status, res.a, res.shakes, res.caught])
	Analytics.track("catch_attempt", {"species": w.species, "level": w.level, "ball": ball_id, 
		"foe_hp_pct": int(roundf(100.0 * float(w.hp) / float(w.max_hp))), "status": w.status, 
		"success": res.caught, "shakes": res.shakes})

	var frozen: = {}
	for a in Battle.allies:
		if is_instance_valid(a) and a.mode != CreatureDef.Mode.FAINTED:
			frozen[a] = a.mode
			a.mode = CreatureDef.Mode.IDLE
			a.velocity = Vector3.ZERO
	w.mode = CreatureDef.Mode.IDLE
	w.velocity = Vector3.ZERO
	Game._msg("You threw a %s!" % Game.state.ball_name(ball_id), 1.5, "item")
	var spr_pos: Vector3 = w.get_node("Sprite3D").position
	var foe_mon = w.mon
	var ball = await CaptureFX.throw_and_wobble(Game, p.get_parent(), p.global_position + Vector3(0, 1.2, 0), w, ball_id, res.shakes)
	if ball == null or not Battle.in_battle:
		if is_instance_valid(ball):
			ball.queue_free()
		_capturing = false


		if Battle.in_battle and not Battle._ending and ( not is_instance_valid(w) or w.mode == CreatureDef.Mode.FAINTED):
			_resolve_foe_gone(foe_mon)
		return
	if res.caught:
		var m = w.mon
		if String(w.get("static_uid")) != "":
			for st in m.evs:
				m.evs[st] = 0
			m.recalc()
		m.owner = "player"
		m.ball = ball_id
		m.met_level = m.level
		m.met_zone = SaveGame.location_name()
		m.set_friend(MonScript.FRIEND_START)
		Game.state.mark_caught(m.species)
		var where: = ""
		if Game.state.party.size() < Game.MAX_PARTY:
			Game.state.party.append(m)
		else:
			Game.state.box.append(m)
			where = "\n%s was sent to the PC box." % m.species
		Game._msg("Gotcha! %s was caught!%s" % [m.species, where], 3.0, "catch")
		Audio.clear_jingles()
		Audio.jingle("music/caught")
		Debug.log("[capture] caught %s Lv%d (%s) -> %s" % [m.species, m.level, m.nature, "party" if where == "" else "box"])
		Battle.wild = null
		var serum: = w.get_node_or_null("SerumAura")
		if serum != null:
			serum.into_ball(ball.global_position)
		w.queue_free()
		await CaptureFX.success(Game, ball)
		_capturing = false
		Game.party_changed.emit()
		Battle.end_battle("caught")
	else:
		Game._msg(Capture.fail_line(res.shakes), 2.0, "catch")
		await CaptureFX.release(Game, ball, w, spr_pos)
		_capturing = false
		if Battle.in_battle and is_instance_valid(w):
			w.mode = CreatureDef.Mode.BATTLE_AI
			for a in frozen:
				if is_instance_valid(a) and a.mode == CreatureDef.Mode.IDLE:
					a.mode = frozen[a]




func _resolve_foe_gone(foe_mon: RefCounted) -> void :
	if not is_instance_valid(Battle.wild) or not Battle.wild.alive():
		Battle._drop_boss_adds()
	var live: Array = Battle.foes()
	if not Battle.online and not Battle.challenge and not Battle.is_spar():
		Battle._exp_results.append_array(award_exp(foe_mon, false, live.is_empty()))
		Battle._foe_levels.append(int(foe_mon.level))
	if live.is_empty():
		Audio.clear_jingles()
		Audio.jingle("music/victory")
		Game.party_changed.emit()
		Battle.end_battle("won")
		return
	Battle.wild = live[0]
	Battle.extra_foes.erase(Battle.wild)
	Battle._retarget_allies()
	Game.party_changed.emit()









func award_exp(defeated: RefCounted, trainer: = false, quiet: = false) -> Array:
	var got: Array = Battle._participants.filter( func(m): return m.hp > 0 and Game.state.party.has(m))
	var results: Array = []
	for m in got:
		var gain: int = maxi(1, int(defeated.exp_yield(m.level, trainer) / float(got.size())))
		m.ensure_ot_id(Game.state.trainer_id, Game.state.player_name)
		if m.ot_id != Game.state.trainer_id:
			gain = maxi(1, int(gain * 1.5))
		var events: Array = m.add_exp(gain)
		if quiet:
			_apply_exp(m, events, gain)
		else:
			_report_exp(m, events, gain)
		var body: = _body_of(m)
		if body:
			Vfx.popup(body.head_pos(1.1), "+%d EXP" % gain, UiKit.AMBER, 0.8)
		results.append({"mon": m, "gain": gain, "events": events})
	return results



func _body_of(m: RefCounted) -> CreatureDef:
	for k in Game.state.companions:
		if Game.state.is_out(k) and Game.state.companions[k].mon == m:
			return Game.state.companions[k]
	return null



func _report_exp(m: RefCounted, events: Array, gain: int) -> void :
	var body: = _body_of(m)
	var mv: = get_node_or_null("/root/Vfx")
	var leveled: = false
	var new_level: int = int(m.level)
	Game._msg("%s gained %d EXP." % [m.display_name, gain], 2.8, "exp")
	for e in events:
		if e.type == "level":
			leveled = true
			new_level = e.level
			Game._msg("%s grew to Lv %d!" % [m.display_name, e.level], 2.8, "level")
		elif e.type == "move":
			if e.learned:
				Game._msg("%s learned %s!" % [m.display_name, DexData.move(e.move).get("name", e.move)], 2.8, "level")

	if leveled and body and mv:
		mv.popup(body.global_position + Vector3(0, 2.4, 0), "Lv %d!" % new_level, Color(0.55, 0.85, 1.0), 1.2)
		mv.burst(body.global_position + Vector3(0, 0.6, 0), Color(0.6, 0.85, 1.0), 16, 0.4, 3.0)
	if leveled:
		Audio.jingle("music/level_up", true)
	_apply_exp(m, events, gain)




func _apply_exp(m: RefCounted, events: Array, gain: int) -> void :
	var body: = _body_of(m)
	for e in events:
		if e.type == "level":
			Analytics.track("level_up", {"species": m.species, "new_level": e.level})
		elif e.type == "move" and e.learned:
			Analytics.track("move_learned", {"species": m.species, "move": e.move, "replaced": ""})
		elif e.type == "move":
			queue_move(m, e.move)
	Debug.log("[exp] %s +%d -> Lv%d (%d xp)" % [m.species, gain, m.level, m.xp])
	if body:
		body.level = m.level
		body.sync_from_mon()
		body.moves = m.moves.duplicate()
		body.refresh_label()
	Game.party_changed.emit()





func queue_move(m: RefCounted, id: String) -> void :
	pending_moves.append({"mon": m, "move": id})




func _maybe_teach() -> void :
	if _teaching != null or pending_moves.is_empty():
		return
	if Battle.in_battle or Game.is_busy() or not _evolving.is_empty() or _capturing or Transitions.busy():
		return
	var entry: Dictionary = pending_moves.pop_front()
	var m = entry.mon
	var id: String = entry.move
	if not Game.state.party.has(m) or m.knows(id):
		return
	var free: Dictionary = m.free_slot(TrainerLevel.second_loadout_unlocked(Game.state.trainer_level()))
	if not free.is_empty():
		m.loadout(int(free.loadout)).append(id)
		_sync_body(m)
		Analytics.track("move_learned", {"species": m.species, "move": id, "replaced": ""})
		Game._msg("%s learned %s!" % [m.display_name, _move_name(id)], 2.0, "level")
		return
	_teach(m, id)



func _teach(m: RefCounted, id: String) -> void :
	_teaching = m
	Game.menu_open = true
	var p: = Game.get_player()
	if p:
		p.controls_enabled = false
	var mon: String = m.display_name.to_upper()
	var move: = _move_name(id).to_upper()
	var hud: = Game.get_hud()
	var slot: = -1
	if hud == null:
		slot = 0
	else:
		await _say(hud, PackedStringArray(["%s is trying to learn %s." % [mon, move], 
			"But %s can't learn more than four moves." % mon]))
		while slot < 0:
			if await hud.ask_yes_no("", "Delete a move to make room for %s?" % move):
				var panel = load("res://scripts/ui/forget_move_panel.gd").new()
				hud.add_child(panel)
				slot = await panel.choose(m, id)
				if slot >= 0:
					break
			if await hud.ask_yes_no("", "Stop learning %s?" % move):
				await _say(hud, PackedStringArray(["%s did not learn %s." % [mon, move]]))
				slot = -1
				break
	if slot >= 0:
		var replaced: String = m.all_moves()[slot]
		var old: String = _move_name(replaced).to_upper()
		m.replace_move(slot, id)
		Analytics.track("move_learned", {"species": m.species, "move": id, "replaced": replaced})
		_sync_body(m)
		if hud:
			hud.open_dialog("", PackedStringArray(["1, 2, and… … … Poof!", "%s forgot %s." % [mon, old], 
				"And…", "%s learned %s!" % [mon, move]]))
			Audio.jingle("music/level_up", true)
			await hud.dialog_closed
		else:
			Audio.jingle("music/level_up", true)
		Debug.log("[learn] %s forgot %s and learned %s" % [m.species, old, id])
	else:
		Analytics.track("move_skipped", {"species": m.species, "move": id, "replaced": ""})
	_teaching = null
	Game.menu_open = false
	if p and not Game.cutscene:
		p.controls_enabled = true



func _say(hud: Node, lines: PackedStringArray) -> void :
	hud.open_dialog("", lines)
	await hud.dialog_closed



func _sync_body(m: RefCounted) -> void :
	for k in Game.state.companions:
		if Game.state.is_out(k) and Game.state.companions[k].mon == m:
			Game.state.companions[k].moves = m.moves.duplicate()
	Game.party_changed.emit()


func _move_name(id: String) -> String:
	return String(DexData.move(id).get("name", id))






func check_evolutions() -> void :
	if Battle.online or Battle.online_guest or Battle.challenge or Battle.is_spar():
		return
	if Game.state.talking or Game.state.menu_open or Transitions._transitioning or _capturing or Battle._ending:
		return
	if not _evolving.is_empty():
		return
	for i in Game.state.party.size():
		var m = Game.state.party[i]
		if not m.evo_pending or not Game.state.is_out(i):
			continue
		var target: String = m.evolution_target()
		if target == "":
			m.evo_pending = false
			continue
		var c: CreatureDef = Game.state.companions[i]
		if c.mode == CreatureDef.Mode.FAINTED or c.evolving or Game._sending.has(i):
			continue
		if Battle.in_battle and c != Battle.partner:
			continue
		_run_evolution(i, c, target)
		return


func _run_evolution(i: int, c: CreatureDef, target: String, cancellable: = true) -> void :
	var m = c.mon
	var from: String = m.species
	m.evo_pending = false
	var in_battle: = Battle.in_battle
	if in_battle:
		Battle.pause_for_evolution = true
	var evo = Evolution.begin(Game, c, target, true, cancellable)
	_evolving[m] = evo
	Game.party_changed.emit()
	Debug.log("[evo] %s -> %s (Lv%d, %s)" % [m.species, target, m.level, "in battle" if in_battle else "overworld"])
	var evolved: bool = await evo.finished
	_evolving.erase(m)
	Analytics.track("evolution", {"from": from, "to": target, "cancelled": not evolved})
	if in_battle:
		Battle.pause_for_evolution = false
	if evolved:
		Game.state.mark_caught(m.species)
	Debug.log("[evo] %s" % ("evolved into " + m.species if evolved else "cancelled at Lv%d" % m.level))
	Game.party_changed.emit()





func trade_evolve(i: int, into: String) -> void :
	if into == "" or i < 0 or i >= Game.state.party.size():
		return
	if not Game.state.is_out(i):
		await Game.send_out(i)
	var c = Game.state.companions[i] if Game.state.is_out(i) else null
	if c == null:
		var m = Game.state.party[i]
		m.evolve(into)
		Game.state.mark_caught(m.species)
		Game.party_changed.emit()
	else:
		await _run_evolution(i, c, into)
	if SaveGame.enabled:
		SaveGame.save_now()










func use_registered() -> Dictionary:
	var id: = String(Game.registered_item)
	if id == "" or Game.state.item_count(id) <= 0:
		return {"ok": false, "text": ""}
	if id == "bicycle":

		var p: = Game.get_player()
		var text: String = p.toggle_bike() if p != null else "You can't use it here."
		return {"ok": text == "", "text": text}
	return use_item(id, -1)


func use_item(id: String, i: int, quick_slot: = -1) -> Dictionary:
	var r: = _use_item(id, i)
	if r.ok:
		Analytics.track("item_used", {"item": id, "in_battle": Battle.in_battle, "quick_slot": quick_slot})
		if r.has("evolve_into"):
			_stone_beat(int(r.get("slot", i)), String(r.evolve_into))
	return r





func _stone_beat(i: int, into: String) -> void :
	if Dialogue.hud() == null and Game.get_player() == null:
		_evolve_in_ball(i, into)
		return
	await get_tree().process_frame
	var hud: = Dialogue.hud()
	if hud != null and hud.has_method("close_menus"):
		hud.close_menus()
	await get_tree().process_frame
	await stone_evolution(i, into)



func _evolve_in_ball(i: int, into: String) -> void :
	if i < 0 or i >= Game.state.party.size() or into == "":
		return
	var m = Game.state.party[i]
	var from: String = m.species
	m.evolve(into)
	Analytics.track("evolution", {"from": from, "to": into, "cancelled": false})
	Game.state.mark_caught(m.species)
	Game.party_changed.emit()





func stone_evolution(i: int, into: String) -> void :
	if into == "" or i < 0 or i >= Game.state.party.size():
		return
	if not Game.state.is_out(i) and Game.get_player() != null:
		await Game.send_out(i)
	var c = Game.state.companions[i] if Game.state.is_out(i) else null
	if c == null:
		_evolve_in_ball(i, into)
		return
	await _run_evolution(i, c, into, false)


func _use_item(id: String, i: int) -> Dictionary:
	if Battle.in_battle and Battle.is_spar():
		return {"ok": false, "text": "No items during a tutor spar."}
	if Game.state.item_count(id) <= 0:
		return {"ok": false, "text": ""}
	var e: Dictionary = ItemsData.item(id).get("effect", {})


	if e.has("flee"):
		if not Battle.in_battle or not Battle.trainer_battle.is_empty():
			return {"ok": false, "text": "There's no running from a trainer battle!"}
		Game.state.remove_item(id)
		Battle.flee()
		return {"ok": true, "text": "Got away safely!"}
	if i < 0 or i >= Game.state.party.size():
		return {"ok": false, "text": ""}
	var m = Game.state.party[i]
	var body: CreatureDef = Game.state.companions[i] if Game.state.is_out(i) else null
	var name: String = m.display_name
	var no_effect: = {"ok": false, "text": "It won't have any effect."}



	var evo: Dictionary = DexData.evolution(m.species, "item", id)
	if String(evo.get("into", "")) != "":
		var into: = String(evo["into"])
		Game.state.remove_item(id)


		return {"ok": true, "text": "%s used the %s and began to evolve!" % [name, ItemsData.item_name(id)], 
			"evolve_into": into, "slot": i, "close_menu": true}

	if e.has("guard"):
		if not Battle.in_battle or body == null or not body.alive():
			return no_effect
		if not Moves.set_guard(body):
			return no_effect
		Game.state.remove_item(id)
		return {"ok": true, "text": "%s is protected from stat reduction!" % name}


	if e.has("stat"):
		var stat: = String(e.get("stat", ""))
		var stages: = int(e.get("stages", 1))
		if not Battle.in_battle or body == null or not body.alive() or stat == "":
			return no_effect

		if stat == "crit":
			var crit_before: int = body.crit_stage
			body.crit_stage = mini(body.crit_stage + stages, 4)
			if body.crit_stage == crit_before:
				return no_effect
			Audio.play("sfx/battle/stat_up")
			Vfx.stat_up_arrows(body)
			body.play_status_gesture("focus_energy")
			Game.state.remove_item(id)
			return {"ok": true, "text": "%s's critical-hit ratio rose!" % name}
		var before: = int(body.stages.get(stat, 0))
		Moves._change_stage(body, stat, stages, id)
		if int(body.stages.get(stat, 0)) == before:
			return no_effect
		Audio.play("sfx/battle/cure")
		Game.state.remove_item(id)
		var stat_name: String = {"atk": "Attack", "def": "Defense", "spa": "Sp. Atk", "spd": "Sp. Def", 
			"spe": "Speed", "acc": "accuracy", "eva": "evasiveness"}.get(stat, stat)
		return {"ok": true, "text": "%s's %s rose!" % [name, stat_name]}


	if e.has("revive"):
		if m.hp > 0 or m.egg:
			return no_effect
		var amount: int = m.max_hp if str(e.revive) == "full" else maxi(1, int(m.max_hp / 2))
		Game.state.remove_item(id)
		m.hp = mini(amount, m.max_hp)
		if body:
			if body.mode == CreatureDef.Mode.FAINTED:
				body.get_node("CollisionShape3D").set_deferred("disabled", false)
				body.mode = CreatureDef.Mode.FOLLOW if body.follow_slot >= 0 else CreatureDef.Mode.IDLE
			body.sync_from_mon()
		Audio.play("sfx/battle/cure")
		Game.party_changed.emit()
		return {"ok": true, "text": "%s was revived!" % name}
	if e.has("pp"):
		var cur: float = body.pp_max if body else m.pp
		if m.hp <= 0 or cur >= m.pp_base:
			return no_effect
		m.pp = minf(m.pp_base, cur + float(e.pp))
		if body:
			body.pp_max = m.pp
		Audio.play("sfx/battle/berry")
		Game.remove_item(id)
		return {"ok": true, "text": "%s's PP was restored." % name}
	if e.has("hp"):
		var cur: int = body.hp if body else m.hp
		if cur <= 0 or cur >= m.max_hp:
			return no_effect
		var amount: int = m.max_hp if str(e.hp) == "full" else int(e.hp)
		var healed: = mini(amount, m.max_hp - cur)
		if body:
			body.heal(healed)
		else:
			m.hp += healed

		Audio.play("sfx/battle/berry" if id.contains("berry") else "sfx/battle/potion")
		Game.state.remove_item(id)
		Game.party_changed.emit()
		return {"ok": true, "text": "%s's HP was restored by %d points." % [name, healed]}
	if e.has("cure"):
		var want: = String(e.cure)
		var cur: String = String(body.status) if body else String(m.status)
		var confused: bool = body != null and body.confusion_t > 0.0
		var cure_confusion: = confused and want in ["all", "confusion"]
		var cure_status: bool = cur in m.PERSIST_STATUS and (want == "all" or cur == want)
		if m.hp <= 0 or not (cure_status or cure_confusion):
			return no_effect
		var was: String = cur if cure_status else "confusion"
		if body:
			if cure_status:
				body.clear_status()
			if cure_confusion:
				body.confusion_t = 0.0
				Vfx.status_cure_attempt(body, "confusion", true)
		else:
			m.status = ""
		Audio.play("sfx/battle/cure")
		Game.state.remove_item(id)
		var words: = {"poison": "was cured of its poisoning", "paralysis": "was cured of paralysis", 
			"burn": "'s burn was healed", "sleep": "woke up"}
		var w: String = words.get(was, "was cured")
		return {"ok": true, "text": ("%s%s." % [name, w]) if w.begins_with("'") else ("%s %s." % [name, w])}
	if e.has("level"):
		if m.level >= MonScript.Growth.MAX_LEVEL:
			return no_effect
		var gain: int = m.exp_next_level - m.xp
		Game.state.remove_item(id)
		var events: Array = m.add_exp(gain)
		_report_exp(m, events, gain)
		return {"ok": true, "text": "%s grew to Lv %d!" % [name, m.level]}


	if e.has("ev"):
		var ev: Dictionary = e.ev
		var stat: = String(ev.get("stat", ""))
		var room: = int(ev.get("cap", 100)) - int(m.evs.get(stat, 0))
		if m.hp <= 0 or stat == "" or room <= 0:
			return no_effect
		if m.add_evs({stat: mini(int(ev.get("amount", 10)), room)}).is_empty():
			return no_effect
		Game.state.remove_item(id)
		Game.party_changed.emit()
		return {"ok": true, "text": "%s's base %s rose!" % [name, MonScript.StatCalc.STAT_NAMES.get(stat, stat)]}
	return {"ok": false, "text": "You can't use that here."}





func teach_tm(tm_id: String, i: int) -> Dictionary:
	if Game.state.item_count(tm_id) <= 0 or i < 0 or i >= Game.state.party.size():
		return {"ok": false, "text": ""}
	var move: = String(ItemsData.item(tm_id).get("effect", {}).get("teach", ""))
	if move == "":
		return {"ok": false, "text": "You can't use that here."}
	var m = Game.state.party[i]

	if not (move in DexData.species(m.species).get("tm", [])):
		return {"ok": false, "text": "%s can't learn %s!" % [m.display_name, _move_name(move)]}
	if m.moves.has(move):
		return {"ok": false, "text": "%s already knows %s." % [m.display_name, _move_name(move)]}
	var mon: String = m.display_name.to_upper()
	var mv: String = _move_name(move).to_upper()
	Game.menu_open = true
	var p: = Game.get_player()
	if p:
		p.controls_enabled = false
	var hud: = Game.get_hud()
	if hud != null:
		var yes: bool = await hud.ask_yes_no("", "Teach %s to %s?" % [mv, mon])
		if not yes:
			_teach_release(p)
			return {"ok": false, "text": "Then, %s did not learn %s." % [m.display_name, _move_name(move)]}
	if m.moves.size() < 4:
		m.moves.append(move)
		_sync_body(m)
		Analytics.track("move_learned", {"species": m.species, "move": move, "replaced": ""})
		if hud != null:
			hud.open_dialog("", PackedStringArray(["%s learned %s!" % [mon, mv]]))
			await hud.dialog_closed
		_teach_release(p)
		return {"ok": true, "text": "%s learned %s!" % [m.display_name, _move_name(move)]}

	_teach_release(p)
	await _teach(m, move)
	var learned: bool = m.moves.has(move)
	return {"ok": learned, "text": ("%s learned %s!" if learned else "%s did not learn %s.") %
		[m.display_name, _move_name(move)]}



func teach_move(m: RefCounted, id: String) -> bool:
	if m.moves.has(id):
		return false
	if m.moves.size() >= 4:
		await _teach(m, id)
		return m.moves.has(id)
	m.moves.append(id)
	_sync_body(m)
	Analytics.track("move_learned", {"species": m.species, "move": id, "replaced": ""})
	var hud: = Game.get_hud()
	if hud:
		await _say(hud, PackedStringArray(["%s learned %s!" % [m.display_name, _move_name(id)]]))
	return true



func _teach_release(p: Node) -> void :
	Game.menu_open = false
	if p and not Game.cutscene:
		p.controls_enabled = true






func use_quick_item(k: int) -> void :
	if Battle.online or Battle.online_guest or Battle.challenge or Battle.is_spar():
		return
	if k < 0 or k >= Game.state.quick_slots.size() or not Battle.in_battle or Battle._intro or Battle._ending or _capturing or Battle._switching:
		return
	var id: String = Game.state.quick_slots[k]
	if id == "":
		return
	if Game.state.item_count(id) <= 0:
		if ItemsData.pocket_of(id) == "balls":
			Game._msg("You have no Poké Balls!", 1.2, "item")
		else:
			Game._msg("You don't have any %ss left!" % ItemsData.item_name(id), 1.2, "item")
		return
	if ItemsData.pocket_of(id) == "balls":
		Controls.close_items_page()
		Game.item_used.emit(k)
		throw_capture(id)
		return
	if item_cd > 0.0 or not is_instance_valid(Battle.partner) or Battle.partner.evolving:
		return
	var i: = Game.state.party.find(Battle.partner.mon)
	var r: = use_item(id, i, k)
	if r.ok:
		Controls.close_items_page()
		item_cd = Game.ITEM_CD
		Game.item_used.emit(k)
		get_node("/root/Vfx").burst(Battle.partner.global_position + Vector3(0, 0.6, 0), Color(0.6, 1.0, 0.65), 20, 0.7, 2.0, 0.1)
		Debug.log("[item] battle: %s on %s" % [id, Battle.partner.species])
	Game._msg(r.text if r.text != "" else "You can't use that now.", 1.8, "item")

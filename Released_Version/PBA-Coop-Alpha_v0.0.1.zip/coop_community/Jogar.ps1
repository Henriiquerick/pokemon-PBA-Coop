﻿param([ValidateSet('menu','host','guest','offline')][string]$Modo='menu',[string]$IP='',[int]$Porta=24620,[string]$Perfil='coop',[switch]$Validar)
$ErrorActionPreference='Stop'
$lock=$null
try {
    if($Perfil -notmatch '^[A-Za-z0-9_-]{1,40}$') { throw 'Nome de perfil invalido.' }
    if($Porta -lt 1024 -or $Porta -gt 65535) { throw 'Porta invalida.' }
    if($Modo -eq 'guest' -and !$IP) { $IP=Read-Host 'IP do anfitriao no Radmin VPN' }
    if($Modo -eq 'guest') {
        $address=$null
        if(![Net.IPAddress]::TryParse($IP,[ref]$address)) { throw 'Informe um IP valido do Radmin VPN.' }
    }
    $record=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'installation.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    $pack=Join-Path $PSScriptRoot 'PokemonBattleAdvanced.pck'
    if((Get-FileHash -LiteralPath $pack -Algorithm SHA256).Hash.ToLowerInvariant() -ne $record.coop_pack_sha256) { throw 'PCK restaurado ou alterado. Use o EXE direto ou instale em outra pasta.' }
    $data=Join-Path $PSScriptRoot ('userdata\'+$Perfil)
    [void][IO.Directory]::CreateDirectory($data)
    $lock=[IO.File]::Open((Join-Path $data 'profile.lock'),[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::ReadWrite)
    try { $lock.Lock(0,1) } catch { throw 'Este perfil ja esta aberto. Feche a outra instancia.' }
    $relative='Godot\app_userdata\Pok'+[char]233+'mon Battle Advanced'
    $user=Join-Path $data $relative
    [void][IO.Directory]::CreateDirectory($user)
    $personal=Join-Path $env:APPDATA $relative
    if(!(Test-Path -LiteralPath (Join-Path $user 'coop_s3\profile.json'))) {
        foreach($name in @('save.json','key_bindings.cfg','settings.cfg')) {
            $from=Join-Path $personal $name;$to=Join-Path $user $name
            if((Test-Path -LiteralPath $from) -and !(Test-Path -LiteralPath $to)) { [IO.File]::Copy($from,$to,$false) }
        }
        if($Modo -ne 'menu' -and (Test-Path -LiteralPath (Join-Path $user 'save.json')) -and !(Test-Path -LiteralPath (Join-Path $user 'campaign_input.json'))) { [IO.File]::Copy((Join-Path $user 'save.json'),(Join-Path $user 'campaign_input.json'),$false) }
    }
    $logs=Join-Path $PSScriptRoot 'logs';[void][IO.Directory]::CreateDirectory($logs)
    $log=Join-Path $logs ($Modo+'.log')
    if(Test-Path -LiteralPath $log) { [IO.File]::Copy($log,(Join-Path $logs ($Modo+'-'+(Get-Date -Format 'yyyyMMdd-HHmmss-ffff')+'.log')),$false) }
    if($Validar -and $Modo -ne 'offline') { throw 'Validar exige Modo offline e um perfil de teste.' }
    $arguments=@()
    if($Validar) { $arguments+='--headless' }
    $arguments+='--'
    if($Modo -eq 'menu') { $arguments+='--coop-menu' }
    else { $arguments+=@('--coop-campaign',('--coop-role='+$Modo),('--coop-ip='+$IP),('--coop-port='+$Porta),'--coop-start=save') }
    if($Validar) { $arguments+='--coop-persist-smoke' }
    $previousAppData=$env:APPDATA
    try {
        $env:APPDATA=$data
        $start=New-Object Diagnostics.ProcessStartInfo
        $start.FileName=Join-Path $PSScriptRoot 'PokemonBattleAdvanced.exe'
        $start.WorkingDirectory=$PSScriptRoot
        $start.Arguments=$arguments -join ' '
        $start.UseShellExecute=$false
        $start.RedirectStandardOutput=$true
        $start.RedirectStandardError=$true
        $start.StandardOutputEncoding=[Text.Encoding]::UTF8
        $start.StandardErrorEncoding=[Text.Encoding]::UTF8
        $process=New-Object Diagnostics.Process
        $process.StartInfo=$start
        [void]$process.Start()
        $stdout=$process.StandardOutput.ReadToEndAsync()
        $stderr=$process.StandardError.ReadToEndAsync()
        $process.WaitForExit()
        $result=$process.ExitCode
        [IO.File]::WriteAllText($log,$stdout.Result+$stderr.Result,(New-Object Text.UTF8Encoding($false)))
        $process.Dispose()
    } finally { $env:APPDATA=$previousAppData }
    Write-Host "Log: $log"
    if($result) { throw "O jogo encerrou com codigo $result. Use Coletar-Logs.bat." }
} catch { Write-Error $_.Exception.Message;exit 1 } finally { if($lock) {$lock.Dispose()} }

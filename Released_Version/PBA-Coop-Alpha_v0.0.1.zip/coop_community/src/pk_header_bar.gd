class_name PkHeaderBar
extends Control




const HEIGHT: = 52.0
const EMBLEM: = 30.0
const PAD: = 16.0

@export var screen_title: = "":
	set(v):
		screen_title = preload("res://coop/pt_br.gd").text(v)
		queue_redraw()


func _init() -> void :
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	custom_minimum_size = Vector2(0, HEIGHT)
	UiKit.connect_version(queue_redraw)


func _draw() -> void :
	var h: = size.y if size.y > 0.0 else HEIGHT
	var w: = size.x

	var strips: = 32
	for i in strips:
		var t: = float(i) / float(strips - 1)
		draw_rect(Rect2(w * i / strips, 0.0, w / strips + 1.0, h), 
			UiKit.SLATE_900.lerp(UiKit.header_end(), t))


	var slash: = Rect2(w * 0.33, 0.0, w * 0.7, h)
	var poly: = UiKit.skew_polygon(slash)
	for i in poly.size():
		poly.set(i, Vector2(clampf(poly[i].x, 0.0, w), poly[i].y))
	draw_colored_polygon(poly, Color(UiKit.accent(), 0.22))
	draw_rect(Rect2(0.0, h - 2.0, w, 2.0), UiKit.SLATE_700)

	var em: = Rect2(Vector2(PAD, (h - EMBLEM) * 0.5), Vector2(EMBLEM, EMBLEM))
	UiKit.skew_rect(self, em, UiKit.accent(), UiKit.accent_border())
	var c: = em.get_center() - Vector2(UiKit.skew_dx(EMBLEM) * 0.5, 0.0)
	draw_colored_polygon(PackedVector2Array([
		c + Vector2(0, -7), c + Vector2(7, 0), c + Vector2(0, 7), c + Vector2(-7, 0), 
	]), UiKit.WHITE)

	if screen_title == "":
		return
	var f: = UiKit.header_font()
	var fs: = 18
	var x: = em.end.x + 18.0
	var baseline: = h * 0.5 + fs * 0.36
	draw_string(f, Vector2(x, baseline), screen_title.to_upper(), HORIZONTAL_ALIGNMENT_LEFT, -1, fs, 
		UiKit.SLATE_100)

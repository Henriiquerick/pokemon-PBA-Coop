"""Curated initial-story/UI catalogue. Never translates move names or identifiers."""
from pathlib import Path
import json,re
ROOT=Path(__file__).resolve().parent
PAIRS=r'''
New Game|Novo jogo
Continue|Continuar
Options|Opções
Settings|Configurações
Credits|Créditos
Quit|Sair
Exit|Sair
Back|Voltar
Cancel|Cancelar
Confirm|Confirmar
Yes|Sim
No|Não
Save|Salvar
Load|Carregar
Saving...|Salvando...
Saved!|Salvo!
Loading...|Carregando...
Select|Selecionar
Close|Fechar
Resume|Continuar
Run|Correr
Jump|Pular
Dodge|Esquivar
Swap|Alternar
Bag|Bolsa
Items|Itens
Pokémon|Pokémon
POKéMON|POKÉMON
Party|Equipe
Summary|Resumo
Moves|Golpes
Stats|Atributos
Ability|Habilidade
Nature|Natureza
Level|Nível
Trainer|Treinador
Player|Jogador
Money|Dinheiro
Badges|Insígnias
Time|Tempo
Location|Local
Play time|Tempo de jogo
Town Map|Mapa de Kanto
Map|Mapa
Quick travel|Viagem rápida
Visited|Visitados
Move|Mover
Buy|Comprar
Sell|Vender
See ya!|Até mais!
Welcome!|Boas-vindas!
Sound|Som
Music|Música
Volume|Volume
Controls|Controles
Keyboard|Teclado
Gamepad|Controle
Graphics|Gráficos
Display|Tela
Fullscreen|Tela cheia
Windowed|Janela
Resolution|Resolução
Apply|Aplicar
Default|Padrão
Reset|Restaurar
Language|Idioma
Touch|Toque
Auto|Automático
On|Ligado
Off|Desligado
Speed|Velocidade
Battle speed|Velocidade da batalha
Text speed|Velocidade do texto
Fast|Rápido
Normal|Normal
Slow|Lento
Choose a Pokémon|Escolha um Pokémon
Send out|Soltar
Supporter|Apoio
Pet|Acariciar
Control|Controlar
Online trading|Troca online
Your offer|Sua oferta
Their offer|Oferta do parceiro
Trade|Trocar
Leave|Sair
Waiting...|Aguardando...
No save data|Nenhum save
Save game|Salvar jogo
Are you sure?|Tem certeza?
Welcome to the world of POKéMON!|Boas-vindas ao mundo dos POKÉMON!
Hello there! Glad to meet you!|Olá! Que bom conhecer você!
My name is OAK.|Meu nome é OAK.
People affectionately refer to me\nas the POKéMON PROFESSOR.|As pessoas me conhecem como\no PROFESSOR POKÉMON.
This world…|Este mundo…
…is inhabited far and wide by\ncreatures called POKéMON.|…é habitado por toda parte por\ncriaturas chamadas POKÉMON.
Hey! Wait! Don't go out!|Ei! Espere! Não saia daí!
It's unsafe! Wild POKéMON live\nin tall grass!|É perigoso! Há POKÉMON selvagens\nna grama alta!
You need your own POKéMON for\nyour protection.|Você precisa de um POKÉMON\npara se proteger.
I know!\nHere, come with me!|Já sei!\nVenha comigo!
Gramps! I'm fed up with waiting!|Vovô! Já cansei de esperar!
{RIVAL}?\nLet me think…|{RIVAL}?\nDeixe-me pensar…
Oh, that's right, I told you to\ncome! Just wait!|Ah, claro! Eu pedi que viesse!\nEspere só um pouco!
Here, {PLAYER}.|Aqui, {PLAYER}.
There are three POKéMON here.|Aqui estão três POKÉMON.
Haha!|Ha-ha!
The POKéMON are held inside\nthese POKé BALLS.|Os POKÉMON ficam dentro\ndestas POKÉ BOLAS.
When I was young, I was a serious\nPOKéMON TRAINER.|Quando era jovem, eu era um\nTREINADOR POKÉMON dedicado.
But now, in my old age, I have\nonly these three left.|Mas agora, com a idade,\nsó me restaram estes três.
You can have one.\nGo on, choose!|Pode ficar com um.\nVamos, escolha!
Hey! Gramps! No fair!\nWhat about me?|Ei, vovô! Não é justo!\nE eu?
Be patient, {RIVAL}.\nYou can have one, too!|Tenha paciência, {RIVAL}.\nVocê também pode escolher um!
I see! BULBASAUR is your choice.\nIt's very easy to raise.\nSo, {PLAYER}, you want to go with\nthe GRASS POKéMON BULBASAUR?|Entendi! Você escolheu BULBASAUR.\nÉ bem fácil de criar.\nEntão, {PLAYER}, vai ficar com\nBULBASAUR, do tipo GRASS?
Ah! CHARMANDER is your choice.\nYou should raise it patiently.\nSo, {PLAYER}, you're claiming the\nFIRE POKéMON CHARMANDER?|Ah! Você escolheu CHARMANDER.\nÉ preciso criá-lo com paciência.\nEntão, {PLAYER}, quer ficar com\nCHARMANDER, do tipo FIRE?
Hm! SQUIRTLE is your choice.\nIt's one worth raising.\nSo, {PLAYER}, you've decided on the\nWATER POKéMON SQUIRTLE?|Hum! Você escolheu SQUIRTLE.\nVale a pena criá-lo.\nEntão, {PLAYER}, decidiu ficar com\nSQUIRTLE, do tipo WATER?
Hey!\nYou came from PALLET TOWN?|Ei!\nVocê veio de PALLET?
You know PROF. OAK, right?|Você conhece o PROF. OAK, certo?
His order came in.\nCan I get you to take it to him?|A encomenda dele chegou.\nPode levá-la até ele?
Okay, thanks! Please say hi to\nPROF. OAK for me, too.|Obrigado! Mande um abraço\npara o PROF. OAK por mim.
Oh, {PLAYER}!\nHow is my old POKéMON?|Ah, {PLAYER}!\nComo está meu velho POKÉMON?
Well, it seems to be growing more\nattached to you.|Parece que ele está ficando\ncada vez mais apegado a você.
You must be talented as a POKéMON\nTRAINER.|Você deve ter talento como\nTREINADOR POKÉMON.
What's that?\nYou have something for me?|O que foi?\nTem algo para mim?
{PLAYER} delivered OAK'S PARCEL.|{PLAYER} entregou a ENCOMENDA DE OAK.
Ah! \nIt's the custom POKé BALL!|Ah!\nÉ a POKÉ BOLA que encomendei!
I had it on order.\nThank you!|Eu a tinha encomendado.\nObrigado!
I almost forgot!\nWhat did you call me for?|Quase me esqueci!\nPor que você me chamou?
Oh, right!\nI have a request for you two.|Ah, sim!\nTenho um pedido para vocês dois.
On the desk there is my invention,\nthe POKéDEX!|Sobre a mesa está minha invenção,\na POKÉDEX!
It automatically records data on\nPOKéMON you've seen or caught.|Ela registra os dados dos POKÉMON\nque vocês viram ou capturaram.
It's a high-tech encyclopedia!|É uma enciclopédia de alta tecnologia!
{PLAYER} and {RIVAL}.\nTake these with you.|{PLAYER} e {RIVAL}.\nLevem estas com vocês.
You can't get detailed data\non POKéMON by just seeing them.|Só olhar os POKÉMON não basta\npara obter dados completos.
You must catch them to obtain\ncomplete data.|É preciso capturá-los\npara obter todos os dados.
So, here are some tools for\ncatching wild POKéMON.|Aqui estão alguns itens para\ncapturar POKÉMON selvagens.
To make a complete guide on all\nthe POKéMON in the world…|Criar um guia completo de todos\nos POKÉMON do mundo…
That was my dream!|Esse era meu sonho!
But, I'm too old.\nI can't get the job done.|Mas já estou velho demais\npara fazer isso sozinho.
So, I want you two to fulfill my\ndream for me.|Quero que vocês dois realizem\nesse sonho por mim.
Get moving, you two.|Vamos lá, vocês dois!
This is a great undertaking in\nPOKéMON history!|Esta é uma grande missão\nna história dos POKÉMON!
All right, Gramps!\nLeave it all to me!|Pode deixar, vovô!\nEu cuido de tudo!
{PLAYER}, I hate to say it, but you\nwon't be necessary for this.|{PLAYER}, sinto muito, mas\nnão vou precisar de você.
I know! I'll borrow a TOWN MAP\nfrom my sis!|Já sei! Vou pegar um MAPA\nemprestado com minha irmã!
I'll tell her not to lend you one,\n{PLAYER}! Hahaha!|Vou dizer para ela não emprestar\num para você, {PLAYER}! Ha-ha-ha!
Don't bother coming around to\nmy place after this!|Nem pense em passar\nna minha casa depois!
So, you're here. I'm BROCK.\nI'm PEWTER's GYM LEADER.|Então você veio. Sou BROCK,\nLÍDER DO GINÁSIO de PEWTER.
My rock-hard willpower is evident\neven in my POKéMON.|Minha vontade é firme como pedra.\nMeus POKÉMON são a prova disso.
My POKéMON are all rock hard, and\nhave true-grit determination.|Meus POKÉMON são resistentes\ne têm uma determinação inabalável.
That's right - my POKéMON are all\nthe ROCK type!|Isso mesmo! Meus POKÉMON\nsão todos do tipo ROCK!
Fuhaha! You're going to challenge\nme knowing that you'll lose?|Ha-ha! Vai me desafiar mesmo\nsabendo que vai perder?
That's the TRAINER's honor that\ncompels you to challenge me.|É a honra de TREINADOR que\nfaz você aceitar esse desafio.
Fine, then!\nShow me your best!|Muito bem!\nMostre o seu melhor!
I took you for granted, and so\nI lost.|Eu subestimei você\ne acabei perdendo.
As proof of your victory, I confer\non you this…the official POKéMON\nLEAGUE BOULDERBADGE.|Como prova da sua vitória,\nentrego a INSÍGNIA DA ROCHA\noficial da LIGA POKÉMON.
There are all kinds of TRAINERS in\nthis huge world of ours.|Há todo tipo de TREINADOR\nneste mundo enorme.
You appear to be very gifted as a\nPOKéMON TRAINER.|Você parece ter muito talento\ncomo TREINADOR POKÉMON.
So let me make a suggestion.|Vou dar uma sugestão.
Go to the GYM in CERULEAN and test\nyour abilities.|Vá ao GINÁSIO de CERULEAN\ne teste suas habilidades.
Just having the BOULDERBADGE makes\nyour POKéMON more powerful.|Só de ter a INSÍGNIA DA ROCHA,\nseus POKÉMON ficam mais fortes.
Wait! Take this with you.|Espere! Leve isto também.
A TM, TECHNICAL MACHINE, contains a\ntechnique for POKéMON.|Uma TM, MÁQUINA TÉCNICA, contém\num golpe para ensinar aos POKÉMON.
Using a TM teaches the move it\ncontains to a POKéMON.|Usar uma TM ensina o golpe\nque ela contém a um POKÉMON.
Anyways... TM39 contains ROCK TOMB.|A TM39 contém ROCK TOMB.
It hurls boulders at the foe and\nlowers its SPEED.|Ela lança pedras no adversário\ne reduz sua VELOCIDADE.
Stop right there, kid!|Pare aí, garoto!
You're ten thousand light-years \nfrom facing BROCK!|Você está a dez mil anos-luz\nde enfrentar BROCK!
Darn!|Droga!
Light-years isn't time…\nIt measures distance!|Ano-luz não mede tempo…\nMede distância!
You're pretty hot.\n…But not as hot as BROCK!|Você manda bem.\n…Mas não tanto quanto BROCK!
Hold it! Nobody climbs to BROCK\nwithout getting past me first!|Alto lá! Ninguém chega ao BROCK\nsem passar por mim primeiro!
My POKéMON were raised on the\nmountain. They don't budge!|Meus POKÉMON cresceram na\nmontanha. Não recuam!
Whoa!\nYou flattened my boulders!|Uau!\nVocê esmagou minhas pedras!
Rocks shrug off normal hits.\nWATER and GRASS wear them down.|Pedras resistem a golpes comuns.\nWATER e GRASS as desgastam.
Watch out for ONIX. When it digs,\nhit it as it comes back up!|Cuidado com ONIX! Quando ele cavar,\nacerte-o assim que voltar à superfície!
Rematch?|Revanche?
Will you face me again?|Vai me enfrentar outra vez?
Welcome to our POKéMON CENTER!|Boas-vindas ao CENTRO POKÉMON!
Would you like me to heal your POKéMON?|Quer que eu cure seus POKÉMON?
Hi there!\nMay I help you?|Olá!\nPosso ajudar?
Thank you!|Obrigado!
Come again!|Volte sempre!
You don't have any Pokémon! Get one at the lab first.|Você ainda não tem um Pokémon! Pegue um no laboratório primeiro.
You have no Poké Balls!|Você não tem Poké Bolas!
The trainer blocked the ball! Don't be a thief!|O treinador bloqueou a bola! Não tente capturar Pokémon de outra pessoa!
It's a dummy - Poke Balls won't help!|É um boneco de treino. Poké Bolas não vão ajudar!
The spirit slips away from the ball!|O espírito escapa da bola!
Control other fighter|Controlar outro Pokémon
Ally menu|Menu do aliado
Fight!|Lutem!
DODGED!|ESQUIVOU!
MISSED!|ERROU!
Fainted|Desmaiado
Caught|Capturado
Victory|Vitória
Defeat|Derrota
Save and quit|Salvar e sair
Do you want to save the game?|Quer salvar o jogo?
Please wait...|Aguarde...
Host|Anfitrião
Guest|Convidado
Connection lost|Conexão perdida
Connecting...|Conectando...
You can't go east to Route 3 without the Boulder Badge.|Você precisa da Insígnia da Rocha para seguir para a Rota 3.
Beat Leader Brock at the Pewter Gym and come back!|Derrote Brock no Ginásio de Pewter e volte aqui!
Wait, {PLAYER}!\nLet's check out our POKéMON!|Espere, {PLAYER}!\nVamos testar nossos POKÉMON!
Come on, I'll take you on!|Vamos lá! Eu enfrento você!
Blue's always in such a rush.|Blue está sempre com pressa.
{PLAYER}, this is your first battle.\nLet me show you how it's done.|{PLAYER}, esta é sua primeira batalha.\nVou mostrar como se faz.
WHAT?\nUnbelievable!\nI picked the wrong POKéMON!|O QUÊ?\nNão acredito!\nEscolhi o POKÉMON errado!
Yeah!\nAm I great or what?|Isso!\nEu sou demais, não sou?
If a wild POKéMON appears,\nyour POKéMON can battle it.|Se um POKÉMON selvagem aparecer,\nseu POKÉMON pode enfrentá-lo.
With it at your side, you should be\nable to reach the next town.|Com ele ao seu lado, você deve\nconseguir chegar à próxima cidade.
Okay! I'll make my\nPOKéMON battle to toughen it up!|Certo! Vou treinar meu\nPOKÉMON para ele ficar mais forte!
{PLAYER}! Gramps!\nSmell you later!|{PLAYER}! Vovô!\nAté mais!
{RIVAL}: Hey! {PLAYER}!|{RIVAL}: Ei! {PLAYER}!
You're off to the POKéMON LEAGUE?\nForget about it!|Vai para a LIGA POKÉMON?\nPode esquecer!
You probably don't have any\nBADGES, do you?|Você provavelmente não tem\nnenhuma INSÍGNIA, não é?
The guard won't let you through\nwithout them.|O guarda não vai deixar\nvocê passar sem elas.
By the way, did your POKéMON get\nany stronger?|Aliás, seus POKÉMON\nficaram mais fortes?
Awww!\nYou just lucked out!|Ah, não!\nVocê só teve sorte!
{RIVAL}: Yeah!\nAm I great or what?|{RIVAL}: Isso!\nEu sou demais, não sou?
I heard the POKéMON LEAGUE is\ncrawling with tough TRAINERS.|Ouvi dizer que a LIGA POKÉMON\nestá cheia de TREINADORES fortes.
I have to figure out how to get\npast them.|Preciso descobrir como\npassar por eles.
You should quit dawdling and get a\nmove on!|Pare de enrolar e\ncomece a se mexer!
''' 

def build():
    catalogue={}
    for row in PAIRS.strip().splitlines():
        source,target=row.split('|',1)
        # The raw source keeps GDScript's escaped line breaks readable.
        source=source.replace('\\\\n','\n').replace('\\n','\n')
        target=target.replace('\\\\n','\n').replace('\\n','\n')
        catalogue[source]=target
    data=ROOT.parent/'coop_lab/PokemonBattleAdvanced_extracted/data'
    moves=json.loads((data/'moves.json').read_text(encoding='utf8'))
    protected={str(d.get('name','')).casefold() for d in moves['moves'] if isinstance(d,dict)}
    assert len(protected)>100
    # Alias authored line wraps without changing story scripts, flags or names.
    normalized={' '.join(k.split()).casefold():v for k,v in catalogue.items()}
    authored=[]
    story=(ROOT.parent/'coop_lab/decompiled/story.gd').read_text(encoding='utf8')
    for token in re.findall(r'"(?:\\.|[^"\\])*"',story):
        try:authored.append(json.loads(token))
        except ValueError:pass
    def collect(value):
        if isinstance(value,str):authored.append(value)
        elif isinstance(value,dict):
            for child in value.values():collect(child)
        elif isinstance(value,list):
            for child in value:collect(child)
    collect(json.loads((data/'trainers.json').read_text(encoding='utf8')))
    for original in authored:
        key=' '.join(original.split()).casefold()
        if key in normalized and original.casefold() not in protected:catalogue.setdefault(original,normalized[key])
    for key,value in list(catalogue.items()):
        if key.casefold() in protected:del catalogue[key];continue
        if len(key)<70 and '\n' not in key and key.upper().casefold() not in protected:catalogue.setdefault(key.upper(),value.upper())
    for en,pt in catalogue.items():
        assert sorted(re.findall(r'\{[^}]+\}|%[sdf]',en))==sorted(re.findall(r'\{[^}]+\}|%[sdf]',pt)),en
        assert en.casefold() not in protected,en
    (ROOT/'src/pt_br.json').write_text(json.dumps(catalogue,ensure_ascii=False,indent=2),encoding='utf8')
    print('Mensagens PT-BR:',len(catalogue),'nomes de golpes protegidos:',len(protected))
if __name__=='__main__':build()

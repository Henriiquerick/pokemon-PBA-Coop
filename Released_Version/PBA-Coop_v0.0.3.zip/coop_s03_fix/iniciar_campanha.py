"""Launch isolated campaign LAN, solo, or the original proven test arena."""
from pathlib import Path
import argparse,os,subprocess,json,shutil,datetime
from packtools import sha256
ROOT=Path(__file__).resolve().parent

if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('role',choices=['host','guest','offline','menu','solo'])
    ap.add_argument('ip',nargs='?',default='127.0.0.1')
    ap.add_argument('--perfil',default='coop',help='Nome do perfil persistente local, independente do papel host/guest')
    ap.add_argument('--porta',type=int,default=24620)
    ap.add_argument('--arena',action='store_true',help='Arena LAN v1 comprovada')
    ap.add_argument('--inicio',choices=['save','route2','brock','split'],default='save',help='save abre na posicao do seu save; split testa Brock/Route 2')
    ap.add_argument('--save',type=Path,help='Importa uma COPIA deste save; por padrao usa o save.json pessoal')
    ap.add_argument('--bindings',type=Path,help='Copia key_bindings.cfg para este perfil isolado')
    ap.add_argument('--auto',action='store_true',help='Entradas automaticas, somente para validacao')
    ap.add_argument('--teste',default='win',choices=['win','lose','abort','repeat','pad','drop_host','drop_guest','travel','wild'])
    ap.add_argument('--debug-rede',action='store_true',help='RTT, jitter e contadores LAN')
    ap.add_argument('--headless',action='store_true')
    args=ap.parse_args()
    manifest=json.loads((ROOT/'installation.json').read_text(encoding='utf8'))
    if sha256(ROOT/'PokemonBattleAdvanced.pck')!=manifest['coop_pack_sha256']:
        raise SystemExit('O PCK foi restaurado ou mudou. Reinstale em uma pasta nova.')
    import re
    if not re.fullmatch(r'[A-Za-z0-9_-]{1,40}',args.perfil):raise SystemExit('Nome de perfil invalido.')
    profile=('solo' if args.role=='solo' else (args.role if args.auto else args.perfil))
    data=ROOT/'userdata'/profile
    user=data/'Godot/app_userdata/Pokémon Battle Advanced'
    user.mkdir(parents=True,exist_ok=True)
    (user/'shader_cache').mkdir(exist_ok=True)
    stamp=datetime.datetime.now().strftime('%Y%m%d-%H%M%S-%f')
    lock_file=None
    if args.role!='solo' and not args.auto:
        import msvcrt
        lock_file=(data/'profile.lock').open('a+b')
        lock_file.seek(0);lock_file.write(b'1');lock_file.flush();lock_file.seek(0)
        try:msvcrt.locking(lock_file.fileno(),msvcrt.LK_NBLCK,1)
        except OSError:raise SystemExit('Este perfil cooperativo ja esta aberto. Feche a outra instancia.')
    source=args.save
    has_profile=(user/'coop_s3/profile.json').exists() or (user/'coop_s3/profile.json.bak').exists()
    if source is not None and has_profile and args.role!='solo':raise SystemExit('Perfil coop ja existe: continue sem --save ou escolha --perfil NOVO. Nao foi sobrescrito.')
    if source is None and args.role not in ['solo','menu'] and not args.arena and not args.auto and not has_profile:
        source=Path(os.environ['APPDATA'])/'Godot/app_userdata/Pokémon Battle Advanced/save.json'
        if not source.is_file():raise SystemExit('Save pessoal nao encontrado. Use --save "CAMINHO_DO_SEU_SAVE.json".')
    if source is not None:
        source=source.resolve()
        doc=json.loads(source.read_text(encoding='utf8-sig'))
        if not isinstance(doc.get('state'),dict) or not isinstance(doc.get('state',{}).get('party'),list):
            raise SystemExit('Arquivo nao parece um save de campanha valido.')
        if args.role not in ['solo','offline','menu'] and not any(isinstance(m,dict) and int(m.get('hp',0))>0 and not m.get('egg',False) for m in doc['state']['party']):
            raise SystemExit('O save precisa ter pelo menos um Pokemon apto para conectar em co-op.')
        backup=ROOT/'save_backups'/profile/stamp
        backup.mkdir(parents=True)
        shutil.copy2(source,backup/source.name)
        dest=user/('save.json' if args.role=='solo' else 'campaign_input.json')
        if dest.exists():shutil.copy2(dest,backup/('previous_'+dest.name))
        shutil.copy2(source,dest)
        (backup/'source.json').write_text(json.dumps({'source':str(source),'sha256':sha256(source)},indent=2),encoding='utf8')
    if args.role=='menu':
        personal=Path(os.environ['APPDATA'])/'Godot/app_userdata'/user.name/'save.json'
        if personal.is_file() and not (user/'save.json').exists():shutil.copy2(personal,user/'save.json')
    if args.bindings:
        shutil.copy2(args.bindings,user/'key_bindings.cfg')
    env=os.environ.copy();env['APPDATA']=str(data)
    cmd=[str(ROOT/'PokemonBattleAdvanced.exe')]
    if args.headless:cmd+=['--headless']
    if args.role=='menu':cmd+=['--','--coop-menu']
    elif args.role!='solo':
        cmd+=['--','--coop' if args.arena else '--coop-campaign','--coop-role='+args.role,'--coop-ip='+args.ip,'--coop-port='+str(args.porta),'--coop-start='+args.inicio]
        if args.debug_rede:cmd+=['--coop-debug']
        if args.auto:cmd+=['--coop-autotest','--coop-test='+args.teste]
    logs=ROOT/'logs';logs.mkdir(exist_ok=True)
    print('Perfil isolado:',data)
    if source is not None:print('Copia do save:',source)
    logfile=logs/(args.role+'.log')
    if logfile.exists():shutil.copy2(logfile,logs/(args.role+'-'+stamp+'.log'))
    print('Log:',logfile)
    with logfile.open('w',encoding='utf8') as out:
        rc=subprocess.call(cmd,cwd=ROOT,env=env,stdout=out,stderr=out)
        out.write('\n[launcher] exit_code=%d\n'%rc)
        out.flush()
    raise SystemExit(rc)

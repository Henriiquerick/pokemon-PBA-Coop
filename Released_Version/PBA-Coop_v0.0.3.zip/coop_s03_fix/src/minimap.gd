class_name Minimap
extends Control














const UiKit: = preload("res://scripts/ui/kit/ui_kit.gd")

const DATA: = "res://data/minimap.json"
const MEAL_FULL: = preload("res://assets/ui/cooking/icons/porridge.png")
const MEAL_EMPTY: = preload("res://assets/sprites/picnic/cooking/bowl_empty.png")

const MEAL_ANGLES: = [205.0, 228.0, 251.0]
const MEAL_SIZE: = 24.0
const VIEW_M: = 40.0
const RES: = 256
const UPDATE_HZ: = 20.0
const SYNC_S: = 0.25
const CAM_H: = 120.0


const C_GROUND_A: = Color("5d7d4c")
const C_GROUND_B: = Color("678a52")
const C_GRASS: = Color("3f6234")
const C_GRASS_TUFT: = Color("5f8d4a")
const C_PATH: = Color("d9ca9d")
const C_PATH_EDGE: = Color("a8966a")
const C_WATER: = Color("4c88c6")
const C_SHORE: = Color("94c6ec")
const C_HILL: = Color("8a9b5d")
const C_CLIFF: = Color("4b5b35")
const C_TREE: = Color("2f5128")
const C_TREE_HI: = Color("4d7e3d")
const C_FENCE: = Color("f0e7d0")
const C_LEDGE: = Color("39492b")
const C_SHADOW: = Color("3a5530")
const C_DOOR: = Color("2b303c")
const C_FLOWER: = Color("dc7fb0")
const C_FLOWER_EYE: = Color("f4d870")

const ROOFS: = [Color("d9825b"), Color("e45f70"), Color("4f80d2"), Color("8d93a1"), Color("e9c25c"), Color("7c8799")]

const CELL: = 8.0
const DISC_N: = 8

const TREE_CHUNK: = 120
const BEZEL: = Color("394454")
const BEZEL_CREAM: = Color("fff0b8")

const Y_GROUND: = 0.0
const Y_CHECK: = 0.02
const Y_CLIFF: = 0.04
const Y_HILL: = 0.05
const Y_GRASS: = 0.08
const Y_TUFT: = 0.09
const Y_FLOWER: = 0.1
const Y_SHORE: = 0.12
const Y_WATER: = 0.14
const Y_PATH_EDGE: = 0.16
const Y_PATH: = 0.18
const Y_LEDGE: = 0.2
const Y_TREELINE: = 0.22
const Y_FENCE: = 0.24
const Y_SHADOW: = 0.26
const Y_WALL: = 0.3
const Y_ROOF: = 0.32
const Y_RIDGE: = 0.34
const Y_TREE: = 0.4

const MASK_SHADER: = "\nshader_type canvas_item;\nvoid fragment() {\n\tvec4 c = texture(TEXTURE, UV);\n\tfloat d = distance(UV, vec2(0.5));\n\tCOLOR = vec4(c.rgb, c.a * smoothstep(0.5, 0.49, d));\n}\n"









var suppressed: = false:
	set(v):
		suppressed = v
		_refresh_visible()

var diameter: = 170.0

var meals: = -1:
	set(v):
		if v != meals:
			meals = v
			_redraw_ring()

var _data: = {}
var _view: SubViewport
var _cam: Camera3D
var _root: Node3D
var _proxies: = {}
var _sync_t: = 0.0
var _update_t: = 0.0
var _streamer: Node
var _arrow_deg: = 0.0

var _disabled: = OS.get_cmdline_user_args().has("--no-minimap")
var _ring: Control


func _init() -> void :
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	name = "minimap"
	visible = false


func _ready() -> void :
	var f: = FileAccess.open(DATA, FileAccess.READ)
	if f != null:
		_data = JSON.parse_string(f.get_as_text())
	_view = SubViewport.new()
	_view.size = Vector2i(RES, RES)
	_view.own_world_3d = true
	_view.transparent_bg = true
	_view.msaa_3d = Viewport.MSAA_DISABLED
	_view.disable_3d = false
	_view.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	add_child(_view)
	_root = Node3D.new()
	_view.add_child(_root)
	_cam = Camera3D.new()
	_cam.projection = Camera3D.PROJECTION_ORTHOGONAL
	_cam.size = VIEW_M
	_cam.near = 1.0
	_cam.far = CAM_H * 2.0
	_cam.rotation_degrees = Vector3(-90.0, 0.0, 0.0)
	_view.add_child(_cam)
	var tex: = TextureRect.new()
	tex.texture = _view.get_texture()
	tex.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	tex.stretch_mode = TextureRect.STRETCH_SCALE
	tex.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var mat: = ShaderMaterial.new()
	var sh: Shader = preload("res://scripts/perf/shader_cache.gd").of(MASK_SHADER)
	mat.shader = sh
	tex.material = mat
	tex.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(tex)
	_ring = Control.new()
	_ring.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_ring.set_anchors_preset(Control.PRESET_FULL_RECT)
	_ring.draw.connect(_draw_ring)
	add_child(_ring)
	set_diameter(diameter)


func set_diameter(d: float) -> void :
	diameter = d
	custom_minimum_size = Vector2(d, d)
	size = Vector2(d, d)
	if _ring != null:
		_ring.queue_redraw()
	queue_redraw()


func _redraw_ring() -> void :
	if _ring != null:
		_ring.queue_redraw()


func _draw() -> void :

	draw_circle(size / 2.0, size.x / 2.0, Color(UiKit.SLATE_950, 0.82))


func _draw_ring() -> void :
	var c: = _ring.size / 2.0
	var r: = _ring.size.x / 2.0

	var k: = r / 85.0
	_ring.draw_arc(c, r - 4.0 * k, 0.0, TAU, 96, BEZEL, 8.0 * k, true)
	_ring.draw_arc(c, r - 0.8 * k, 0.0, TAU, 96, UiKit.SLATE_950, 1.6 * k, true)
	_ring.draw_arc(c, r - 9.6 * k, 0.0, TAU, 96, UiKit.accent_border(), 2.6 * k, true)
	_ring.draw_arc(c, r - 11.9 * k, 0.0, TAU, 96, BEZEL_CREAM, 1.2 * k, true)
	_draw_meals(c, r)
	var lan = get_node_or_null("/root/LanCampaign")
	var player = Game.get_player()
	if lan != null and lan.peer_ready and player != null and lan.remote_scene == get_tree().current_scene.scene_file_path:
		var delta: Vector3 = lan.remote_at - player.global_position
		var offset = Vector2(delta.x,delta.z) * (_ring.size.x / VIEW_M)
		var edge = r * 0.78
		var point = c + offset.limit_length(edge)
		_ring.draw_circle(point,5.0 * k,Color.CYAN)
		_ring.draw_arc(point,6.0*k,0,TAU,16,Color.BLACK,2.0*k,true)
		if offset.length() > edge:
			var dir = offset.normalized()
			var side = Vector2(-dir.y,dir.x)
			_ring.draw_colored_polygon(PackedVector2Array([point+dir*9*k,point-dir*4*k+side*5*k,point-dir*4*k-side*5*k]),Color.CYAN)


	var a: = deg_to_rad(_arrow_deg)
	var fwd: = Vector2(sin(a), - cos(a))
	var side: = Vector2( - fwd.y, fwd.x)
	var ak: = r * 0.11
	var tip: = c + fwd * ak * 1.6
	var pts: = PackedVector2Array([tip, c - fwd * ak + side * ak * 0.9, c - fwd * ak * 0.4, c - fwd * ak - side * ak * 0.9])
	_ring.draw_colored_polygon(pts, UiKit.WHITE)
	_ring.draw_polyline(PackedVector2Array([pts[0], pts[1], pts[2], pts[3], pts[0]]), UiKit.SLATE_950, 1.5, true)


func _process(delta: float) -> void :
	_refresh_visible()
	if not visible:
		return
	var p: = Game.get_player()
	if p == null:
		return
	_cam.global_position = Vector3(p.global_position.x, CAM_H, p.global_position.z)
	_ring.queue_redraw()
	var fv: Vector3 = p.facing_vector() if p.has_method("facing_vector") else Vector3.ZERO
	if fv.length_squared() > 0.001:
		var deg: = rad_to_deg(atan2(fv.x, - fv.z))
		if not is_equal_approx(deg, _arrow_deg):
			_arrow_deg = deg
			_ring.queue_redraw()
	_sync_t -= delta
	if _sync_t <= 0.0:
		_sync_t = SYNC_S
		_sync_zones()
	if UPDATE_HZ > 0.0:
		_update_t -= delta
		_view.render_target_update_mode = SubViewport.UPDATE_ONCE if _update_t <= 0.0 else SubViewport.UPDATE_DISABLED
		if _update_t <= 0.0:
			_update_t = 1.0 / UPDATE_HZ


func _refresh_visible() -> void :
	if _streamer == null or not is_instance_valid(_streamer):
		_streamer = get_tree().get_first_node_in_group("zone_streamer") if is_inside_tree() else null
	var want: = not _disabled and _streamer != null and not suppressed and not Battle.in_battle and Game.get_player() != null\
	and String(_streamer.active) != ""
	if want != visible:
		visible = want
		if _view != null:
			_view.render_target_update_mode = SubViewport.UPDATE_ALWAYS if want else SubViewport.UPDATE_DISABLED



func _sync_zones() -> void :
	var loaded: Dictionary = _streamer.loaded
	for id in loaded:
		if not _proxies.has(id) and _data.has(id):
			var zone: = Node3D.new()
			zone.add_child(_build_zone(_data[id]))
			_root.add_child(zone)
			_proxies[id] = zone
			_build_trees(zone, _data[id].get("trees", []))
	for id in _proxies.keys():
		if not loaded.has(id):
			_proxies[id].queue_free()
			_proxies.erase(id)



static var DISC: = _make_disc()


static func _make_disc() -> PackedVector2Array:
	var out: = PackedVector2Array()
	for i in DISC_N + 1:
		out.append(Vector2(cos(TAU * i / DISC_N), sin(TAU * i / DISC_N)))
	return out



class Buf:
	var v: = PackedVector3Array()
	var c: = PackedColorArray()
	var col: = Color.WHITE

	func add(p: Vector3) -> void :
		v.append(p)
		c.append(col)


func _build_zone(d: Dictionary) -> MeshInstance3D:
	var st: = Buf.new()
	for r in d.get("ground", []):
		_quad(st, r, Y_GROUND, C_GROUND_A)
		_checker(st, r)
	for r in d.get("hills", []):
		_quad(st, _grow(r, 0.6), Y_CLIFF, C_CLIFF)
		_quad(st, r, Y_HILL, C_HILL)
	for r in d.get("grass", []):
		_quad(st, r, Y_GRASS, C_GRASS)
		_tufts(st, r)
	for f in d.get("flowers", []):
		_disc(st, f[0], f[1], f[2], Y_FLOWER, C_FLOWER)
		_disc(st, f[0], f[1], f[2] * 0.45, Y_FLOWER + 0.01, C_FLOWER_EYE)
	for r in d.get("water", []):
		_quad(st, _grow(r, 0.7), Y_SHORE, C_SHORE)
		_quad(st, r, Y_WATER, C_WATER)
	for r in d.get("paths", []):
		_quad(st, _grow(r, 0.5), Y_PATH_EDGE, C_PATH_EDGE)
	for r in d.get("paths", []):
		_quad(st, r, Y_PATH, C_PATH)
	for l in d.get("ledges", []):
		_seg(st, l, 0.8, Y_LEDGE, C_LEDGE)
	for l in d.get("tree_lines", []):
		var w: float = 2.4 * float(l[4])
		_seg(st, l, w, Y_TREELINE, C_TREE)
		_seg(st, l, w * 0.5, Y_TREELINE + 0.01, C_TREE_HI)
	for l in d.get("fences", []):
		_seg(st, l, 0.5, Y_FENCE, C_FENCE)
	for b in d.get("buildings", []):
		_building(st, b)
	return _to_instance(st)




func _build_trees(zone: Node3D, trees: Array) -> void :
	var i: = 0
	while i < trees.size():
		var st: = Buf.new()
		var end: = mini(i + TREE_CHUNK, trees.size())
		for j in range(i, end):
			var t: Array = trees[j]
			_disc(st, t[0], t[1], 1.4, Y_TREE, C_TREE)
			_disc(st, t[0] - 0.3, t[1] - 0.3, 0.8, Y_TREE + 0.02, C_TREE_HI)
		zone.add_child(_to_instance(st))
		i = end
		if i < trees.size():
			await get_tree().process_frame
			if not is_instance_valid(zone):
				return


func _to_instance(st: Buf) -> MeshInstance3D:
	var mi: = MeshInstance3D.new()
	var arrays: = []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = st.v
	arrays[Mesh.ARRAY_COLOR] = st.c
	var mesh: = ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	mi.mesh = mesh
	var mat: = StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.vertex_color_use_as_albedo = true
	mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	mi.material_override = mat
	return mi


func _grow(r: Array, m: float) -> Array:
	return [float(r[0]) - m, float(r[1]) - m, float(r[2]) + 2.0 * m, float(r[3]) + 2.0 * m]



func _checker(st: Buf, r: Array) -> void :
	var x0: = float(r[0])
	var z0: = float(r[1])
	var x1: = x0 + float(r[2])
	var z1: = z0 + float(r[3])
	for gx in range(int(floor(x0 / CELL)), int(ceil(x1 / CELL))):
		for gz in range(int(floor(z0 / CELL)), int(ceil(z1 / CELL))):
			if (gx + gz) & 1 == 0:
				continue
			var cx0: = maxf(gx * CELL, x0)
			var cz0: = maxf(gz * CELL, z0)
			var cx1: = minf((gx + 1) * CELL, x1)
			var cz1: = minf((gz + 1) * CELL, z1)
			if cx1 > cx0 and cz1 > cz0:
				_quad(st, [cx0, cz0, cx1 - cx0, cz1 - cz0], Y_CHECK, C_GROUND_B)



func _tufts(st: Buf, r: Array) -> void :
	var x0: = float(r[0])
	var z0: = float(r[1])
	var x1: = x0 + float(r[2])
	var z1: = z0 + float(r[3])
	var row: = 0
	var z: = z0 + 1.0
	while z < z1 - 0.5:
		var x: = x0 + 1.0 + (1.5 if row & 1 else 0.0)
		while x + 1.0 < x1:
			_quad(st, [x, z, 1.0, 0.35], Y_TUFT, C_GRASS_TUFT)
			x += 3.0
		z += 1.8
		row += 1



func _building(st: Buf, b: Array) -> void :
	var x: = float(b[0])
	var z: = float(b[1])
	var w: = float(b[2])
	var h: = float(b[3])
	var roof: Color = ROOFS[clampi(int(b[4]), 0, ROOFS.size() - 1)]
	var face: = 2.4
	_quad(st, [x + 1.2, z + 1.4, w, h], Y_SHADOW, C_SHADOW)
	_quad(st, [x, z, w, h], Y_WALL, roof.darkened(0.45))
	_quad(st, [x, z, w, h - face], Y_ROOF, roof)
	_quad(st, [x + 0.6, z + (h - face) / 2.0 - 0.25, w - 1.2, 0.5], Y_RIDGE, roof.lightened(0.3))
	_quad(st, [x + w / 2.0 - 0.9, z + h - face, 1.8, face], Y_RIDGE, C_DOOR)


func _quad(st: Buf, r: Array, y: float, col: Color) -> void :
	var x0: = float(r[0])
	var z0: = float(r[1])
	var x1: = x0 + float(r[2])
	var z1: = z0 + float(r[3])
	st.col = col.srgb_to_linear()
	for v in [Vector3(x0, y, z0), Vector3(x1, y, z0), Vector3(x1, y, z1), Vector3(x0, y, z0), Vector3(x1, y, z1), Vector3(x0, y, z1)]:
		st.add(v)



func _seg(st: Buf, l: Array, w: float, y: float, col: Color) -> void :
	var a: = Vector2(float(l[0]), float(l[1]))
	var b: = Vector2(float(l[2]), float(l[3]))
	var dir: = b - a
	if dir.length() < 0.01:
		return
	var n: = Vector2( - dir.y, dir.x).normalized() * (w / 2.0)
	st.col = col.srgb_to_linear()
	for v in [a - n, a + n, b + n, a - n, b + n, b - n]:
		st.add(Vector3(v.x, y, v.y))


func _disc(st: Buf, cx: float, cz: float, r: float, y: float, col: Color) -> void :
	st.col = col.srgb_to_linear()
	var c: = Vector3(cx, y, cz)
	for i in DISC_N:
		var p0: Vector2 = DISC[i] * r
		var p1: Vector2 = DISC[i + 1] * r
		st.add(c)
		st.add(Vector3(cx + p0.x, y, cz + p0.y))
		st.add(Vector3(cx + p1.x, y, cz + p1.y))



func _draw_meals(c: Vector2, r: float) -> void :
	if meals < 0:
		return
	for i in MEAL_ANGLES.size():
		var a: = deg_to_rad(MEAL_ANGLES[i])
		var pos: = c + Vector2(sin(a), - cos(a)) * r
		_ring.draw_circle(pos, MEAL_SIZE * 0.58, Color(UiKit.SLATE_950, 0.9))
		_ring.draw_arc(pos, MEAL_SIZE * 0.58, 0.0, TAU, 24, UiKit.accent_border(), 2.0, true)
		_ring.draw_texture_rect(MEAL_FULL if i < meals else MEAL_EMPTY, Rect2(pos - Vector2.ONE * MEAL_SIZE / 2.0, Vector2.ONE * MEAL_SIZE), false)

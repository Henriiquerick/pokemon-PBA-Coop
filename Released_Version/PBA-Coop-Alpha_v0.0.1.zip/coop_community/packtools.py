"""PCK v4 append-only writer. Never mutates its source."""
import hashlib
import mmap
import struct
from pathlib import Path

ENTRY = struct.Struct('<QQ16sI')

def read_index(pack):
    if struct.unpack_from('<4s5I', pack) != (b'GDPC', 4, 4, 7, 1, 2):
        raise ValueError('PCK incompatível: esperado formato 4, Godot 4.7, flags 2')
    base, directory = struct.unpack_from('<QQ', pack, 24)
    count, = struct.unpack_from('<I', pack, directory)
    cursor = directory + 4
    index = {}
    for _ in range(count):
        length, = struct.unpack_from('<I', pack, cursor)
        cursor += 4
        name = pack[cursor:cursor + length]
        cursor += length
        record = ENTRY.unpack_from(pack, cursor)
        cursor += ENTRY.size
        path = name.rstrip(b'\0').decode('utf8')
        if path in index:
            raise ValueError('Entrada duplicada no PCK')
        index[path] = (name, record)
    return base, index

def resource(pack, base, index, path):
    _, (offset, size, digest, flags) = index[path]
    if flags or base + offset + size > len(pack):
        raise ValueError('Entrada incompatível: ' + path)
    data = pack[base + offset:base + offset + size]
    if hashlib.md5(data).digest() != digest:
        raise ValueError('MD5 inválido: ' + path)
    return data

def sha256(path):
    with Path(path).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()

def patch(source, output, changes):
    source, output = Path(source), Path(output)
    if source.resolve() == output.resolve():
        raise ValueError('O arquivo de entrada deve ser preservado')
    with source.open('rb') as f, mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ) as pack:
        base, index = read_index(pack)
        with output.open('xb') as dst:
            dst.write(pack)
            for path, data in changes.items():
                dst.write(b'\0' * (-dst.tell() % 16))
                offset = dst.tell() - base
                dst.write(data)
                name = path.encode('utf8') + b'\0'
                name += b'\0' * (-len(name) % 4)
                index[path] = (name, (offset, len(data), hashlib.md5(data).digest(), 0))
            dst.write(b'\0' * (-dst.tell() % 16))
            directory = dst.tell()
            dst.write(struct.pack('<I', len(index)))
            for name, record in index.values():
                dst.write(struct.pack('<I', len(name)))
                dst.write(name)
                dst.write(ENTRY.pack(*record))
            dst.seek(32)
            dst.write(struct.pack('<Q', directory))
    with output.open('rb') as f, mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ) as result:
        base, index = read_index(result)
        for path, expected in changes.items():
            if resource(result, base, index, path) != expected:
                raise ValueError('Falha na verificação: ' + path)

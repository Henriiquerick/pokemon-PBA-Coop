extends Node




const PokemonSprites: = preload("res://scripts/pokemon_sprites.gd")
const CreatureDef: = preload("res://scripts/creature.gd")
const MonScript: = preload("res://scripts/stats/mon.gd")
const Daycare: = preload("res://scripts/daycare.gd")
const TrainerLevel: = preload("res://scripts/stats/trainer_level.gd")
const BreederLevel: = preload("res://scripts/stats/breeder_level.gd")
const CompanionActionsScript: = preload("res://scripts/companion_actions.gd")
const PicnicScript: = preload("res://scripts/world/picnic.gd")
const ItemPickupScript: = preload("res://scripts/world/item_pickup.gd")
const CaptureFX: = preload("res://scripts/capture_fx.gd")
const GameStateScript: = preload("res://scripts/state/game_state.gd")
const DexData: = preload("res://scripts/dex.gd")
const EvolutionScript: = preload("res://scripts/evolution.gd")


const ControlsScript: = preload("res://scripts/controls.gd")




static var daily_build: = OS.has_feature("daily_tower_build") or "--daily" in OS.get_cmdline_user_args() + OS.get_cmdline_args()

const MAX_PARTY: = 6

const ITEM_CD: = 3.0

const PET_GAIN: = 6
const FEED_GAIN: = 8
const PET_CD: = 60.0
const FEED_CD: = 90.0
const PASSIVE_TICK_S: = 10.0
const PASSIVE_GAIN: = 1
const FAINT_LOSS: = 20

const ACT_PICK_S: = 0.5
const RING_RADIUS: = 1.8
const RING_COME_RADIUS: = 1.2
const RING_RAIN_RADIUS: = 0.8
const RAIN_WET: = 0.4



const FETCH_LEAD: = 0.5
const FETCH_ARRIVE: = 1.0
const FETCH_BERRY_M: = 0.3


const FETCH_EXCLAIM_S: = 1.8
const BUMP_RANGE: = 0.55


const RECALL_SECS: = 0.45
const WORLD_SCENE: = "res://scenes/world/overworld.tscn"



const CHECKPOINTS: = {
	"remember_move": {"label": "N102 Remember Move", "spawn": "vc_center", "trainer_level": 15, 
		"party": [["Charmander", 20, ["scratch"]], 
			["Charmeleon", 25, ["scratch", "growl", "smokescreen", "rage"]], ["Ditto", 10], 
			["Arcanine", 40, ["ember"]]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex"], 
		"bag": {"tiny_mushroom": 4, "big_mushroom": 2}}, 


	"route23": {"label": "Route 23 / League gate (8 badges)", "spawn": "r22_gate", "trainer_level": 15, 
		"party": [["Blastoise", 58, ["hydro_pump", "ice_beam", "bite", "earthquake"]], 
			["Charizard", 58, ["flamethrower", "aerial_ace", "dragon_claw", "earthquake"]], 
			["Venusaur", 58, ["giga_drain", "sludge_bomb", "sleep_powder", "earthquake"]], 
			["Pikachu", 56, ["thunderbolt", "thunder_wave", "quick_attack", "iron_tail"]]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", 
			"thunder_badge", "rainbow_badge", "soul_badge", "marsh_badge", "volcano_badge", "earth_badge"], 
		"bag": {"hyper_potion": 20, "revive": 10, "full_heal": 10, "ultra_ball": 20}}, 

	"indigo_plateau": {"label": "Indigo Plateau (League city)", "spawn": "ip_vr_exit", "trainer_level": 15, 
		"party": [["Blastoise", 58, ["hydro_pump", "ice_beam", "bite", "earthquake"]], 
			["Machoke", 56, ["cross_chop", "rock_slide", "earthquake", "bulk_up"]], 
			["Charizard", 58, ["flamethrower", "aerial_ace", "dragon_claw", "earthquake"]], 
			["Pikachu", 56, ["thunderbolt", "thunder_wave", "quick_attack", "iron_tail"]]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", 
			"thunder_badge", "rainbow_badge", "soul_badge", "marsh_badge", "volcano_badge", "earth_badge"], 
		"bag": {"hyper_potion": 20, "revive": 10, "full_heal": 10, "ultra_ball": 20}}, 

	"league": {"label": "Pokémon League hall (tournament)", "scene": "res://scenes/interiors/indigo_plateau_interiors.tscn", 
		"spawn": "ip_league_in", "trainer_level": 15, 
		"party": [["Blastoise", 62, ["hydro_pump", "ice_beam", "bite", "earthquake"]], 
			["Machamp", 60, ["cross_chop", "rock_slide", "earthquake", "bulk_up"]], 
			["Charizard", 62, ["flamethrower", "aerial_ace", "dragon_claw", "earthquake"]], 
			["Raichu", 60, ["thunderbolt", "thunder_wave", "quick_attack", "iron_tail"]], 
			["Alakazam", 60, ["psychic", "thunder_wave", "recover", "shadow_ball"]], 
			["Snorlax", 61, ["body_slam", "earthquake", "rest", "shadow_ball"]]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", 
			"thunder_badge", "rainbow_badge", "soul_badge", "marsh_badge", "volcano_badge", "earth_badge"], 
		"bag": {"hyper_potion": 20, "revive": 10, "full_heal": 10}}, 


	"league_final": {"label": "Pokémon League hall (final next)", "scene": "res://scenes/interiors/indigo_plateau_interiors.tscn", 
		"spawn": "ip_league_gate", "trainer_level": 15, "league_round": 3, 
		"party": [["Blastoise", 62, ["hydro_pump", "ice_beam", "bite", "earthquake"]], 
			["Machamp", 60, ["cross_chop", "rock_slide", "earthquake", "bulk_up"]], 
			["Charizard", 62, ["flamethrower", "aerial_ace", "dragon_claw", "earthquake"]], 
			["Raichu", 60, ["thunderbolt", "thunder_wave", "quick_attack", "iron_tail"]], 
			["Alakazam", 60, ["psychic", "thunder_wave", "recover", "shadow_ball"]], 
			["Snorlax", 61, ["body_slam", "earthquake", "rest", "shadow_ball"]]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", 
			"thunder_badge", "rainbow_badge", "soul_badge", "marsh_badge", "volcano_badge", "earth_badge"], 
		"bag": {"hyper_potion": 20, "revive": 10, "full_heal": 10}}, 

	"league_cup": {"label": "Pokémon League hall (champion, Masters Cup)", "scene": "res://scenes/interiors/indigo_plateau_interiors.tscn", 
		"spawn": "ip_league_in", "trainer_level": 15, 
		"party": [["Blastoise", 62, ["hydro_pump", "ice_beam", "bite", "earthquake"]], 
			["Machamp", 60, ["cross_chop", "rock_slide", "earthquake", "bulk_up"]], 
			["Charizard", 62, ["flamethrower", "aerial_ace", "dragon_claw", "earthquake"]], 
			["Raichu", 60, ["thunderbolt", "thunder_wave", "quick_attack", "iron_tail"]], 
			["Alakazam", 60, ["psychic", "thunder_wave", "recover", "shadow_ball"]], 
			["Snorlax", 61, ["body_slam", "earthquake", "rest", "shadow_ball"]]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", 
			"thunder_badge", "rainbow_badge", "soul_badge", "marsh_badge", "volcano_badge", "earth_badge", "league_champion"], 
		"bag": {"hyper_potion": 20, "revive": 10, "full_heal": 10}}, 

	"league_arena": {"label": "Pokémon League arena (walk-in with Blue)", "scene": "res://scenes/interiors/indigo_plateau_interiors.tscn", 
		"spawn": "ip_arena_in", "trainer_level": 15, 
		"party": [["Blastoise", 62, ["hydro_pump", "ice_beam", "bite", "earthquake"]], 
			["Charizard", 62, ["flamethrower", "aerial_ace", "dragon_claw", "earthquake"]], 
			["Alakazam", 60, ["psychic", "thunder_wave", "recover", "shadow_ball"]]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", 
			"thunder_badge", "rainbow_badge", "soul_badge", "marsh_badge", "volcano_badge", "earth_badge"]}, 


	"victory_road": {"label": "Victory Road 1F (Strength puzzles)", "spawn": "vr_1f_in", 
		"scene": "res://scenes/interiors/victory_road_interiors.tscn", "trainer_level": 15, 
		"party": [["Blastoise", 58, ["hydro_pump", "ice_beam", "bite", "earthquake"]], 
			["Machoke", 56, ["cross_chop", "rock_slide", "earthquake", "bulk_up"]], 
			["Charizard", 58, ["flamethrower", "aerial_ace", "dragon_claw", "earthquake"]], 
			["Pikachu", 56, ["thunderbolt", "thunder_wave", "quick_attack", "iron_tail"]]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", 
			"thunder_badge", "rainbow_badge", "soul_badge", "marsh_badge", "volcano_badge", "earth_badge"], 
		"bag": {"hyper_potion": 20, "revive": 10, "full_heal": 10, "ultra_ball": 20}}, 


	"victory_road_2f": {"label": "Victory Road 2F (after the 3F boulder drop)", "spawn": "vr_2f_from_hole", 
		"scene": "res://scenes/interiors/victory_road_interiors.tscn", "trainer_level": 15, 
		"party": [["Blastoise", 58, ["hydro_pump", "ice_beam", "bite", "earthquake"]], 
			["Machoke", 56, ["cross_chop", "rock_slide", "earthquake", "bulk_up"]], 
			["Charizard", 58, ["flamethrower", "aerial_ace", "dragon_claw", "earthquake"]], 
			["Pikachu", 56, ["thunderbolt", "thunder_wave", "quick_attack", "iron_tail"]]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", 
			"thunder_badge", "rainbow_badge", "soul_badge", "marsh_badge", "volcano_badge", "earth_badge", 
			"vr_1f_switch_1", "vr_2f_switch_1", "vr_3f_switch_1", "vr_3f_boulder_dropped"], 
		"bag": {"hyper_potion": 20, "revive": 10, "full_heal": 10, "ultra_ball": 20}}, 
	"victory_road_exit": {"label": "Victory Road 2F exit (-> Indigo Plateau)", "spawn": "vr_2f_exit_in", 
		"scene": "res://scenes/interiors/victory_road_interiors.tscn", "trainer_level": 15, 
		"party": [["Blastoise", 58, ["hydro_pump", "ice_beam", "bite", "earthquake"]], 
			["Machoke", 56, ["cross_chop", "rock_slide", "earthquake", "bulk_up"]], 
			["Charizard", 58, ["flamethrower", "aerial_ace", "dragon_claw", "earthquake"]], 
			["Pikachu", 56, ["thunderbolt", "thunder_wave", "quick_attack", "iron_tail"]]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", 
			"thunder_badge", "rainbow_badge", "soul_badge", "marsh_badge", "volcano_badge", "earth_badge", 
			"vr_1f_switch_1", "vr_2f_switch_1", "vr_3f_switch_1", "vr_3f_boulder_dropped"], 
		"bag": {"hyper_potion": 20, "revive": 10, "full_heal": 10, "ultra_ball": 20}}, 
	"silph_co": {"label": "Silph Co. / reception", "spawn": "silph_1f_in", 
		"scene": "res://scenes/interiors/silph_co_interiors.tscn", "trainer_level": 15, 
		"party": [["Charizard", 60], ["Pikachu", 60], ["Blastoise", 60], ["Venusaur", 60]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", 
			"thunder_badge", "rainbow_badge", "soul_badge", "marsh_badge", "volcano_badge", "earth_badge", 
			"gyarados_done", "cape_scene_seen"], 
		"bag": {"hyper_potion": 30, "revive": 15, "full_heal": 15, 
			"silph_key_red": 1, "silph_key_blue": 1, "silph_key_gold": 1}}, 

	"silph_10f": {"label": "Silph Co. / 10F (executive lift, keys)", "spawn": "silph_10f_exec", 
		"scene": "res://scenes/interiors/silph_co_interiors.tscn", "trainer_level": 15, 
		"party": [["Charizard", 60], ["Pikachu", 60], ["Blastoise", 60], ["Venusaur", 60]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", 
			"thunder_badge", "rainbow_badge", "soul_badge", "marsh_badge", "volcano_badge", "earth_badge", 
			"gyarados_done", "cape_scene_seen"], 
		"bag": {"hyper_potion": 30, "revive": 15, "full_heal": 15, 
			"silph_key_red": 1, "silph_key_blue": 1, "silph_key_gold": 1}}, 

	"silph_revisit": {"label": "Silph Co. / 11F revisit (finale won)", "spawn": "ElevatorArrival", 
		"scene": "res://scenes/interiors/saffron/SilphFinalFloor.tscn", "trainer_level": 15, 
		"party": [["Charizard", 60], ["Pikachu", 60]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", 
			"gyarados_done", "cape_scene_seen", "thunder_badge", "rainbow_badge", "soul_badge", "marsh_badge", 
			"volcano_badge", "earth_badge", "silph_finale_won"], 
		"bag": {"hyper_potion": 10, "revive": 6, "full_heal": 10}}, 
	"silph_finale": {"label": "Silph Co. finale", "spawn": "ElevatorArrival", 
		"scene": "res://scenes/interiors/saffron/SilphFinalFloor.tscn", "trainer_level": 15, 
		"party": [["Charizard", 60], ["Pikachu", 60]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", 
			"gyarados_done", "cape_scene_seen", 
			"thunder_badge", "rainbow_badge", "soul_badge", "marsh_badge", "volcano_badge", "earth_badge"], 
		"bag": {"hyper_potion": 10, "revive": 6, "full_heal": 10}}, 
	"silph_battle": {"label": "Silph Co. / legendary battle ready", "spawn": "RooftopBattleArrival", 
		"scene": "res://scenes/interiors/saffron/SilphFinalFloor.tscn", "trainer_level": 15, 
		"party": [["Charizard", 60], ["Pikachu", 60]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", 
			"gyarados_done", "cape_scene_seen", "thunder_badge", "rainbow_badge", "soul_badge", 
			"marsh_badge", "volcano_badge", "earth_badge", "_silph_battle_checkpoint"], 
		"bag": {"hyper_potion": 10, "revive": 6, "full_heal": 10}}, 

	"held_berries": {"label": "Held berry assignment", "spawn": "vc_center", 
		"party": [["Bulbasaur", 12], ["Pikachu", 12]], "flags": ["has_pokedex"], 
		"bag": {"oran_berry": 5, "sitrus_berry": 5, "pecha_berry": 5, "persim_berry": 5, 
			"cheri_berry": 5, "chesto_berry": 5, "rawst_berry": 5, "lum_berry": 5, 
			"leppa_berry": 5, "razz_berry": 3, "bluk_berry": 3, "nanab_berry": 3, 
			"pinap_berry": 3, "potion": 3, "poke_ball": 5}}, 
	"route1": {"label": "Route 1", "spawn": "r1_south", "party": [["Bulbasaur", 8], ["Pidgey", 6]]}, 

	"friend_ball": {"label": "Friend catch prompt (Route 1)", "spawn": "r1_south", "trainer_level": 15, 
		"party": [["Bulbasaur", 8], ["Pidgey", 6]], "friends": [["Caterpie", 4, 70]], 
		"bag": {"poke_ball": 3, "great_ball": 3, "ultra_ball": 3, "master_ball": 1, "potion": 3}}, 

	"zoom": {"label": "B145 camera zoom (Route 1, big team)", "spawn": "r1_south", "trainer_level": 15, 
		"party": [["Onix", 30], ["Venusaur", 30], ["Snorlax", 30], ["Pidgey", 30]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge"], 
		"bag": {"potion": 5, "poke_ball": 10}}, 

	"forest_big": {"label": "Viridian Forest (big team, cast scale)", "spawn": "vf_south", "trainer_level": 15, 
		"party": [["Blastoise", 30], ["Charizard", 30], ["Venusaur", 30], ["Pikachu", 30]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex"], 
		"bag": {"potion": 5, "poke_ball": 10}}, 


	"lab_rival": {"label": "Pallet morning — Oak stop, starter, rival fight", "spawn": "start", 
		"party": [], "flags": ["night_prologue_done"], 
		"unset_flags": ["oak_stopped", "starter_chosen", "rival_battle_done", "rival_battle_won", "rival_starter"]}, 

	"loadouts": {"label": "N79 two loadouts (Route 1)", "spawn": "r1_south", 
		"party": [["Clefable", 26, ["pound", "sing", "double_slap", "mega_punch"], ["thunderbolt", "ice_beam", "psychic", "toxic"]], 
			["Pikachu", 20, ["thunder_shock", "quick_attack", "thunder_wave", "double_team"], ["slam", "swift", "agility", "thunderbolt"]]]}, 

	"route1_starters": {"label": "Route 1 (3 starter lv 5)", "spawn": "r1_south", 
		"party": [["Bulbasaur", 5], ["Squirtle", 5], ["Charmander", 5]]}, 

	"mount": {"label": "N98 cavalcature (Route 1)", "spawn": "r1_south", 
		"party": [["Rapidash", 25], ["Arcanine", 25], ["Pidgeot", 25], ["Rhyhorn", 20], ["Bulbasaur", 10]], 
		"bag": {"potion": 5}}, 
	"picnic": {"label": "N96: picnic cooking", "spawn": "r1_south", "breeder_level": 3, 
		"party": [["Bulbasaur", 5], ["Charmander", 5], ["Squirtle", 5], ["Pikachu", 5]], 
		"bag": {"rice": 12, "salt": 6, "spices": 6, "bitter_herbs": 12, "honey": 6, "milk": 6, 
			"tiny_mushroom": 12, "big_mushroom": 6, "oran_berry": 20, "cheri_berry": 20, 
			"pecha_berry": 20, "sitrus_berry": 20, "chesto_berry": 20, "rawst_berry": 20}}, 
	"gust_route1": {"label": "Route 1 Gust play-test", "spawn": "r1_road", 
		"party": [["Rattata", 10], ["Charmander", 10]], "bag": {"potion": 5, "poke_ball": 5}}, 
	"route1_from_pallet": {"label": "Route 1 da Pallet — Bulbasaur Lv6", "spawn": "start", 
		"party": [["Bulbasaur", 6]], "trainer_level": 15, 
		"flags": ["night_prologue_done", "starter_chosen", "has_pokedex"], 
		"bag": {"potion": 3, "poke_ball": 5}}, 
	"route1_landscape": {"label": "Route 1 — prati e radura", "spawn": "r1_boss_approach", 
		"party": [["Wartortle", 12], ["Pidgeotto", 11]], "trainer_level": 15, 
		"flags": ["night_prologue_done", "starter_chosen", "has_pokedex"], 
		"bag": {"potion": 10, "poke_ball": 10}}, 
	"raticate": {"label": "Route 1 Raticate boss", "spawn": "r1_hilltop", 
		"party": [["Charmander", 10], ["Rattata", 8]], "bag": {"potion": 5, "poke_ball": 5}}, 
	"viridian": {"label": "Viridian City", "spawn": "vc_center", "party": [["Charmander", 10], ["Rattata", 8]]}, 


	"fish": {"label": "N100 pesci fuori dalla ball (Viridian)", "spawn": "vc_pond", 
		"party": [["Goldeen", 12], ["Seaking", 12], ["Squirtle", 12], ["Magikarp", 12]], 
		"flags": ["has_pokedex"], "bag": {"potion": 3}}, 
	"viridian_pond": {"label": "Viridian pond water combat play-test", "spawn": "vc_pond", 
		"party": [["Wartortle", 16, ["tackle", "bubble", "water_gun"]], ["Blastoise", 36, ["tackle", "bubble", "water_gun"]], 
			["Squirtle", 7, ["tackle", "bubble", "water_gun"]], ["Poliwag", 5, ["tackle", "bubble", "water_gun"]]], 
		"trainer_level": 15, "time": "09:00", 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex"], "bag": {"potion": 10}}, 

	"surf": {"label": "N101 surf (Viridian)", "spawn": "vc_pond", 
		"party": [["Seaking", 14], ["Nidoking", 14], ["Blastoise", 14], ["Squirtle", 12]], 
		"flags": ["has_pokedex"], "bag": {"potion": 3}}, 

	"poliwrath_surf": {"label": "Poliwrath water ride (Viridian pond, Fuchsia)", "spawn": "vc_pond", 
		"party": [["Poliwrath", 30], ["Seadra", 30], ["Kingdra", 30], ["Horsea", 25], ["Blastoise", 30]], 
		"trainer_level": 15, 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", 
			"thunder_badge", "rainbow_badge", "soul_badge"], 
		"bag": {"potion": 5, "poke_ball": 5}}, 
	"viridian_magikarp": {"label": "Viridian Magikarp land play-test", "spawn": "vc_center", 
		"party": [["Magikarp", 10], ["Charmander", 10]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex"], "bag": {"potion": 3}}, 

	"viridian_full": {"label": "Viridian City (6 party + 6 box)", "spawn": "vc_center", 
		"party": [["Charmander", 14], ["Pidgey", 12], ["Rattata", 11], ["Pikachu", 13], ["Bulbasaur", 12], ["Squirtle", 12]], 
		"box": [["Caterpie", 6], ["Weedle", 6], ["Spearow", 7], ["Nidoran M", 8], ["Mankey", 9], ["Oddish", 8]], 
		"flags": ["has_pokedex"], "bag": {"potion": 5, "super_potion": 2, "antidote": 3, "poke_ball": 10}}, 

	"camp": {"label": "Viridian Training Camp", "spawn": "vc_camp", 
		"party": [["Charmander", 10], ["Rattata", 8], ["Pidgey", 6]], "bag": {"potion": 3, "poke_ball": 5}}, 
	"cooldown_test": {"label": "Switch cooldown play-test", "spawn": "vc_camp", 
		"party": [["Geodude", 15, ["rock_tomb", "hyper_beam", "tackle", "defense_curl"]], ["Charmander", 15], ["Pidgey", 15]], 
		"bag": {"potion": 10, "poke_ball": 5}}, 
	"pewter_camp": {"label": "Pewter Training Camp", "spawn": "pw_camp", 
		"party": [["Charmander", 14], ["Pidgey", 12], ["Mankey", 11]], "bag": {"potion": 3, "poke_ball": 5}}, 

	"daily": {"label": "Daily Tower", "spawn": "vm_daily_in", 
		"scene": "res://scenes/interiors/vermilion_interiors.tscn", 
		"party": [["Pikachu", 20], ["Bulbasaur", 20]]}, 

	"viridian_center": {"label": "Viridian Pokémon Center (Cable Club)", "spawn": "vc_center_in", 
		"scene": "res://scenes/interiors/viridian_city_interiors.tscn", 
		"party": [["Charmander", 10], ["Rattata", 8], ["Pidgey", 6], ["Rattata", 5]]}, 
	"viridian_parcel": {"label": "Viridian (parcel)", "spawn": "vc_center", "party": [["Charmander", 10], ["Rattata", 8]], "bag": {"potion": 3}}, 
	"route2_trainers": {"label": "Route 2 — south trainer trial", "spawn": "r2_trainer_trial", 
		"party": [["Bulbasaur", 10], ["Pidgey", 9], ["Rattata", 8]], 
		"flags": ["night_prologue_done", "starter_chosen", "has_parcel", "parcel_delivered", "has_pokedex"], 
		"bag": {"potion": 6, "poke_ball": 5}}, 
	"route2": {"label": "Route 2", "spawn": "vc_north", "party": [["Charmander", 10], ["Rattata", 8]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex"], "bag": {"potion": 3, "poke_ball": 5}}, 


	"r2_trainers": {"label": "Route 2 (first trainers)", "spawn": "r2_square", 
		"party": [["Charmander", 14], ["Rattata", 12]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex"], "bag": {"potion": 5, "poke_ball": 5}}, 


	"r2_rematch": {"label": "Route 2 (rematches)", "spawn": "r2_square", 
		"party": [["Charmander", 17], ["Rattata", 17]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "trainer_bug_catcher_drew", 
			"trainer_youngster_ryan", "trainer_youngster_dane", "trainer_lass_faye"], 
		"bag": {"potion": 5, "poke_ball": 5}}, 

	"forest_rematch": {"label": "Viridian Forest (rematches)", "spawn": "vf_south", 
		"party": [["Charmander", 17], ["Rattata", 17]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "trainer_bug_catcher_rick", 
			"trainer_bug_catcher_doug", "trainer_bug_catcher_anthony", "trainer_bug_catcher_charlie", 
			"trainer_bug_catcher_sammy"], 
		"bag": {"potion": 5, "poke_ball": 5}}, 
	"forest": {"label": "Viridian Forest", "spawn": "vf_south", "party": [["Charmander", 12], ["Rattata", 10]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex"], "bag": {"potion": 3, "poke_ball": 5}}, 

	"vid_caterpie": {"label": "Video: Caterpie rescue", "spawn": "vf_south", "party": [["Bulbasaur", 12], ["Pidgey", 8]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex"], "bag": {"potion": 5, "poke_ball": 10}}, 
	"vid_mtmoon_rocket": {"label": "Video: Mt. Moon Rocket", "spawn": "mm_b2f_from_grove", 
		"scene": "res://scenes/interiors/mt_moon_interiors.tscn", 
		"party": [["Bulbasaur", 20, ["vine_whip", "razor_leaf", "leech_seed", "sleep_powder"]], 
			["Butterfree", 20, ["confusion", "gust", "sleep_powder", "stun_spore"]], 
			["Pikachu", 19, ["thunder_shock", "quick_attack", "thunder_wave", "double_team"]], 
			["Mankey", 19, ["karate_chop", "low_kick", "fury_swipes", "scratch"]]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "FLAG_HIDE_MISC_KANTO_ROCKETS"], 
		"bag": {"potion": 5, "poke_ball": 5, "super_potion": 3}}, 
	"vid_misty": {"label": "Video: Misty", "spawn": "pw_gym_in", 
		"scene": "res://scenes/interiors/cerulean_interiors.tscn", 
		"party": [["Bulbasaur", 22, ["vine_whip", "razor_leaf", "leech_seed", "sleep_powder"]], 
			["Butterfree", 22, ["confusion", "gust", "sleep_powder", "stun_spore"]], 
			["Pikachu", 21, ["thunder_shock", "quick_attack", "thunder_wave", "double_team"]], 
			["Mankey", 21, ["karate_chop", "low_kick", "fury_swipes", "scratch"]]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "trainer_swimmer_luis", "trainer_picnicker_diana"], 
		"bag": {"potion": 5, "poke_ball": 5, "super_potion": 3}}, 
	"vid_ssanne": {"label": "Video: S.S. Anne cargo", "spawn": "ssa_cargo_in", 
		"scene": "res://scenes/interiors/ss_anne_interiors.tscn", 
		"party": [["Bulbasaur", 26, ["vine_whip", "razor_leaf", "leech_seed", "sleep_powder"]], 
			["Butterfree", 26, ["confusion", "gust", "sleep_powder", "stun_spore"]], 
			["Pikachu", 25, ["thunder_shock", "quick_attack", "thunder_wave", "double_team"]], 
			["Mankey", 25, ["karate_chop", "low_kick", "fury_swipes", "scratch"]]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", "gyarados_done", "cape_scene_seen", 
			"rocket_ship_1", "rocket_ship_2", "rocket_ship_3", "trainer_rocket_ship_1", 
			"trainer_rocket_ship_2", "trainer_rocket_ship_3"], 
		"bag": {"potion": 5, "poke_ball": 5, "super_potion": 3, "ss_ticket": 1}}, 
	"vid_surge_gym": {"label": "Video: Vermilion Gym", "spawn": "vm_gym_in", 
		"scene": "res://scenes/interiors/vermilion_interiors.tscn", 
		"party": [["Bulbasaur", 26, ["vine_whip", "razor_leaf", "leech_seed", "sleep_powder"]], 
			["Butterfree", 26, ["confusion", "gust", "sleep_powder", "stun_spore"]], 
			["Pikachu", 25, ["thunder_shock", "quick_attack", "thunder_wave", "double_team"]], 
			["Mankey", 25, ["karate_chop", "low_kick", "fury_swipes", "scratch"]]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", "gyarados_done", "cape_scene_seen"], 
		"bag": {"potion": 5, "poke_ball": 5, "super_potion": 3, "ss_ticket": 1}}, 
	"route2_north": {"label": "Route 2 (north, towards Pewter)", "spawn": "r2n_road", "party": [["Charmander", 14], ["Pidgey", 11]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex"], "bag": {"potion": 3, "poke_ball": 5}}, 
	"pewter": {"label": "Pewter City", "spawn": "pw_south", "party": [["Charmander", 14], ["Pidgey", 11]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex"], "bag": {"potion": 3, "poke_ball": 5}}, 
	"gym": {"label": "Pewter Gym", "spawn": "pw_gym_front", 
		"party": [["Charmander", 14], ["Mankey", 13], ["Pidgey", 12]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex"], "bag": {"potion": 3, "poke_ball": 5}}, 

	"gym_rematch": {"label": "Pewter Gym (rematches)", "spawn": "pw_gym_front", 
		"party": [["Charmeleon", 27], ["Primeape", 27], ["Pidgeotto", 27]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "trainer_camper_liam", 
			"trainer_hiker_dudley", "trainer_brock", "boulder_badge"], 
		"bag": {"potion": 5, "poke_ball": 5}}, 


	"cerulean_rival": {"label": "Cerulean City (Blue on the Bridge Square)", "spawn": "ce_rival", 
		"party": [["Charmeleon", 20], ["Pidgeotto", 18], ["Mankey", 17], ["Geodude", 16]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cerulean_gate_briefed"], 
		"bag": {"potion": 3, "poke_ball": 5, "super_potion": 1}}, 

	"cerulean_entry": {"label": "Cerulean City (arrival from Route 4)", "spawn": "ce_west", 
		"party": [["Charmeleon", 20], ["Pidgeotto", 18], ["Mankey", 17], ["Geodude", 16]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge"], 
		"bag": {"potion": 3, "poke_ball": 5, "super_potion": 1}}, 
	"cerulean": {"label": "Cerulean City", "spawn": "ce_center", 
		"party": [["Charmeleon", 20], ["Pidgeotto", 18], ["Mankey", 17], ["Geodude", 16]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cerulean_gate_briefed"], 
		"bag": {"potion": 3, "poke_ball": 5, "super_potion": 1}}, 


	"cerulean_water_lab": {"label": "Cerulean camp water lab (invincible)", "spawn": "ce_camp", "trainer_level": 15, 
		"party": [["Charmeleon", 20], ["Pidgeotto", 18], ["Mankey", 17]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cerulean_gate_briefed", 
			"water_lesson_seen", "water_lab"], 
		"bag": {"potion": 5, "poke_ball": 5, "super_potion": 3}}, 

	"cerulean_camp": {"label": "Cerulean water camp (fire type)", "spawn": "ce_camp", "trainer_level": 15, 
		"party": [["Charmeleon", 20], ["Pidgeotto", 18], ["Mankey", 17]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cerulean_gate_briefed"], 
		"bag": {"potion": 5, "poke_ball": 5, "super_potion": 3}}, 

	"cerulean_badge": {"label": "Cerulean (Cascade Badge)", "spawn": "ce_house2_front", 
		"party": [["Charmeleon", 20], ["Pidgeotto", 18], ["Mankey", 17], ["Geodude", 16]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", "gyarados_done", "cape_scene_seen"], 
		"bag": {"potion": 3, "poke_ball": 5, "super_potion": 1}}, 

	"cerulean_pocket": {"label": "Cerulean (Rocket pocket)", "spawn": "ce_pocket", 
		"party": [["Charmeleon", 20], ["Pidgeotto", 18], ["Mankey", 17], ["Geodude", 16]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", "gyarados_done", "cape_scene_seen"], 
		"bag": {"potion": 3, "poke_ball": 5, "super_potion": 1}}, 

	"cerulean_ready": {"label": "Cerulean City (strong team)", "spawn": "ce_center", 
		"party": [["Charizard", 30], ["Alakazam", 27], ["Gyarados", 27], ["Raichu", 26], ["Nidoking", 27], ["Snorlax", 28]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", "gyarados_done", "cape_scene_seen"], 
		"bag": {"super_potion": 8, "revive": 2, "poke_ball": 20, "antidote": 3, "repel": 2}}, 



	"bike_shop": {"label": "Cerulean BIKE SHOP (no voucher)", "spawn": "ce_bike_in", "trainer_level": 15, 
		"scene": "res://scenes/interiors/cerulean_interiors.tscn", 
		"party": [["Charmeleon", 20], ["Pidgeotto", 18], ["Mankey", 17], ["Geodude", 16]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge"], 
		"bag": {"potion": 3, "poke_ball": 5, "super_potion": 1}}, 

	"bike": {"label": "Cerulean BIKE SHOP (BICYCLE to register)", "spawn": "ce_bike_in", "trainer_level": 15, 
		"scene": "res://scenes/interiors/cerulean_interiors.tscn", 
		"party": [["Charmeleon", 20], ["Pidgeotto", 18], ["Mankey", 17], ["Geodude", 16]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge"], 
		"bag": {"bicycle": 1, "potion": 3, "poke_ball": 5, "super_potion": 1}}, 
	"cerulean_gym": {"label": "Cerulean Gym", "spawn": "pw_gym_in", 
		"scene": "res://scenes/interiors/cerulean_interiors.tscn", 
		"party": [["Charmeleon", 18], ["Pidgeotto", 17], ["Mankey", 16], ["Geodude", 15], ["Squirtle", 15]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge"], 
		"bag": {"potion": 3, "poke_ball": 5, "super_potion": 1}}, 

	"cerulean_gym_misty": {"label": "Cerulean Gym — Misty ready", "spawn": "pw_gym_in", 
		"scene": "res://scenes/interiors/cerulean_interiors.tscn", "trainer_level": 15, 
		"party": [["Charmeleon", 22], ["Pikachu", 21], ["Bulbasaur", 22], ["Mankey", 21], ["Geodude", 20]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", 
			"gyarados_done", "cape_scene_seen", "trainer_swimmer_luis", "trainer_picnicker_diana"], 
		"bag": {"potion": 5, "poke_ball": 5, "super_potion": 3}}, 


	"vermilion_ready": {"label": "Vermilion City (strong team + S.S. Ticket)", "spawn": "vm_north", 
		"party": [["Charizard", 30], ["Alakazam", 27], ["Gyarados", 27], ["Raichu", 26], ["Nidoking", 27], ["Snorlax", 28]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", "gyarados_done", "cape_scene_seen"], 
		"bag": {"super_potion": 8, "revive": 2, "poke_ball": 20, "antidote": 3, "repel": 2, "ss_ticket": 1}}, 

	"vm_trade": {"label": "Vermilion House 2 (Spearow -> Farfetch'd trade)", "spawn": "vm_house2_in", 
		"scene": "res://scenes/interiors/vermilion_interiors.tscn", 
		"party": [["Spearow", 20], ["Pikachu", 20], ["Charmeleon", 22]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", "thunder_badge", "gyarados_done", "cape_scene_seen"], 
		"bag": {"potion": 3, "poke_ball": 5, "super_potion": 1, "ss_ticket": 1}}, 

	"vermilion": {"label": "Vermilion City", "spawn": "vm_north", 
		"party": [["Charmeleon", 22], ["Pidgeotto", 20], ["Mankey", 19], ["Geodude", 18], ["Squirtle", 18]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", "gyarados_done", "cape_scene_seen"], 
		"bag": {"potion": 3, "poke_ball": 5, "super_potion": 1, "ss_ticket": 1}}, 
	"fuchsia_green": {"label": "Fuchsia City (the thief's warning at the gate)", "spawn": "fc_west", 
		"party": [["Charmeleon", 30], ["Pidgeotto", 28], ["Mankey", 26], ["Geodude", 25], ["Squirtle", 25]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", "thunder_badge", "gyarados_done", "cape_scene_seen", "starter_stolen", "vermilion_green_done"], 
		"bag": {"potion": 3, "poke_ball": 5, "super_potion": 1}}, 
	"cinnabar_green": {"label": "Cinnabar Island (the thief opens Saffron's gates)", "spawn": "cn_center", 
		"party": [["Charmeleon", 38], ["Pidgeotto", 36], ["Mankey", 34], ["Geodude", 33], ["Squirtle", 33]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", "thunder_badge", "rainbow_badge", "soul_badge", "volcano_badge", "gyarados_done", "cape_scene_seen", "blaine_lab_done", "starter_stolen", "vermilion_green_done", "fuchsia_green_met"], 
		"bag": {"potion": 3, "poke_ball": 5, "super_potion": 1, "great_ball": 3}}, 
	"vermilion_green": {"label": "Vermilion City (the starter thief at the gangway)", "spawn": "vm_plaza_n", 
		"party": [["Charmeleon", 22], ["Pidgeotto", 20], ["Mankey", 19], ["Geodude", 18], ["Squirtle", 18]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", "gyarados_done", "cape_scene_seen", "starter_stolen"], 
		"bag": {"potion": 3, "poke_ball": 5, "super_potion": 1, "ss_ticket": 1}}, 

	"celadon_city": {"label": "Celadon City", "spawn": "cc_east", 
		"party": [["Charmeleon", 26], ["Pidgeotto", 24], ["Mankey", 22], ["Geodude", 21], ["Squirtle", 21]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", "gyarados_done", "cape_scene_seen"], 
		"bag": {"potion": 3, "poke_ball": 5, "super_potion": 1, "ss_ticket": 1}}, 

	"route_7": {"label": "Route 7", "spawn": "r7_grass", 
		"party": [["Charmeleon", 26], ["Pidgeotto", 24], ["Mankey", 22], ["Geodude", 21], ["Squirtle", 21]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", "gyarados_done", "cape_scene_seen"], 
		"bag": {"potion": 3, "poke_ball": 5, "super_potion": 1, "ss_ticket": 1}}, 

	"saffron_north_gate": {"label": "Saffron north gate", "spawn": "r5_gate_door", 
		"party": [["Charizard", 44], ["Pidgeot", 42], ["Primeape", 40], ["Golem", 40], ["Blastoise", 42]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", "thunder_badge", "rainbow_badge", "soul_badge", "volcano_badge", "gyarados_done", "cape_scene_seen", "blaine_lab_done", "starter_stolen", "vermilion_green_done", "fuchsia_green_met", "cinnabar_green_met", "saffron_open"], 
		"bag": {"potion": 3, "poke_ball": 5}}, 
	"saffron_south_gate": {"label": "Saffron south gate", "spawn": "r6_gate_door", 
		"party": [["Charizard", 44], ["Pidgeot", 42], ["Primeape", 40], ["Golem", 40], ["Blastoise", 42]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", "thunder_badge", "rainbow_badge", "soul_badge", "volcano_badge", "gyarados_done", "cape_scene_seen", "blaine_lab_done", "starter_stolen", "vermilion_green_done", "fuchsia_green_met", "cinnabar_green_met", "saffron_open"], 
		"bag": {"potion": 3, "poke_ball": 5}}, 
	"saffron_west_gate": {"label": "Saffron west gate", "spawn": "r7_gate_door", 
		"party": [["Charizard", 44], ["Pidgeot", 42], ["Primeape", 40], ["Golem", 40], ["Blastoise", 42]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", "thunder_badge", "rainbow_badge", "soul_badge", "volcano_badge", "gyarados_done", "cape_scene_seen", "blaine_lab_done", "starter_stolen", "vermilion_green_done", "fuchsia_green_met", "cinnabar_green_met", "saffron_open"], 
		"bag": {"potion": 3, "poke_ball": 5}}, 
	"saffron_east_gate": {"label": "Saffron east gate", "spawn": "r8_gate_door", 
		"party": [["Charizard", 44], ["Pidgeot", 42], ["Primeape", 40], ["Golem", 40], ["Blastoise", 42]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", "thunder_badge", "rainbow_badge", "soul_badge", "volcano_badge", "gyarados_done", "cape_scene_seen", "blaine_lab_done", "starter_stolen", "vermilion_green_done", "fuchsia_green_met", "cinnabar_green_met", "saffron_open"], 
		"bag": {"potion": 3, "poke_ball": 5}}, 

	"saffron_city": {"label": "Saffron City", "spawn": "sf_plaza", 
		"party": [["Charizard", 44], ["Pidgeot", 42], ["Primeape", 40], ["Golem", 40], ["Blastoise", 42]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", "thunder_badge", "rainbow_badge", "soul_badge", "volcano_badge", "gyarados_done", "cape_scene_seen", "blaine_lab_done", "starter_stolen", "vermilion_green_done", "fuchsia_green_met", "cinnabar_green_met", "saffron_open"], 
		"bag": {"potion": 3, "poke_ball": 5, "super_potion": 1, "ss_ticket": 1}}, 

	"ss_anne_cargo": {"label": "S.S. Anne cargo hold", "spawn": "ssa_cargo_in", 
		"scene": "res://scenes/interiors/ss_anne_interiors.tscn", 
		"party": [["Charmeleon", 24], ["Pidgeotto", 22], ["Mankey", 21], ["Geodude", 20], ["Squirtle", 20]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", "gyarados_done", "cape_scene_seen", 
			"rocket_ship_1", "rocket_ship_2", "rocket_ship_3", "trainer_rocket_ship_1", 
			"trainer_rocket_ship_2", "trainer_rocket_ship_3"], 
		"bag": {"potion": 3, "poke_ball": 5, "super_potion": 1, "ss_ticket": 1}}, 

	"ss_anne_release": {"label": "S.S. Anne cargo hold (all grunts down: release + Mewtwo escape)", "spawn": "ssa_cargo_in", 
		"scene": "res://scenes/interiors/ss_anne_interiors.tscn", 
		"party": [["Charmeleon", 24], ["Pidgeotto", 22], ["Mankey", 21], ["Geodude", 20], ["Squirtle", 20]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", "gyarados_done", "cape_scene_seen", 
			"rocket_ship_1", "rocket_ship_2", "rocket_ship_3", "trainer_rocket_ship_1", "trainer_rocket_ship_2", "trainer_rocket_ship_3", 
			"trainer_rocket_ship_4", "ss_anne_surge_seen"], 
		"room_at": ["SSAnneCargoHold", 6.5, -7.9], "late_flags": ["ss_anne_hold_cleared"], 
		"bag": {"potion": 3, "poke_ball": 5, "super_potion": 1, "ss_ticket": 1}}, 

	"vermilion_harbor": {"label": "Vermilion Harbour (S.S. Anne gangway)", "spawn": "vm_ss_anne", 
		"party": [["Charmeleon", 22], ["Pidgeotto", 20], ["Mankey", 19], ["Geodude", 18], ["Squirtle", 18]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", "gyarados_done", "cape_scene_seen"], 
		"bag": {"potion": 3, "poke_ball": 5, "super_potion": 1, "ss_ticket": 1}}, 
	"r2_east_gate": {"label": "Route 2 (east gate / Oak's aide)", "spawn": "r2_east_gate_door", 
		"party": [["Charmeleon", 20], ["Pidgeotto", 18]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", "gyarados_done", "cape_scene_seen", "thunder_badge"], 
		"bag": {"potion": 3, "poke_ball": 5}}, 

	"r2_cave": {"label": "Route 2 (Diglett's Cave mouth)", "spawn": "r2_cave", 
		"party": [["Charmeleon", 20], ["Dugtrio", 20], ["Pidgeotto", 18], ["Mankey", 17]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", "gyarados_done", "cape_scene_seen", "thunder_badge"], 
		"bag": {"potion": 3, "poke_ball": 5, "super_potion": 1}}, 


	"digletts": {"label": "Diglett's Cave (north mouth)", "spawn": "dc_north_in", 
		"scene": "res://scenes/interiors/digletts_cave_interiors.tscn", 
		"party": [["Charmeleon", 20], ["Dugtrio", 20], ["Pidgeotto", 18], ["Mankey", 17]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", "gyarados_done", "cape_scene_seen", "thunder_badge"], 
		"bag": {"potion": 3, "poke_ball": 5, "super_potion": 1}}, 
	"digletts_cave": {"label": "Diglett's Cave (tunnel)", "spawn": "dc_north_stair", 
		"scene": "res://scenes/interiors/digletts_cave_interiors.tscn", 
		"party": [["Charmeleon", 20], ["Dugtrio", 20], ["Pidgeotto", 18], ["Mankey", 17]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", "gyarados_done", "cape_scene_seen", "thunder_badge"], 
		"bag": {"potion": 3, "poke_ball": 5, "super_potion": 1}}, 

	"lavender": {"label": "Lavender Town", "spawn": "lv_north", 
		"party": [["Charmeleon", 24], ["Pidgeotto", 22], ["Mankey", 21], ["Geodude", 20], ["Squirtle", 20]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", "gyarados_done", "cape_scene_seen", "thunder_badge"], 
		"bag": {"potion": 3, "poke_ball": 5, "super_potion": 1, "ss_ticket": 1}}, 
	"lavender_tower": {"label": "Lavender (tower yard)", "spawn": "lv_tower", 
		"party": [["Charmeleon", 24], ["Pidgeotto", 22], ["Mankey", 21], ["Geodude", 20], ["Squirtle", 20]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", "gyarados_done", "cape_scene_seen", "thunder_badge"], 
		"bag": {"potion": 3, "poke_ball": 5, "super_potion": 1, "ss_ticket": 1, "silph_scope": 1}}, 

	"tower_6f": {"label": "Pokémon Tower 6F (possessed Blue)", "spawn": "lv_tower_6f_2", 
		"trainer_level": 15, 
		"scene": "res://scenes/interiors/lavender_interiors.tscn", 
		"party": [["Charizard", 30], ["Alakazam", 27], ["Gyarados", 27], ["Raichu", 26], ["Nidoking", 27], ["Snorlax", 28]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", "gyarados_done", "cape_scene_seen", "thunder_badge"], 
		"bag": {"super_potion": 8, "revive": 2, "poke_ball": 20}}, 

	"tower_7f": {"label": "Pokémon Tower 7F (Koga)", "spawn": "lv_tower_7f_1", 
		"scene": "res://scenes/interiors/lavender_interiors.tscn", "trainer_level": 15, 
		"party": [["Charizard", 30], ["Alakazam", 27], ["Gyarados", 27], ["Raichu", 26], ["Nidoking", 27], ["Snorlax", 28]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", "gyarados_done", "cape_scene_seen", "thunder_badge", "tower_6f_done"], 
		"bag": {"super_potion": 8, "revive": 2, "poke_ball": 20}}, 


	"lavender_volunteer_house": {"label": "Lavender (Volunteer House)", "spawn": "lv_volunteer_in", 
		"scene": "res://scenes/interiors/lavender_interiors.tscn", 
		"party": [["Alakazam", 75], ["Gengar", 75], ["Charizard", 75], ["Dragonite", 75], ["Blastoise", 75], ["Venusaur", 75]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", "gyarados_done", "cape_scene_seen", 
			"thunder_badge", "rescued_mr_fuji", "hide_tower_fuji"], 
		"bag": {"potion": 20, "poke_ball": 30, "super_potion": 20, "ss_ticket": 1}}, 


	"lavender_tower_op": {"label": "Lavender Tower (no Scope)", "spawn": "lv_tower", 
		"party": [["Alakazam", 75], ["Gengar", 75], ["Charizard", 75], ["Dragonite", 75], ["Blastoise", 75], ["Venusaur", 75]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", "gyarados_done", "cape_scene_seen", "thunder_badge"], 
		"bag": {"potion": 20, "poke_ball": 30, "super_potion": 20, "ss_ticket": 1}}, 
	"lavender_tower_scope": {"label": "Lavender Tower (Silph Scope)", "spawn": "lv_tower", 
		"party": [["Alakazam", 75], ["Gengar", 75], ["Charizard", 75], ["Dragonite", 75], ["Blastoise", 75], ["Venusaur", 75]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", "gyarados_done", "cape_scene_seen", "thunder_badge"], 
		"bag": {"potion": 20, "poke_ball": 30, "super_potion": 20, "ss_ticket": 1, "silph_scope": 1}}, 

	"route12": {"label": "Route 12 (Snorlax, flute only)", "spawn": "r12_snorlax", 
		"party": [["Charmeleon", 26], ["Pidgeotto", 24], ["Mankey", 23], ["Geodude", 22], ["Squirtle", 22]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", "gyarados_done", "cape_scene_seen", "thunder_badge", "trainer_route12_ned", "trainer_route12_chip", "trainer_route12_hank", "trainer_route12_elliot", "trainer_route12_gia_jes", "trainer_route12_luca", "trainer_route12_justin", "trainer_route12_andrew"], 
		"bag": {"potion": 3, "poke_ball": 5, "super_potion": 1, "great_ball": 3, "poke_flute": 1}}, 

	"route12_scope": {"label": "Route 12 (flute + Silph Scope)", "spawn": "r12_snorlax", 
		"party": [["Charmeleon", 26], ["Pidgeotto", 24], ["Mankey", 23], ["Geodude", 22], ["Squirtle", 22]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", "gyarados_done", "cape_scene_seen", "thunder_badge", "trainer_route12_ned", "trainer_route12_chip", "trainer_route12_hank", "trainer_route12_elliot", "trainer_route12_gia_jes", "trainer_route12_luca", "trainer_route12_justin", "trainer_route12_andrew"], 
		"bag": {"potion": 3, "poke_ball": 5, "super_potion": 1, "great_ball": 3, "poke_flute": 1, "silph_scope": 1}}, 

	"route13": {"label": "Route 13", "spawn": "r13_east", 
		"party": [["Charmeleon", 27], ["Pidgeotto", 25], ["Mankey", 24], ["Geodude", 23], ["Squirtle", 23]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", "gyarados_done", "cape_scene_seen", "thunder_badge"], 
		"bag": {"potion": 3, "poke_ball": 5, "super_potion": 1, "great_ball": 3}}, 


	"r13_plank": {"label": "Route 13 (on the plank walk)", "spawn": "r13_plank", 
		"party": [["Charmeleon", 27], ["Pidgeotto", 25], ["Mankey", 24], ["Geodude", 23], ["Squirtle", 23]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", "gyarados_done", "cape_scene_seen", "thunder_badge"], 
		"registered": "bicycle", 
		"bag": {"bicycle": 1, "potion": 3, "poke_ball": 5, "super_potion": 1, "great_ball": 3}}, 

	"route14": {"label": "Route 14", "spawn": "r14_east", 
		"party": [["Charmeleon", 28], ["Pidgeotto", 26], ["Mankey", 25], ["Geodude", 24], ["Squirtle", 24]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", "gyarados_done", "cape_scene_seen", "thunder_badge"], 
		"bag": {"potion": 3, "poke_ball": 5, "super_potion": 1, "great_ball": 3}}, 

	"route15": {"label": "Route 15", "spawn": "r15_east", 
		"party": [["Charmeleon", 29], ["Pidgeotto", 27], ["Mankey", 26], ["Geodude", 25], ["Squirtle", 25]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", "gyarados_done", "cape_scene_seen", "thunder_badge"], 
		"bag": {"potion": 3, "poke_ball": 5, "super_potion": 1, "great_ball": 3}}, 

	"route16": {"label": "Route 16", "spawn": "r16_east", 
		"party": [["Charmeleon", 30], ["Pidgeotto", 28], ["Mankey", 27], ["Geodude", 26], ["Squirtle", 26]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", "gyarados_done", "cape_scene_seen", "thunder_badge"], 
		"bag": {"potion": 3, "poke_ball": 5, "super_potion": 1, "great_ball": 3}}, 

	"route16_scope": {"label": "Route 16 (Snorlax, flute + Silph Scope)", "spawn": "r16_snorlax", 
		"party": [["Charmeleon", 30], ["Pidgeotto", 28], ["Mankey", 27], ["Geodude", 26], ["Squirtle", 26]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", "gyarados_done", "cape_scene_seen", "thunder_badge", "trainer_route16_lea_jed", "trainer_route16_lao", "trainer_route16_koji", "trainer_route16_luke", "trainer_route16_hideo", "trainer_route16_ruben", "trainer_route16_camron"], 
		"bag": {"potion": 3, "poke_ball": 5, "super_potion": 1, "great_ball": 3, "poke_flute": 1, "silph_scope": 1}}, 

	"route16_gate": {"label": "Route 16 Cycling Road gate", "spawn": "r16_gate_south", 
		"party": [["Pidgeot", 36], ["Charmeleon", 30], ["Mankey", 27], ["Geodude", 26], ["Squirtle", 26]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", "gyarados_done", "cape_scene_seen", "thunder_badge"], 
		"registered": "bicycle", 
		"bag": {"bicycle": 1, "potion": 3, "poke_ball": 5, "super_potion": 1, "great_ball": 3}}, 

	"celadon_mansion": {"label": "Celadon Mansion", "spawn": "cm_1f_in", "trainer_level": 15, 
		"scene": "res://scenes/interiors/celadon_mansion_interiors.tscn", 
		"party": [["Charmeleon", 32], ["Pidgeotto", 30], ["Mankey", 29], ["Geodude", 28], ["Squirtle", 28]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", "gyarados_done", "cape_scene_seen", "thunder_badge"], 
		"bag": {"potion": 5, "super_potion": 3, "poke_ball": 5, "great_ball": 3}}, 

	"celadon_game_corner": {"label": "Celadon Game Corner", "spawn": "cl_gamecorner_in", "trainer_level": 15, 
		"scene": "res://scenes/interiors/celadon_interiors.tscn", "money": 12000, "coins": 300, 
		"party": [["Charmeleon", 32], ["Pidgeotto", 30], ["Mankey", 29], ["Geodude", 28], ["Squirtle", 28]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", "gyarados_done", "cape_scene_seen", "thunder_badge", "got_coin_case"], 
		"bag": {"potion": 5, "super_potion": 3, "poke_ball": 5, "great_ball": 3, "coin_case": 1}}, 

	"rocket_hideout_b1f": {"label": "Rocket Hideout B1F", "spawn": "rh_b1f_from_gc", "trainer_level": 15, 
		"scene": "res://scenes/interiors/rocket_hideout_interiors.tscn", "money": 12000, "coins": 300, 
		"party": [["Charmeleon", 32], ["Pidgeotto", 30], ["Mankey", 29], ["Geodude", 28], ["Squirtle", 28]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", "gyarados_done", "cape_scene_seen", "thunder_badge", "got_coin_case", "opened_rocket_hideout", "cgc_grunt_beaten"], 
		"bag": {"potion": 5, "super_potion": 3, "poke_ball": 5, "great_ball": 3, "coin_case": 1}}, 
	"rocket_hideout_b2f": {"label": "Rocket Hideout B2F (Ariana, then Erika)", "spawn": "rh_b2f_from_above", "trainer_level": 15, 
		"scene": "res://scenes/interiors/rocket_hideout_interiors.tscn", "money": 12000, "coins": 300, 
		"party": [["Charmeleon", 32], ["Pidgeotto", 30], ["Mankey", 29], ["Geodude", 28], ["Squirtle", 28]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", "gyarados_done", "cape_scene_seen", "thunder_badge", "got_coin_case", "opened_rocket_hideout", "cgc_grunt_beaten"], 
		"bag": {"potion": 5, "super_potion": 3, "poke_ball": 5, "great_ball": 3, "coin_case": 1}}, 

	"saffron_gym": {"label": "Saffron Gym", "spawn": "sf_gym_in", "trainer_level": 15, 
		"scene": "res://scenes/interiors/saffron_interiors.tscn", 
		"party": [["Charizard", 50], ["Pidgeot", 48], ["Primeape", 46], ["Golem", 46], ["Blastoise", 48]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", "thunder_badge", "rainbow_badge", "soul_badge", "volcano_badge", "gyarados_done", "cape_scene_seen", "blaine_lab_done", "starter_stolen", "vermilion_green_done", "fuchsia_green_met", "cinnabar_green_met", "saffron_open"], 
		"bag": {"potion": 5, "super_potion": 5, "poke_ball": 5, "great_ball": 5}}, 

	"cinnabar_lab": {"label": "Cinnabar Lab", "spawn": "cn_lab_in", "trainer_level": 15, 
		"scene": "res://scenes/interiors/cinnabar_interiors.tscn", 
		"party": [["Blastoise", 46], ["Raichu", 34], ["Venonat", 20], ["Ponyta", 25], ["Clefairy", 25], ["Gyarados", 44]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", "thunder_badge", "rainbow_badge", "soul_badge", "tower_koga_done", "gyarados_done", "cape_scene_seen"], 
		"bag": {"potion": 5, "poke_ball": 5, "dome_fossil": 1, "helix_fossil": 1}}, 

	"cinnabar_gym": {"label": "Cinnabar Gym", "spawn": "cn_gym_in", "trainer_level": 15, 
		"scene": "res://scenes/interiors/cinnabar_interiors.tscn", 
		"party": [["Blastoise", 46], ["Gyarados", 44], ["Pidgeot", 44], ["Golem", 43], ["Primeape", 43]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", "thunder_badge", "rainbow_badge", "soul_badge", "gyarados_done", "cape_scene_seen", "blaine_lab_done"], 
		"bag": {"potion": 5, "super_potion": 5, "poke_ball": 5, "great_ball": 5}}, 

	"cinnabar_volcano": {"label": "Cinnabar Volcano (1F entrance)", "spawn": "vc_in", "trainer_level": 15, 
		"scene": "res://scenes/interiors/volcano_interiors.tscn", 
		"party": [["Blastoise", 46], ["Gyarados", 44], ["Pidgeot", 44], ["Golem", 43], ["Primeape", 43]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", "thunder_badge", "rainbow_badge", "soul_badge", "gyarados_done", "cape_scene_seen", "blaine_lab_done"], 
		"bag": {"potion": 5, "super_potion": 5, "poke_ball": 10, "great_ball": 10}}, 

	"fuchsia_gym": {"label": "Fuchsia Gym", "spawn": "fc_gym_in", "trainer_level": 15, 
		"scene": "res://scenes/interiors/fuchsia_interiors.tscn", 
		"party": [["Charizard", 44], ["Pidgeot", 42], ["Primeape", 41], ["Golem", 41], ["Blastoise", 42]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", "thunder_badge", "rainbow_badge", "gyarados_done", "cape_scene_seen"], 
		"bag": {"potion": 5, "super_potion": 5, "poke_ball": 5, "great_ball": 5}}, 

	"viridian_gym": {"label": "Viridian Gym (Giovanni)", "spawn": "vc_gym_in", "trainer_level": 15, 
		"scene": "res://scenes/interiors/viridian_city_interiors.tscn", 
		"party": [["Charizard", 55], ["Blastoise", 55], ["Venusaur", 55], ["Pikachu", 52], ["Alakazam", 52]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", "thunder_badge", "rainbow_badge", 
			"soul_badge", "marsh_badge", "volcano_badge", "gyarados_done", "cape_scene_seen", "silph_finale_won", 
			"viridian_final_showdown_unlocked"], 
		"bag": {"hyper_potion": 10, "revive": 5, "full_heal": 5, "poke_ball": 5}}, 

	"safari_zone": {"label": "Safari Zone (a game already running)", "spawn": "sz_gate", "trainer_level": 15, 
		"party": [["Charizard", 44], ["Pidgeot", 42], ["Primeape", 41], ["Golem", 41], ["Blastoise", 42]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", "thunder_badge", "rainbow_badge", "gyarados_done", "cape_scene_seen", "safari_active"], 
		"bag": {"potion": 5, "super_potion": 5, "poke_ball": 5, "great_ball": 5}}, 


	"safari_inside": {"label": "Safari Zone (inside, game running)", "spawn": "sz_west", "trainer_level": 15, 
		"party": [["Charizard", 44], ["Pidgeot", 42], ["Primeape", 41]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", 
			"thunder_badge", "rainbow_badge", "soul_badge", "marsh_badge", "volcano_badge", "earth_badge", 
			"safari_active"], 
		"bag": {"super_potion": 5, "full_heal": 3}}, 

	"safari_entrance": {"label": "Safari entrance (pay at the counter)", "spawn": "fc_safari_in", "trainer_level": 15, "money": 3000, 
		"scene": "res://scenes/interiors/fuchsia_interiors.tscn", 
		"party": [["Charizard", 44], ["Pidgeot", 42], ["Primeape", 41], ["Golem", 41], ["Blastoise", 42]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", "thunder_badge", "rainbow_badge", "gyarados_done", "cape_scene_seen"], 
		"bag": {"potion": 5, "super_potion": 5, "poke_ball": 5, "great_ball": 5}}, 

	"saffron_dojo": {"label": "Saffron Fighting Dojo", "spawn": "sf_dojo_in", "trainer_level": 15, 
		"scene": "res://scenes/interiors/saffron_interiors.tscn", 
		"party": [["Charizard", 50], ["Pidgeot", 48], ["Primeape", 46], ["Golem", 46], ["Blastoise", 48]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", "thunder_badge", "rainbow_badge", "soul_badge", "volcano_badge", "gyarados_done", "cape_scene_seen", "blaine_lab_done", "starter_stolen", "vermilion_green_done", "fuchsia_green_met", "cinnabar_green_met", "saffron_open"], 
		"bag": {"potion": 5, "super_potion": 5, "poke_ball": 5, "great_ball": 5}}, 

	"celadon_gym": {"label": "Celadon Gym", "spawn": "cg_gym_in", "trainer_level": 15, 
		"scene": "res://scenes/interiors/celadon_gym_interiors.tscn", 
		"party": [["Charmeleon", 32], ["Pidgeotto", 30], ["Mankey", 29], ["Geodude", 28], ["Squirtle", 28]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", "gyarados_done", "cape_scene_seen", "thunder_badge"], 
		"bag": {"potion": 5, "super_potion": 3, "poke_ball": 5, "great_ball": 3}}, 

	"route17": {"label": "Route 17", "spawn": "r17_north", 
		"party": [["Charmeleon", 30], ["Pidgeotto", 28], ["Mankey", 27], ["Geodude", 26], ["Squirtle", 26]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", "gyarados_done", "cape_scene_seen", "thunder_badge"], 
		"bag": {"potion": 3, "poke_ball": 5, "super_potion": 1, "great_ball": 3}}, 

	"route18": {"label": "Route 18", "spawn": "r18_north", 
		"party": [["Charmeleon", 31], ["Pidgeotto", 29], ["Mankey", 28], ["Geodude", 27], ["Squirtle", 27]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", "gyarados_done", "cape_scene_seen", "thunder_badge"], 
		"bag": {"potion": 3, "poke_ball": 5, "super_potion": 1, "great_ball": 3}}, 

	"fuchsia": {"label": "Fuchsia City", "spawn": "fc_west", 
		"party": [["Charmeleon", 31], ["Pidgeotto", 29], ["Mankey", 28], ["Geodude", 27], ["Squirtle", 27]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", "gyarados_done", "cape_scene_seen", "thunder_badge"], 
		"bag": {"potion": 3, "poke_ball": 5, "super_potion": 1, "great_ball": 3}}, 

	"route19": {"label": "Route 19", "spawn": "r19_start", 
		"party": [["Charmeleon", 31], ["Pidgeotto", 29], ["Mankey", 28], ["Geodude", 27], ["Squirtle", 27]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", "gyarados_done", "cape_scene_seen", "thunder_badge"], 
		"bag": {"potion": 3, "poke_ball": 5, "super_potion": 1, "great_ball": 3}}, 

	"route10_surf": {"label": "Route 10 (broken bridge, surf)", "spawn": "r10_landing", "trainer_level": 15, 
		"party": [["Lapras", 36], ["Charmeleon", 31], ["Rhydon", 30], ["Geodude", 27], ["Rattata", 22], ["Squirtle", 27]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", "gyarados_done", "cape_scene_seen", "thunder_badge", "soul_badge"], 
		"bag": {"potion": 5, "super_potion": 3, "poke_ball": 5, "great_ball": 3}}, 


	"route19_surf": {"label": "Route 19 (surf test)", "spawn": "r19_start", 
		"party": [["Lapras", 36], ["Charmeleon", 31], ["Rhydon", 30], ["Geodude", 27], ["Rattata", 22], ["Squirtle", 27]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", "gyarados_done", "cape_scene_seen", "thunder_badge", "soul_badge"], 
		"bag": {"potion": 5, "super_potion": 3, "poke_ball": 5, "great_ball": 3}}, 

	"route19_surf_water": {"label": "Route 19 (surf ambush test)", "spawn": "r19_start", 
		"party": [["Lapras", 36], ["Blastoise", 34], ["Poliwrath", 33], ["Starmie", 33], ["Seaking", 32]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", "gyarados_done", "cape_scene_seen", "thunder_badge", "soul_badge"], 
		"bag": {"potion": 5, "super_potion": 3, "poke_ball": 5, "great_ball": 3}}, 


	"route19_gate": {"label": "Route 19 (gate test)", "spawn": "r19_start", 
		"party": [["Lapras", 36], ["Charmeleon", 31], ["Rhydon", 30]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", "gyarados_done", "cape_scene_seen", "thunder_badge", "soul_badge"], 
		"bag": {"potion": 5, "poke_ball": 5}}, 

	"route19_blackout": {"label": "Route 19 (black-out test)", "spawn": "r19_start", 
		"party": [["Lapras", 36], ["Charmeleon", 31], ["Rhydon", 30], ["Rattata", 3]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", "gyarados_done", "cape_scene_seen", "thunder_badge", "soul_badge"], 
		"bag": {"potion": 5, "poke_ball": 5}}, 

	"route20": {"label": "Route 20", "spawn": "r20_entrance", 
		"party": [["Charmeleon", 31], ["Pidgeotto", 29], ["Mankey", 28], ["Geodude", 27], ["Squirtle", 27]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", "gyarados_done", "cape_scene_seen", "thunder_badge"], 
		"bag": {"potion": 3, "poke_ball": 5, "super_potion": 1, "great_ball": 3}}, 

	"seafoam": {"label": "Seafoam Islands (east hall)", "spawn": "sf_east_in", 
		"scene": "res://scenes/interiors/seafoam_interiors.tscn", "trainer_level": 15, 
		"party": [["Lapras", 32], ["Blastoise", 36], ["Pidgeotto", 29], ["Mankey", 28], ["Geodude", 27]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", "gyarados_done", "cape_scene_seen", "thunder_badge"], 
		"bag": {"potion": 3, "poke_ball": 5, "super_potion": 1, "great_ball": 3}}, 

	"cinnabar": {"label": "Cinnabar Island", "spawn": "cn_center", 
		"party": [["Charmeleon", 31], ["Pidgeotto", 29], ["Mankey", 28], ["Geodude", 27], ["Squirtle", 27]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", "gyarados_done", "cape_scene_seen", "thunder_badge", "rainbow_badge", "soul_badge", "tower_koga_done"], 
		"bag": {"potion": 3, "poke_ball": 5, "super_potion": 1, "great_ball": 3}}, 

	"route21": {"label": "Route 21", "spawn": "r21_shore", 
		"party": [["Charmeleon", 31], ["Pidgeotto", 29], ["Mankey", 28], ["Geodude", 27], ["Squirtle", 27]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", "gyarados_done", "cape_scene_seen", "thunder_badge"], 
		"bag": {"potion": 3, "poke_ball": 5, "super_potion": 1, "great_ball": 3}}, 
	"battle_tower": {"label": "Battle Tower", "spawn": "vm_tower_in", 
		"scene": "res://scenes/interiors/vermilion_interiors.tscn", 
		"party": [["Charmeleon", 24]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", "gyarados_done", "cape_scene_seen", "thunder_badge"], 
		"bag": {"potion": 3}}, 
	"vermilion_gym": {"label": "Vermilion Gym", "spawn": "vm_gym_in", 
		"scene": "res://scenes/interiors/vermilion_interiors.tscn", 
		"party": [["Charmeleon", 24], ["Pidgeotto", 22], ["Mankey", 21], ["Geodude", 20], ["Squirtle", 20]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", "gyarados_done", "cape_scene_seen"], 
		"bag": {"potion": 3, "poke_ball": 5, "super_potion": 1, "ss_ticket": 1}}, 

	"route24": {"label": "Route 24 (Nugget Bridge)", "spawn": "r24_south", 
		"party": [["Charmeleon", 18], ["Pidgeotto", 17], ["Mankey", 16], ["Geodude", 15], ["Squirtle", 15]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge"], 
		"bag": {"potion": 3, "poke_ball": 5, "super_potion": 1}}, 

	"route24_walk": {"label": "Route 24/25 walk (trainers beaten, surf)", "spawn": "r24_south", 
		"party": [["Charmeleon", 18], ["Pidgeotto", 17], ["Mankey", 16], ["Geodude", 15], ["Squirtle", 15], ["Blastoise", 36]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "soul_badge", "route24_gauntlet_done", 
			"trainer_route24_cale", "trainer_route24_ali", "trainer_route24_timmy", "trainer_route24_reli", 
			"trainer_route24_ethan", "trainer_route24_rocket", "trainer_route24_shane", 
			"trainer_route25_franklin", "trainer_route25_wayne", "trainer_route25_joey", "trainer_route25_dan", 
			"trainer_route25_kelsey", "trainer_route25_nob", "trainer_route25_flint", "trainer_route25_chad", 
			"trainer_route25_haley"], 
		"bag": {"potion": 3, "poke_ball": 5, "super_potion": 1}}, 

	"route24_rematch": {"label": "Route 24/25 (rematches)", "spawn": "r24_south", 
		"party": [["Charmeleon", 28], ["Primeape", 28], ["Pidgeotto", 28]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "route24_gauntlet_done", 
			"trainer_route24_cale", "trainer_route24_ali", "trainer_route24_timmy", "trainer_route24_reli", 
			"trainer_route24_ethan", "trainer_route24_rocket", "trainer_route24_shane", 
			"trainer_route25_franklin", "trainer_route25_wayne", "trainer_route25_joey", "trainer_route25_dan", 
			"trainer_route25_kelsey", "trainer_route25_nob", "trainer_route25_flint", "trainer_route25_chad", 
			"trainer_route25_haley"], 
		"bag": {"potion": 5, "poke_ball": 5, "super_potion": 3}, "trainer_level": 15}, 
	"route25": {"label": "Route 25 (Bill's Cape)", "spawn": "r25_west", 
		"party": [["Charmeleon", 18], ["Pidgeotto", 17], ["Mankey", 16], ["Geodude", 15], ["Squirtle", 15]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge"], 
		"bag": {"potion": 3, "poke_ball": 5, "super_potion": 1}}, 


	"route25_cove": {"label": "Route 25 (Sea Cliff Cove)", "spawn": "r25_cottage", 
		"party": [["Charmeleon", 18], ["Pidgeotto", 17], ["Mankey", 16], ["Squirtle", 15]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "route24_gauntlet_done", 
			"trainer_route24_cale", "trainer_route24_ali", "trainer_route24_timmy", "trainer_route24_reli", 
			"trainer_route24_ethan", "trainer_route24_rocket", "trainer_route24_shane", 
			"trainer_route25_franklin", "trainer_route25_wayne", "trainer_route25_joey", "trainer_route25_dan", 
			"trainer_route25_kelsey", "trainer_route25_nob", "trainer_route25_flint", "trainer_route25_chad", 
			"trainer_route25_haley"], 
		"bag": {"potion": 3, "poke_ball": 5, "super_potion": 1}, "trainer_level": 15}, 

	"route5": {"label": "Route 5", "spawn": "r5_north", 
		"party": [["Charmeleon", 20], ["Pidgeotto", 18], ["Mankey", 17], ["Geodude", 16]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge"], 
		"bag": {"potion": 3, "poke_ball": 5, "super_potion": 1}}, 


	"daycare": {"label": "Route 5 Day Care (Pikachu inside, egg soon)", "spawn": "r5_daycare_door", "trainer_level": 15, 
		"party": [["Charizard", 50], ["Blastoise", 50], ["Venusaur", 50]], 
		"daycare": ["Pikachu", 12, 1440], "egg_in": 60, 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge"], 
		"bag": {"potion": 3, "poke_ball": 5}}, 

	"daycare_deposit": {"label": "Route 5 Day Care (empty, try leaving one)", "spawn": "r5_daycare_door", "trainer_level": 15, 
		"party": [["Charizard", 50], ["Blastoise", 50], ["Venusaur", 50]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge"], 
		"bag": {"potion": 3, "poke_ball": 5}}, 


	"daycare_egg4": {"label": "Day Care (egg due, 4 in the party)", "spawn": "r5_daycare_door", "trainer_level": 15, 
		"party": [["Charizard", 50], ["Blastoise", 50], ["Venusaur", 50], ["Pikachu", 20]], 
		"daycare": ["Pikachu", 12, 4320], "egg_in": 0, 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge"], 
		"bag": {"potion": 3, "poke_ball": 5}}, 
	"daycare_egg6": {"label": "Day Care (egg due, party full)", "spawn": "r5_daycare_door", "trainer_level": 15, 
		"party": [["Charizard", 50], ["Blastoise", 50], ["Venusaur", 50], ["Pikachu", 20], ["Snorlax", 40], ["Gyarados", 40]], 
		"daycare": ["Pikachu", 12, 4320], "egg_in": 0, 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge"], 
		"bag": {"potion": 3, "poke_ball": 5}}, 
	"daycare_hatch": {"label": "Route 5 Day Care (egg about to hatch)", "spawn": "r5_daycare_door", "trainer_level": 15, 
		"party": [["Charizard", 50], ["Blastoise", 50]], "eggs": [["Charmander", 40]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge"], 
		"bag": {"potion": 3, "poke_ball": 5}}, 

	"route5_tunnel": {"label": "Route 5 - Underground Path", "spawn": "r5_ug_door", 
		"party": [["Charmeleon", 20], ["Pidgeotto", 18], ["Mankey", 17], ["Geodude", 16]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge"], 
		"bag": {"potion": 3, "poke_ball": 5, "super_potion": 1}}, 

	"route6": {"label": "Route 6", "spawn": "r6_north", 
		"party": [["Charmeleon", 20], ["Pidgeotto", 19], ["Mankey", 18], ["Geodude", 17], ["Squirtle", 17]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge"], 
		"bag": {"potion": 3, "poke_ball": 5, "super_potion": 1}}, 

	"route9": {"label": "Route 9", "spawn": "r9_meadow", 
		"party": [["Charmeleon", 22], ["Pidgeotto", 20], ["Mankey", 19], ["Geodude", 18], ["Squirtle", 18]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", "gyarados_done", "cape_scene_seen", "thunder_badge"], 
		"bag": {"potion": 3, "poke_ball": 5, "super_potion": 1}}, 

	"route9_rematch": {"label": "Route 9 (rematches)", "spawn": "r9_meadow", 
		"party": [["Charizard", 31], ["Pidgeot", 30], ["Primeape", 30], ["Golem", 29], ["Blastoise", 30]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", "gyarados_done", "cape_scene_seen", "thunder_badge"], 
		"bag": {"potion": 3, "poke_ball": 5, "super_potion": 3}}, 
	"route10_rematch": {"label": "Route 10 (rematches)", "spawn": "r10_plaza", 
		"party": [["Charizard", 38], ["Pidgeot", 37], ["Primeape", 37], ["Golem", 36], ["Blastoise", 38]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", "gyarados_done", "cape_scene_seen", "thunder_badge"], 
		"bag": {"potion": 3, "poke_ball": 5, "super_potion": 3}}, 




	"route10": {"label": "Route 10", "spawn": "r10_west", 
		"party": [["Charmeleon", 28], ["Pidgeotto", 27], ["Primeape", 27], ["Graveler", 26], ["Wartortle", 27]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge"], 
		"bag": {"potion": 3, "poke_ball": 5, "super_potion": 1}}, 


	"route10_cave": {"label": "Route 10 (before Rock Tunnel)", "spawn": "r10_plaza", 
		"party": [["Charmeleon", 28], ["Pidgeotto", 27], ["Primeape", 27], ["Graveler", 26], ["Wartortle", 27]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge"], 
		"bag": {"flashlight": 1, "potion": 5, "poke_ball": 10, "super_potion": 3, "repel": 3, "antidote": 2}}, 

	"route10_power_plant": {"label": "Route 10 (Power Plant door)", "spawn": "r10_power_plant", "trainer_level": 15, 
		"party": [["Lapras", 32], ["Blastoise", 36], ["Pidgeotto", 24], ["Mankey", 23], ["Pikachu", 24]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge"], 
		"bag": {"potion": 5, "poke_ball": 10, "super_potion": 3}}, 

	"power_plant_back": {"label": "Power Plant (inside, north door open)", "spawn": "pp_north_in", "trainer_level": 15, 
		"scene": "res://scenes/interiors/power_plant_interiors.tscn", 
		"party": [["Blastoise", 52], ["Charizard", 52], ["Venusaur", 51], ["Pikachu", 48], ["Alakazam", 50]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "soul_badge", "silph_finale_won", 
			"pp_north_open", "pp_gate_GA", "pp_gate_GE", "pp_gate_G2"], 
		"bag": {"ultra_ball": 20, "full_restore": 5, "max_revive": 2}}, 

	"power_plant_zapdos": {"label": "Power Plant north yard (Zapdos)", "spawn": "r10_plant_yard", "trainer_level": 15, 
		"party": [["Blastoise", 62], ["Golem", 61], ["Venusaur", 61], ["Lapras", 60], ["Alakazam", 60]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "soul_badge", "silph_finale_won", "pp_north_open"], 
		"bag": {"ultra_ball": 20, "full_restore": 5, "max_revive": 2}}, 

	"power_plant": {"label": "Power Plant (interior)", "spawn": "pp_in", "trainer_level": 15, 
		"scene": "res://scenes/interiors/power_plant_interiors.tscn", 
		"party": [["Pikachu", 24], ["Charmeleon", 28], ["Pidgeotto", 27], ["Primeape", 27], ["Wartortle", 27]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "soul_badge"], 
		"bag": {"potion": 5, "poke_ball": 10, "super_potion": 3}}, 
	"rock_tunnel": {"label": "Rock Tunnel", "spawn": "rt_north_in", 
		"scene": "res://scenes/interiors/rock_tunnel_interiors.tscn", 
		"party": [["Charmeleon", 24], ["Pidgeotto", 22], ["Mankey", 21], ["Geodude", 20], ["Squirtle", 20]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "rt_flashlit"], 
		"bag": {"flashlight": 1, "potion": 4, "poke_ball": 8, "super_potion": 2, "repel": 2}}, 


	"rock_tunnel_rematch": {"label": "Rock Tunnel (rematches)", "spawn": "rt_north_in", 
		"scene": "res://scenes/interiors/rock_tunnel_interiors.tscn", 
		"party": [["Charizard", 42], ["Pidgeot", 41], ["Primeape", 40], ["Golem", 40], ["Blastoise", 42]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", 
			"gyarados_done", "cape_scene_seen", "thunder_badge", "rt_flashlit", 
			"trainer_rock_tunnel_lenny", "trainer_rock_tunnel_oliver", "trainer_rock_tunnel_lucas", 
			"trainer_rock_tunnel_ashton", "trainer_rock_tunnel_dana", "trainer_rock_tunnel_ariana", 
			"trainer_rock_tunnel_leah", "trainer_rock_tunnel_cooper", "trainer_rock_tunnel_dudley", 
			"trainer_rock_tunnel_sofia", "trainer_rock_tunnel_allen", "trainer_rock_tunnel_eric", 
			"trainer_rock_tunnel_steve", "trainer_rock_tunnel_martha", "trainer_rock_tunnel_winston"], 
		"bag": {"flashlight": 1, "potion": 3, "poke_ball": 5, "super_potion": 5, "full_heal": 2}}, 
	"route10_south": {"label": "Route 10 (cave exit)", "spawn": "r10_exit", 
		"party": [["Charmeleon", 28], ["Pidgeotto", 27], ["Primeape", 27], ["Graveler", 26], ["Wartortle", 27]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge"], 
		"bag": {"potion": 3, "poke_ball": 5, "super_potion": 1}}, 
	"bills": {"label": "Bill's Sea Cottage", "spawn": "r25_cottage", 
		"party": [["Charmeleon", 18], ["Pidgeotto", 17], ["Mankey", 16], ["Geodude", 15], ["Squirtle", 15]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge"], 
		"bag": {"potion": 3, "poke_ball": 5, "super_potion": 1}}, 

	"cape": {"label": "Route 25 cape (Gyarados event)", "spawn": "r25_cottage", 
		"party": [["Pikachu", 21], ["Charmeleon", 22], ["Pidgeotto", 20], ["Mankey", 18]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge"], 
		"bag": {"potion": 5, "poke_ball": 20, "super_potion": 5}, "trainer_level": 15}, 
	"cape_done": {"label": "Route 25 cape (event done)", "spawn": "r25_cottage", 
		"party": [["Raichu", 25], ["Charmeleon", 22], ["Pidgeotto", 20], ["Mankey", 18]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "gyarados_done", 
			"cape_scene_seen", "cape_ticket_given"], 
		"bag": {"potion": 5, "poke_ball": 20, "super_potion": 5, "ss_ticket": 1}}, 
	"route3": {"label": "Route 3", "spawn": "r3_south", 
		"party": [["Charmander", 16], ["Pidgey", 14], ["Mankey", 13]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge"], 
		"bag": {"potion": 3, "poke_ball": 5, "super_potion": 1}}, 
	"route4": {"label": "Route 3 (Mt. Moon)", "spawn": "r4_center", 
		"party": [["Charmander", 16], ["Pidgey", 14], ["Mankey", 13]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge"], 
		"bag": {"potion": 3, "poke_ball": 5, "super_potion": 1}}, 


	"route3_mtmoon": {"label": "Route 3 (Mt. Moon door, Rhyhorn out)", "spawn": "r4_west_mouth", 
		"party": [["Rhyhorn", 18], ["Charmeleon", 18], ["Pidgeotto", 17], ["Mankey", 16]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge"], 
		"bag": {"potion": 3, "poke_ball": 5, "super_potion": 1}, 
		"out": [0]}, 


	"route_4": {"label": "Route 4 (east road)", "spawn": "r4_meadow", 
		"party": [["Charmander", 16], ["Pidgey", 14], ["Mankey", 13]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge"], 
		"bag": {"potion": 3, "poke_ball": 5, "super_potion": 1}}, 

	"route_4_boss": {"label": "Route 4 (Glimmer Mere boss)", "spawn": "r4_mere", 
		"party": [["Charmeleon", 22], ["Pidgeotto", 20], ["Mankey", 19]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge"], 
		"bag": {"potion": 3, "super_potion": 3, "poke_ball": 5}}, 
	"route_4_camp": {"label": "Route 4 (Black Belt camp)", "spawn": "r4_camp", 
		"party": [["Charmander", 16], ["Squirtle", 16]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge"], 
		"bag": {"potion": 3, "poke_ball": 5, "super_potion": 1}}, 

	"route_11": {"label": "Route 11 (cave road)", "spawn": "r11_west", 
		"party": [["Charmeleon", 21], ["Pidgeotto", 19], ["Mankey", 18], ["Geodude", 18]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge"], 
		"bag": {"potion": 3, "poke_ball": 5, "super_potion": 1}}, 

	"route8": {"label": "Route 8 (west road)", "spawn": "r8_lavender", 
		"party": [["Charmeleon", 22], ["Pidgeotto", 20], ["Mankey", 19], ["Geodude", 18], ["Squirtle", 18]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "cascade_badge", "gyarados_done", "cape_scene_seen", "thunder_badge"], 
		"bag": {"potion": 3, "poke_ball": 5, "super_potion": 1}}, 

	"mtmoon_mouth": {"label": "Mt. Moon mouth (Route 3)", "spawn": "r4_west_mouth", 
		"party": [["Charmeleon", 16], ["Pidgey", 14], ["Mankey", 13]], 

		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "starter_stolen"], 
		"bag": {"potion": 3, "poke_ball": 5, "super_potion": 1}}, 
	"mtmoon": {"label": "Mt. Moon 1F", "spawn": "mm_1f_west_in", 
		"scene": "res://scenes/interiors/mt_moon_interiors.tscn", 
		"party": [["Charmeleon", 16], ["Pidgey", 14], ["Mankey", 13]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge"], 
		"bag": {"potion": 3, "poke_ball": 5, "super_potion": 1}}, 
	"mtmoon_thief": {"label": "Mt. Moon 1F (the starter thief, after Pewter's aide)", "spawn": "mm_1f_west_in", 
		"scene": "res://scenes/interiors/mt_moon_interiors.tscn", 
		"party": [["Charmeleon", 16], ["Pidgey", 14], ["Mankey", 13]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "starter_stolen"], 
		"bag": {"potion": 3, "poke_ball": 5, "super_potion": 1}}, 
	"mtmoon_b2f": {"label": "Mt. Moon B2F (fossils)", "spawn": "mm_b2f_in", 
		"scene": "res://scenes/interiors/mt_moon_interiors.tscn", 
		"party": [["Charmeleon", 16], ["Pidgey", 14], ["Mankey", 13]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge"], 
		"bag": {"potion": 3, "poke_ball": 5, "super_potion": 1}}, 


	"mtmoon_moonlight": {"label": "Mt. Moon (grove, moonlight rule)", "spawn": "mm_grove_in", 
		"scene": "res://scenes/interiors/mt_moon_interiors.tscn", 
		"party": [["Clefairy", 20], ["Nidorino", 20]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", 
			"FLAG_MTMOON_ROCKET_BEATEN", "grove_rite_done", "grove_night_fell"], 
		"time": "21:00", 
		"bag": {"potion": 3, "poke_ball": 10, "super_potion": 1}}, 


	"mtmoon_grove": {"label": "Mt. Moon (Clefairy grove)", "spawn": "mm_grove_in", 
		"scene": "res://scenes/interiors/mt_moon_interiors.tscn", 
		"party": [["Charmeleon", 20], ["Pidgeotto", 18], ["Mankey", 17]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "FLAG_MTMOON_ROCKET_BEATEN"], 
		"bag": {"potion": 3, "poke_ball": 10, "super_potion": 1}}, 
	"demo_end": {"label": "Demo end", "spawn": "pw_gym_door", 
		"party": [["Charmeleon", 20], ["Pidgeotto", 19], ["Mankey", 18], ["Pikachu", 17], ["Nidoking", 16], ["Geodude", 15]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge", "trainer_brock"], 
		"bag": {"potion": 5, "poke_ball": 10, "super_potion": 3}}, 
	"pallet": {"label": "Pallet Town", "spawn": "start", "party": [["Squirtle", 5]]}, 

	"pallet_daisy": {"label": "Pallet — Daisy's TOWN MAP", "spawn": "rival_house_door", "party": [["Squirtle", 5]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex"], "bag": {"potion": 3, "poke_ball": 5}, "no_map": true}, 
	"pallet_woods_forest": {"label": "Pallet Woods — forest rework", "spawn": "woods_east", 
		"party": [["Wartortle", 14], ["Pidgeotto", 13]], "trainer_level": 15, 
		"flags": ["night_prologue_done", "has_pokedex"], "bag": {"poke_ball": 10, "super_potion": 5}}, 
	"pallet_woods": {"label": "Pallet Woods", "spawn": "woods_east", "party": [["Squirtle", 5]], 
		"flags": ["night_prologue_done"]}, 

	"rest_test": {"label": "Pallet Woods — bench / picnic rest", "spawn": "woods_clearing", 
		"party": [["Wartortle", 14], ["Pidgeotto", 13], ["Pikachu", 12]], "trainer_level": 15, 
		"breeder_level": 15, "hp_frac": 0.35, "pp_frac": 0.2, 
		"flags": ["night_prologue_done", "has_pokedex"], 
		"bag": {"rice": 6, "salt": 4, "bitter_herbs": 6, "tiny_mushroom": 6, "big_mushroom": 3, "honey": 4, 
			"spices": 4, "milk": 4, "oran_berry": 12, "cheri_berry": 12, "pecha_berry": 12, "sitrus_berry": 12, 
			"chesto_berry": 12, "poke_ball": 5}}, 

	"route22": {"label": "Route 22", "spawn": "r22_grass", "party": [["Charmander", 10], ["Rattata", 8]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex"], "bag": {"potion": 3, "poke_ball": 5}}, 
	"route22_landscape": {"label": "Route 22 — lago e radura sud", "spawn": "r22_east", 
		"party": [["Bulbasaur", 8], ["Pidgey", 6]], "trainer_level": 15, 
		"flags": ["night_prologue_done", "starter_chosen", "has_parcel", "parcel_delivered", "has_pokedex"], 
		"bag": {"potion": 5, "poke_ball": 10}}, 
	"route22_east": {"label": "Route 22 (east)", "spawn": "r22_east", "party": [["Charmander", 10], ["Rattata", 8]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex"], "bag": {"potion": 3, "poke_ball": 5}}, 

	"forest_north": {"label": "Viridian Forest (north gate)", "spawn": "vf_north", "party": [["Charmander", 12], ["Rattata", 10]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex"], "bag": {"potion": 3, "poke_ball": 5}}, 

	"forest_butterfree": {"label": "Viridian Forest (Pale Flower Glade)", "spawn": "vf_butterfree_entry", "party": [["Charmeleon", 18], ["Pidgeotto", 17]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex"], "bag": {"potion": 5, "poke_ball": 10}}, 

	"route3_graveler": {"label": "Route 3 (Boulder Rise)", "spawn": "r4_valley", "room_at": ["Static_r3_boss_graveler", -9.0, -1.0], "snap_ground": true, 

		"party": [["Charmeleon", 22, ["scratch", "growl", "ember", "metal_claw"], ["tackle", "leer", "swift", "slash"]], 
			["Pidgeotto", 21], ["Machoke", 20]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex", "boulder_badge"], 
		"bag": {"potion": 5, "super_potion": 3, "poke_ball": 10}}, 
	"forest_beedrill": {"label": "Viridian Forest (Buzzing Hollow)", "spawn": "vf_beedrill_entry", "party": [["Charmeleon", 18], ["Pidgeotto", 17]], 
		"flags": ["has_parcel", "parcel_delivered", "has_pokedex"], "bag": {"potion": 5, "poke_ball": 10}}, 
}

signal battle_started(fighter, wild)
signal battle_ended(result)
signal party_changed
signal item_used(slot)


var state: = GameStateScript.new()

var whiteout_count: = 0

var _sending: = {}


var _cooldown: = {}

var _passive_t: = 0.0

var _still_s: = 0.0
var _act_pick_t: = 0.0
var _act_now: = 0.0

var _come_owner = null

var _moonlight_busy: = false

var _fetch_owner = null
var _fetch_phase: = ""
var _fetch_left: = 0.0
var _fetch_spot: = Vector3.INF
var _fetch_berry: = ""


var _fetch_item: = "oran_berry"
var _fetch_carry: Sprite3D = null

var _fetch_out_since: = {}



var _fetch_last_s: = -1000000000.0
var _fetch_last_tier: = "Wary"
var _fetch_last_cave: = false

var _drop_n: = 0



var _tired_phase: = {}
var _tired_left: = {}
var _last_ask: = {}
var _tired_frac: = {}
var _rest_tick_t: = 0.0






var party: Array:
	get:
		return state.party
	set(v):
		state.party = v
var flags: Dictionary:
	get:
		return state.flags
	set(v):
		state.flags = v
var companions: Dictionary:
	get:
		return state.companions
	set(v):
		state.companions = v
var bag: Dictionary:
	get:
		return state.bag
	set(v):
		state.bag = v
var selected_ball: String:
	get:
		return state.selected_ball
	set(v):
		state.selected_ball = v
var quick_slots: Array:
	get:
		return state.quick_slots
	set(v):
		state.quick_slots = v
var box: Array:
	get:
		return state.box
	set(v):
		state.box = v
var talking: bool:
	get:
		return state.talking
	set(v):
		state.talking = v
var menu_open: bool:
	get:
		return state.menu_open
	set(v):
		state.menu_open = v
var cutscene: bool:
	get:
		return state.cutscene
	set(v):
		state.cutscene = v




func night_prologue_active() -> bool:
	return bool(state.flags.get("night_prologue_started", false)) and not bool(state.flags.get("night_prologue_done", false))



func start_night_prologue() -> void :
	state.flags["night_prologue_started"] = true
	state.clock_minutes = 0.0


var item_cd: float:
	get:
		return Progression.item_cd
	set(v):
		Progression.item_cd = v
var _capturing: bool:
	get:
		return Progression._capturing
	set(v):
		Progression._capturing = v
var _evolving: Dictionary:
	get:
		return Progression._evolving
	set(v):
		Progression._evolving = v




func _ready() -> void :
	ControlsScript.setup(MAX_PARTY)
	party_changed.connect(_refresh_trail_slots)




func _input(event: InputEvent) -> void :
	ControlsScript.note_device(event)


func _process(delta: float) -> void :
	if get_player() != null and not get_node("/root/BattleTower").running:
		state.play_time += delta
		_regen_pp(delta)
		_friend_tick(delta)
		_wild_friend_tick(delta)
		_wounded_tick(delta)
		_event_cooldown_tick(delta)
		_companion_tick(delta)
		_moonlight_tick()
		_fetch_tick(delta)
		_tired_tick(delta)
	ControlsScript.handle_input(self)




const PP_WORLD_REGEN: = 0.005


func _regen_pp(delta: float) -> void :
	if Battle.in_battle:
		return
	for i in party.size():
		var m = party[i]
		if m.hp <= 0 or m.pp >= m.pp_base:
			continue
		if is_out(i) and String(_tired_phase.get(i, CompanionActionsScript.PHASE_NONE)) == CompanionActionsScript.PHASE_REST:
			continue
		m.pp = minf(m.pp_base, m.pp + m.pp_base * PP_WORLD_REGEN * delta)


		var c = companions.get(i)
		if is_instance_valid(c) and c.mon == m:
			c.combat.pp_max = minf(m.pp, c.combat.pp_base)




func _friend_tick(delta: float) -> void :
	if Battle.in_battle:
		return
	for i in _cooldown.keys():
		var left: = float(_cooldown[i]) - delta
		if left <= 0.0:
			_cooldown.erase(i)
		else:
			_cooldown[i] = left
	_passive_t += delta
	while _passive_t >= PASSIVE_TICK_S:
		_passive_t -= PASSIVE_TICK_S
		for i in party.size():
			if is_out(i) and party[i].hp > 0:
				party[i].set_friend(party[i].friend + PASSIVE_GAIN)






func _companion_tick(delta: float) -> void :
	_act_now += delta
	_bump_all()
	if Battle.in_battle:
		_clear_actions()
		return

	if get_tree().get_first_node_in_group("picnic") != null:
		return
	if is_busy():
		_clear_actions()
		return
	var p: = get_player()
	if p == null:
		return
	var still: = Vector2(p.velocity.x, p.velocity.z).length() < 0.1
	_still_s = _still_s + delta if still else 0.0
	if not still:
		_clear_actions()
		return
	var layout: = _ring_layout(p)
	_act_pick_t -= delta
	if _act_pick_t > 0.0:
		return
	_act_pick_t = ACT_PICK_S
	_assign_actions(layout)



func _ring_layout(p: Node3D) -> Dictionary:
	var outs: Array = []
	for i in party.size():
		if is_out(i) and is_instance_valid(companions.get(i)):
			outs.append(i)
	var rain: = _rain_at(p.global_position)
	var night: = Clock.period() == "night"
	for k in outs.size():
		var c = companions[outs[k]]
		c.ring_slot = k
		c.ring_count = outs.size()
		c.ring_radius = RING_RAIN_RADIUS if rain else RING_RADIUS
		c.come_radius = RING_RAIN_RADIUS if rain else RING_COME_RADIUS
		c.night = night
	return {"outs": outs, "weather": "rain" if rain else "", "night": night}




func _refresh_trail_slots() -> void :
	var out: = []
	for i in party.size():
		out.append(is_out(i))
	var slots: Array = state.out_slots(out)
	for i in party.size():
		var c = companions.get(i)
		if int(slots[i]) >= 0 and c != null and is_instance_valid(c):
			c.trail_slot = int(slots[i])



func _rain_at(pos: Vector3) -> bool:
	var w: = get_tree().get_first_node_in_group("weather")
	if w == null or not w.has_method("coverage_at"):
		return false
	return float(w.coverage_at(pos).get("wet", 0.0)) > RAIN_WET


func _assign_actions(layout: Dictionary) -> void :
	var outs: Array = layout["outs"]
	for k in outs.size():
		var i: int = outs[k]
		var c = companions[i]
		if c.act != CreatureDef.Act.NONE or c.piloted:
			continue
		var a: String = CompanionActionsScript.pick(
			CompanionActionsScript.tier_of(party[i].friend), _still_s, outs.size(), 
			layout["weather"], layout["night"])
		match a:
			CompanionActionsScript.COME:

				if _come_owner == null or not is_instance_valid(_come_owner) or _come_owner.act != CreatureDef.Act.COME:
					_come_owner = c
					c.set_act(CreatureDef.Act.COME)
			CompanionActionsScript.ORBIT:
				c.set_act(CreatureDef.Act.ORBIT)
			CompanionActionsScript.NAP:
				c.set_act(CreatureDef.Act.NAP)
			CompanionActionsScript.PLAY:
				c.set_act(CreatureDef.Act.PLAY)







func _fetch_tick(delta: float) -> void :
	if Battle.in_battle or is_busy() or get_tree().get_first_node_in_group("evolution") != null or get_tree().get_first_node_in_group("picnic") != null:
		_end_fetch()
		return
	if _fetch_owner != null:
		if is_instance_valid(_fetch_owner) and _fetch_owner.act == CreatureDef.Act.FETCH:
			_fetch_advance(delta)
			return
		_end_fetch()
	_fetch_maybe_start()





func _fetch_maybe_start() -> void :
	if is_busy() or get_tree().get_first_node_in_group("evolution") != null:
		return
	var p: = get_player()
	if p == null:
		return

	if _indoors(p):
		return

	var since: = {}
	for i in party.size():
		var c0 = companions.get(i)
		if is_out(i) and is_instance_valid(c0):
			since[c0.get_instance_id()] = float(_fetch_out_since.get(c0.get_instance_id(), _act_now))
	_fetch_out_since = since
	if not CompanionActionsScript.fetch_due(_fetch_last_tier, _act_now, _fetch_last_s, _fetch_last_cave):
		return
	var eligible: Array = []
	for i in party.size():
		if not is_out(i) or party[i].hp <= 0:
			continue
		var c = companions.get(i)
		if is_instance_valid(c) and not c.evolving and not c.piloted and c.act == CreatureDef.Act.NONE\
		and _act_now - float(since[c.get_instance_id()]) >= CompanionActionsScript.FETCH_OUT_MIN_S:
			eligible.append(i)
	if eligible.is_empty():
		return
	var pick_i: int = eligible[randi() % eligible.size()]
	_start_fetch(pick_i, companions[pick_i], p, CompanionActionsScript.tier_of(party[pick_i].friend))




func _start_fetch(i: int, c, p: Node3D, tier: String) -> void :
	_fetch_owner = c
	_fetch_phase = CompanionActionsScript.FETCH_SPOT
	_fetch_left = CompanionActionsScript.FETCH_SPOT_S
	_fetch_spot = _fetch_spot_for(p)


	_fetch_last_cave = _in_cave(p)
	_fetch_item = CompanionActionsScript.fetch_item(_fetch_last_cave, randi())
	if _fetch_item == CompanionActionsScript.BERRY_ORAN:


		_fetch_item = ItemsScript.berry_roll(randi())
		_fetch_berry = PicnicScript.berry_sprite(_fetch_item)
	else:
		_fetch_berry = PicnicScript.mushroom_for_slot(randi(), _fetch_item == CompanionActionsScript.MUSHROOM_BIG)
	c.fetch_target = Vector3.INF
	c.set_act(CreatureDef.Act.FETCH)
	_fetch_last_tier = tier
	_fetch_last_s = _act_now
	var vfx: = get_node_or_null("/root/Vfx")
	if vfx != null:


		vfx.emote("bang", c.head_pos(0.35), 1.0, FETCH_EXCLAIM_S)
	Audio.play_at("sfx/ui/confirm", c.global_position, -4.0)



func _fetch_advance(delta: float) -> void :
	var p: = get_player()
	var c = _fetch_owner
	if p == null or c == null:
		_end_fetch()
		return
	c.fetch_target = _fetch_spot if _fetch_phase == CompanionActionsScript.FETCH_TRAVEL\
	else (p.global_position if _fetch_phase == CompanionActionsScript.FETCH_RETURN else Vector3.INF)
	var arrived: bool = c.fetch_target.is_finite() and _flat_distance(c.global_position, c.fetch_target) <= FETCH_ARRIVE
	var prev: = _fetch_phase
	var r: Array = CompanionActionsScript.fetch_step(_fetch_phase, _fetch_left, delta, arrived)
	_fetch_phase = r[0]
	_fetch_left = float(r[1])
	if _fetch_phase == prev:
		return
	match _fetch_phase:
		CompanionActionsScript.FETCH_PAUSE:
			Audio.cry(c.species, c.global_position)
		CompanionActionsScript.FETCH_RETURN:
			_carry_berry(c)
		CompanionActionsScript.FETCH_DELIVER:
			_drop_fetch_berries(p)
			_end_fetch()




func _drop_fetch_berries(p: Node3D) -> void :
	var pos: Vector3 = p.global_position + p.facing_vector() * FETCH_LEAD
	pos.y = Transitions.ground_y(pos, p.global_position.y)
	_drop_n += 1
	var node: Node3D = ItemPickupScript.new()
	node.uid = "fetch_%d_%d" % [_drop_n, Time.get_ticks_usec()]
	node.ephemeral = true
	node.item_id = _fetch_item
	node.count = 1
	node.visual = _fetch_berry
	node.position = pos
	p.get_parent().add_child(node)






func _in_cave(p: Node3D) -> bool:
	return _room_sun_scale(p) == 0.0



func _indoors(p: Node3D) -> bool:
	var s: = _room_sun_scale(p)
	return s != INF and s != 0.0



func _room_sun_scale(p: Node3D) -> float:
	var scene: = get_tree().current_scene
	if scene == null:
		return INF
	var pos: = Vector2(p.global_position.x, p.global_position.z)

	var buildings: Array = scene.get_children()
	buildings.append(scene)
	for b in buildings:
		var room: = b.get_node_or_null("Room") as Node3D
		if room == null:
			continue
		var size = room.get("size")
		if size == null:
			continue
		if Rect2(Vector2(room.global_position.x, room.global_position.z) - size * 0.5, size).has_point(pos):
			return float(b.get_meta("sun_scale", -1.0))
	return INF




func room_field(p: Node3D) -> String:
	var scene: = get_tree().current_scene
	if scene == null:
		return ""
	var pos: = Vector2(p.global_position.x, p.global_position.z)
	var buildings: Array = scene.get_children()
	buildings.append(scene)
	for b in buildings:
		var room: = b.get_node_or_null("Room") as Node3D
		if room == null:
			continue
		var size = room.get("size")
		if size == null:
			continue
		if Rect2(Vector2(room.global_position.x, room.global_position.z) - size * 0.5, size).has_point(pos):
			return String(b.get_meta("field", ""))
	return ""



func _carry_berry(c) -> void :
	var s: = Sprite3D.new()
	s.texture = load(_fetch_berry)
	s.pixel_size = FETCH_BERRY_M / 16.0
	s.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	s.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
	s.shaded = false
	s.alpha_cut = SpriteBase3D.ALPHA_CUT_DISCARD
	s.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	s.position = Vector3(0, c.look_height() + 0.35, 0)
	c.add_child(s)
	_fetch_carry = s




func _end_fetch() -> void :
	if is_instance_valid(_fetch_owner):
		_fetch_owner.clear_act()
		_fetch_owner.fetch_target = Vector3.INF
	if is_instance_valid(_fetch_carry):
		_fetch_carry.queue_free()
	_fetch_carry = null
	_fetch_owner = null
	_fetch_phase = ""
	_fetch_left = 0.0
	_fetch_spot = Vector3.INF






func _fetch_spot_for(p: Node3D) -> Vector3:
	var rect: = _map_rect()
	var fallback: = p.global_position
	for k in 8:
		var a: = randf() * TAU
		var d: = randf_range(CompanionActionsScript.FETCH_MIN_D, CompanionActionsScript.FETCH_MAX_D)
		var t: Vector3 = p.global_position + Vector3(cos(a), 0.0, sin(a)) * d
		if rect != Rect2() and not rect.grow(2.0).has_point(Vector2(t.x, t.z)):
			continue
		var g: float = Transitions.ground_y(t, INF)
		if not is_finite(g) or absf(g - p.global_position.y) > CreatureDef.LEDGE_HOP_DROP:
			continue
		return Vector3(t.x, g, t.z)

	var a2: = randf() * TAU
	var near: Vector3 = p.global_position + Vector3(cos(a2), 0.0, sin(a2)) * CompanionActionsScript.FETCH_MIN_D
	near.y = Transitions.ground_y(near, fallback.y)
	return near



func _map_rect() -> Rect2:
	var s: = get_tree().get_first_node_in_group("zone_streamer")
	if s == null or String(s.active) == "" or not s.zones.has(s.active):
		return Rect2()
	var r: Array = s.zones[s.active].rect
	return Rect2(float(r[0]), float(r[1]), float(r[2]), float(r[3]))



func _flat_distance(a: Vector3, b: Vector3) -> float:
	return Vector2(a.x - b.x, a.z - b.z).length()




func _bump_all() -> void :
	var list: Array = []
	for i in companions:
		var c = companions[i]
		if is_instance_valid(c) and c.mode == CreatureDef.Mode.FOLLOW:
			list.append(c)
	for a in list.size():
		for b in range(a + 1, list.size()):
			_bump_pair(list[a], list[b], false)
	var p: = get_player()
	if p != null:
		for c in list:
			_bump_pair(c, p, true)


func _bump_pair(a, b, player_b: bool) -> void :
	var d: float = a.global_position.distance_to(b.global_position)
	if d > BUMP_RANGE or d < 0.001:
		return
	var dir: Vector3 = (a.global_position - b.global_position) / d
	a.bump(dir)
	if not player_b:
		b.bump( - dir)





func _moonlight_tick() -> void :
	if _moonlight_busy or Battle.in_battle or is_busy():
		return
	var p: = get_player()
	if p == null:
		return
	var room: = p.get_parent().get_node_or_null("MtMoonGrove")
	if room == null:
		return
	var period: String = Clock.period()
	for i in party.size():
		if not is_out(i) or not is_instance_valid(companions.get(i)):
			continue
		var into: = ""
		for evo in DexData.evolutions(party[i].species):
			into = EvolutionScript.moonlight_target(evo, period, true)
			if into != "":
				break
		if into == "":
			continue
		_moonlight_evolve(i, room, into)
		return


func _moonlight_evolve(i: int, room: Node3D, into: String) -> void :
	_moonlight_busy = true
	await Story.begin()
	var c = companions[i]
	var m = party[i]
	var name: String = m.display_name


	var stone: = room.find_child("GroveMoonStone", true, false) as Node3D
	var target: Vector3 = ((stone.global_position if stone else room.global_position)
		+ Vector3(1.3, 0, 1.9))

	var cam: = get_camera_rig()
	if cam:
		cam.focus_fixed(target, 13.0)


	c.evolving = true
	while is_instance_valid(c):
		var to: Vector3 = target - c.global_position
		to.y = 0.0
		if to.length() <= 0.15:
			break
		var dir: = to.normalized()
		c.facing = dir
		c.global_position += dir * minf(c.move_speed * get_physics_process_delta_time(), to.length())
		c._animate(0.0, false)
		await get_tree().physics_frame
	if not is_instance_valid(c):
		_moonlight_busy = false
		Story.end()
		return
	c.facing = Vector3(0, 0, -1)
	c._animate(0.0, false)
	await Story.say("", ["%s steps into the moonlight." % name])
	await Progression._run_evolution(i, c, into)
	await Story.say("", ["%s evolved into %s!" % [name, m.species]])
	if is_instance_valid(c):
		c.mode = CreatureDef.Mode.FOLLOW
	_moonlight_busy = false
	Story.end()



func _clear_actions() -> void :
	_come_owner = null
	for i in companions:
		var c = companions[i]
		if is_instance_valid(c) and c.act != CreatureDef.Act.NONE and not _is_tired_act(c.act)\
		and c.act != CreatureDef.Act.FETCH:
			c.clear_act()




func egg_walk(metres: float) -> void :
	var eggs: Array = []
	for m in party:
		if m.egg:
			eggs.append(m)
	if eggs.is_empty():
		return
	var s: Vector2 = Daycare.steps_for(metres, state.egg_carry)
	state.egg_carry = s.y
	for m in eggs:
		m.egg_steps = maxi(m.egg_steps - int(s.x), 0)
	if is_busy() or Story.running:
		return
	for m in eggs:
		if m.egg_steps <= 0:
			Story.hatch_egg(m)
			return


func is_busy() -> bool:
	return Battle.in_battle or Battle._ambush or state.talking or Transitions.busy() or state.menu_open or state.cutscene or not get_tree().get_nodes_in_group("evolution").is_empty()




func get_player() -> Node3D:
	return Dialogue.player()



func hero_name() -> String:
	return state.player_name


func get_camera_rig() -> Node:
	return Dialogue.camera_rig()


func get_hud() -> Node:
	return Dialogue.hud()





func _msg(text: String, secs: = 2.5, kind: = "info") -> void :
	Dialogue.msg(text, secs, kind)



const TRAINER_XP_COLOR: = Color("f43f5e")
const BREEDER_XP_COLOR: = Color("4ade80")




func trainer_xp_feedback(gain: int, levels: Array) -> void :
	var p: = get_player()
	if p != null and gain > 0:
		var at: Vector3 = p.global_position + Vector3(0, 1.9, 0)
		Vfx.popup(at, "+%d XP" % gain, TRAINER_XP_COLOR, 0.8)
		if not levels.is_empty():
			Vfx.popup(at, "Trainer Level Up!", TRAINER_XP_COLOR, 0.8)
	if levels.is_empty():
		return
	var lines: Array = []
	for l in levels:
		lines.append_array(TrainerLevel.unlock_lines(int(l), state.ev_read_order))
	var top: = int(levels.back())
	var sub: = ""
	if lines.is_empty():
		var nu: Dictionary = TrainerLevel.next_unlock(top, state.ev_read_order)
		lines.append("You are getting stronger!")
		sub = "" if nu.is_empty() else "Next: Lv%d - %s" % [int(nu.level), String(nu.text)]
	elif lines.size() > 1:
		sub = " · ".join(lines.slice(1))
	var hud: = Dialogue.hud()
	if hud != null and hud.level_card != null:
		hud.level_card.show_card("TRAINER · LEVEL %d" % top, String(lines[0]), sub)




func breeder_xp_feedback(gain: int, levels: Array) -> void :
	var p: = get_player()
	if p != null and gain > 0:
		var at: Vector3 = p.global_position + Vector3(0, 1.9, 0)
		Vfx.popup(at, "+%d XP" % gain, BREEDER_XP_COLOR, 0.8)
		if not levels.is_empty():
			Vfx.popup(at, "Breeder Level Up!", BREEDER_XP_COLOR, 0.8)
	if levels.is_empty():
		return
	var lines: Array = []
	for l in levels:
		lines.append_array(BreederLevel.unlock_lines(int(l), state.iv_read_order))
	var top: = int(levels.back())
	var sub: = ""
	if lines.is_empty():
		var nu: Dictionary = BreederLevel.next_unlock(top, state.iv_read_order)
		lines.append("Your Pokémon trust you more!")
		sub = "" if nu.is_empty() else "Next: Lv%d - %s" % [int(nu.level), String(nu.text)]
	elif lines.size() > 1:
		sub = " · ".join(lines.slice(1))
	var hud: = Dialogue.hud()
	if hud != null and hud.level_card != null:
		hud.level_card.show_card("BREEDER · LEVEL %d" % top, String(lines[0]), sub, BREEDER_XP_COLOR)



func add_breeder_xp(n: int) -> void :
	if n <= 0:
		return
	breeder_xp_feedback(n, state.add_breeder_exp(n))




func picnic_breeder_xp() -> void :
	var now: = Time.get_unix_time_from_system()
	if now - state.picnic_xp_at < BreederLevel.picnic_cooldown_s():
		return
	var n: int = BreederLevel.xp("picnic") * state.party.size()
	if n <= 0:
		return
	state.picnic_xp_at = now
	add_breeder_xp(n)



func open_observe(target: Node) -> void :
	var hud: = Dialogue.hud()
	if hud != null and hud.observe_card != null:
		hud.observe_card.open(target)


func close_observe() -> void :
	var hud: = Dialogue.hud()
	if hud != null and hud.observe_card != null:
		hud.observe_card.close()


func start_dialogue(npc: Node) -> void :
	await Dialogue.start(npc)


func ground_y(pos: Vector3, fallback: = 0.0) -> float:
	return Transitions.ground_y(pos, fallback)



func surface_at(x: float, z: float) -> int:
	return Transitions.surface_at(x, z)



func water_rects() -> Array:
	return Transitions.water_rects()



func water_banks() -> Array:
	return Transitions.water_banks()



func water_level_of(r: Rect2, fallback: = 0.04) -> float:
	return Transitions.water_level_of(r, fallback)


func is_out(i: int) -> bool:
	return state.is_out(i)


func item_count(id: String) -> int:
	return state.item_count(id)


func add_item(id: String, n: = 1) -> void :
	state.add_item(id, n)
	party_changed.emit()


func remove_item(id: String, n: = 1) -> bool:
	if not state.remove_item(id, n):
		return false
	party_changed.emit()
	return true



func give_held(i: int, id: String) -> Dictionary:
	if Battle.in_battle:
		return {"ok": false, "text": "Assign held items outside battle."}
	var result: = state.give_held(i, id)
	if result.ok:
		party_changed.emit()
	return result


func take_held(i: int) -> Dictionary:
	if Battle.in_battle:
		return {"ok": false, "text": "Remove held items outside battle."}
	var result: = state.take_held(i)
	if result.ok:
		party_changed.emit()
	return result




var biking: = false


var registered_item: String:
	get:
		return state.registered_item
	set(v):
		state.registered_item = v


func set_registered_item(id: String) -> void :
	state.registered_item = id


func set_quick_slot(k: int, id: String) -> void :
	state.set_quick_slot(k, id)
	party_changed.emit()


func item_targets_party(id: String) -> bool:
	return state.item_targets_party(id)


func item_battle_usable(id: String) -> bool:
	return state.item_battle_usable(id)


func ball_name(id: String) -> String:
	return state.ball_name(id)






func start_checkpoint(id: String) -> void :
	var cp: Dictionary = CHECKPOINTS.get(id, {})
	if cp.is_empty():
		push_warning("[debug] unknown checkpoint '%s' (have: %s)" % [id, ", ".join(CHECKPOINTS.keys())])
		return
	Debug.log("[debug] checkpoint %s -> %s" % [id, cp.get("spawn", "")])
	_apply_checkpoint(cp)
	SaveGame.enabled = false
	if Debug.save_slot > 0:
		SaveGame.set_slot(Debug.save_slot - 1)
		SaveGame.enabled = true
	await Transitions.go_to(String(cp.get("scene", WORLD_SCENE)), String(cp.get("spawn", "")), true)


	var at: Array = cp.get("room_at", [])
	if at.size() == 3:
		await get_tree().process_frame
		var room: = get_tree().current_scene.find_child(String(at[0]), true, false) as Node3D
		var pl: = get_player()
		if room != null and pl != null:
			pl.global_position = room.global_position + Vector3(float(at[1]), 0.0, float(at[2]))
			if bool(cp.get("snap_ground", false)):
				pl.global_position.y = Transitions.ground_y(pl.global_position, pl.global_position.y)
			Transitions.reset_interp(pl)
			await get_tree().process_frame


	for i in cp.get("out", []):
		var slot: = int(i)
		if slot >= 0 and slot < party.size() and not is_out(slot):
			await send_out(slot)
	for f in cp.get("late_flags", []):
		flags[String(f)] = true
	if cp.has("registered"):
		set_registered_item(String(cp["registered"]))



func cycle_checkpoint() -> void :
	if is_busy():
		return
	Debug._checkpoint_i = (Debug._checkpoint_i + 1) % CHECKPOINTS.size()
	var id: String = CHECKPOINTS.keys()[Debug._checkpoint_i]
	_msg("Checkpoint: %s" % CHECKPOINTS[id].get("label", id), 2.0)
	start_checkpoint(id)


func _apply_checkpoint(cp: Dictionary) -> void :
	Debug.party = false
	party.clear()
	companions.clear()
	for e in cp.get("party", []):
		var m = MonScript.create(String(e[0]), Debug.mon_level if Debug.mon_level > 0 else int(e[1]), null, Debug.shiny)
		if e.size() > 2:
			m.moves = e[2].duplicate()
		if e.size() > 3:
			m.moves2 = e[3].duplicate()
		m.owner = "player"
		party.append(m)

	for e in cp.get("eggs", []):
		var egg = MonScript.create_egg(String(e[0]), int(e[1]))
		egg.owner = "player"
		party.append(egg)
	state.daycare = {}
	if cp.has("daycare"):
		var dm = MonScript.create(String(cp["daycare"][0]), int(cp["daycare"][1]))
		dm.owner = "player"
		var rng_dc: = RandomNumberGenerator.new()
		state.daycare = Daycare.deposit(dm, state.clock_minutes - float(cp["daycare"][2]), rng_dc)
		state.daycare["egg_due"] = state.clock_minutes + float(cp.get("egg_in", 60.0))
	state.box.clear()
	for e in cp.get("box", []):
		var bm = MonScript.create(String(e[0]), int(e[1]))
		bm.owner = "player"
		state.box.append(bm)
	if not party.is_empty():
		flags["starter_" + String(party[0].species).to_lower()] = true
	flags["night_prologue_done"] = true
	flags["oak_stopped"] = true
	flags["starter_chosen"] = true
	flags["rival_battle_done"] = true
	flags["rival_battle_won"] = true
	flags["rival_starter"] = "Charmander"
	for f in cp.get("flags", []):
		flags[String(f)] = true
	for f in cp.get("unset_flags", []):
		flags.erase(String(f))

	if cp.has("league_round"):
		var League = load("res://scripts/league/league.gd")
		League.start_run()
		for i in int(cp["league_round"]):
			League.win_round(120000)

	if cp.has("time"):
		var clock: = get_node_or_null("/root/Clock")
		var t: = String(cp["time"]).split(":")
		if clock != null and t.size() == 2:
			clock.set_time(clock.day_index(), int(t[0]), int(t[1]))
	var tl: = Debug.trainer_level if Debug.trainer_level > 0 else int(cp.get("trainer_level", 0))
	if tl > 0:
		state.set_trainer_level(tl)
		if Debug.trainer_level > 0:
			for m in party:
				m.add_evs({"atk": 100, "spe": 60, "hp": 40})
	var bl: = Debug.breeder_level if Debug.breeder_level > 0 else int(cp.get("breeder_level", 0))
	if bl > 0:
		state.set_breeder_level(bl)

	for m in party:
		if cp.has("hp_frac"):
			m.hp = maxi(1, int(m.max_hp * float(cp.hp_frac)))
		if cp.has("pp_frac"):
			m.pp = m.pp_base * float(cp.pp_frac)

	var b = cp.get("bag", {"potion": 3})
	bag = b.duplicate() if b is Dictionary else {}
	if flags.get("parcel_delivered", false) and not cp.get("no_map", false):
		bag["town_map"] = 1

	state.friends = []
	for fr in cp.get("friends", []):
		state.friends.append({"species": fr[0], "level": fr[1], "f": fr[2]})
	if cp.has("money"):
		state.money = int(cp["money"])
	if cp.has("coins"):
		state.coins = int(cp["coins"])
	party_changed.emit()





const WildRescueScript: = preload("res://scripts/wild_rescue.gd")
const RescueEventScript: = preload("res://scripts/world/rescue_event.gd")

var rescue_event: Node3D = null



var _rescue_asking: = false

func ask_rescue(victim) -> void :
	var ev = rescue_event
	if _rescue_asking or is_busy():
		return
	if ev == null or not is_instance_valid(ev) or ev.victim != victim:
		return
	_rescue_asking = true
	var hud: = get_hud()
	var yes: = true
	if hud != null and hud.has_method("ask_yes_no"):
		yes = await hud.ask_yes_no("", "A %s is cornered! Do you want to help it?" % str(victim.species))
	if not yes:
		_rescue_asking = false
		return
	var boss = ev.boss
	if boss == null or not is_instance_valid(boss):
		_rescue_asking = false
		return
	ev.begin_fight()
	if ev.scripted:
		Battle.extra_foes = ev.attackers.filter( func(a): return a != boss and is_instance_valid(a))
	Battle.engage(boss)
	var result: String = await battle_ended
	_rescue_asking = false
	ev.resolve(WildRescueScript.is_win(result))




const WildWoundedScript: = preload("res://scripts/wild_wounded.gd")
const ItemsScript: = preload("res://scripts/items.gd")

var _wounded_cry_t: = 0.0
var _wounded_alive: = 0.0
var _wounded_node: Node3D = null




func heal_wounded(c) -> void :
	if c == null or not is_instance_valid(c) or String(c.wounded) == "":
		return
	var cond: = String(c.wounded)
	var opts: Array = []
	for id in bag.keys():
		if int(bag[id]) <= 0:
			continue
		var eff: Dictionary = ItemsScript.item(String(id)).get("effect", {})
		if WildWoundedScript.cures(cond, eff):
			opts.append({"id": String(id), 
				"label": "%s  x%d" % [ItemsScript.item_name(String(id)), int(bag[id])]})
	if opts.is_empty():
		_wounded_notice(c, "You don't have anything for %s." % WildWoundedScript.tag(cond).to_lower())
		return
	var hud: = get_hud()
	var pick: = ""
	if hud != null and hud.has_method("ask_choice"):
		pick = await hud.ask_choice("", "A %s is suffering from %s. What do you use?" % [
			str(c.species), WildWoundedScript.tag(cond).to_lower()], opts)
	if pick == "" or not opts.any( func(o): return String(o.id) == pick):
		return
	if not remove_item(pick, 1):
		return
	c.cure_wounded()
	if c.has_meta("tutorial"):
		flags["wounded_tutorial_done"] = true

		var pl: = get_player()
		if pl != null and c.get_parent() != pl.get_parent():
			c.reparent(pl.get_parent())
	_wounded_node = null
	note_event_ended()
	_wounded_notice(c, "%s used a %s! It feels better and follows you." % [
		state.player_name, ItemsScript.item_name(pick)])



func _wounded_notice(c: Node, text: String) -> void :
	var hud: = get_hud()
	if hud != null and is_instance_valid(c):
		var title: String = c.mon.display_name if c.mon != null else String(c.species)
		hud.show_notice(title, text, String(c.species))





const EVENT_GAP: = 300.0


var _event_gap: = 0.0



func note_event_ended() -> void :
	_event_gap = EVENT_GAP


func _event_cooldown_tick(delta: float) -> void :
	if _event_gap > 0.0:
		_event_gap = maxf(_event_gap - delta, 0.0)



func _event_busy() -> bool:
	if _event_gap > 0.0:
		return true
	if rescue_event != null and is_instance_valid(rescue_event):
		return true
	for w in get_tree().get_nodes_in_group("wounded"):
		if is_instance_valid(w):
			return true
	return false





func maybe_spawn_route_event(p: Node3D) -> void :
	if p == null:
		return
	var zone: = event_zone(p)
	if not _hosts_event(zone):
		return
	if zone == "route_1" and not flags.get("wounded_tutorial_done", false):
		_spawn_tutorial_wounded(p)
		return
	if Debug.wounded != "" and not _debug_wounded_done:
		_debug_wounded_done = true
		_spawn_wounded(p, zone, Debug.wounded, 7.0, 10.0)
		return
	if _event_busy():
		return
	if live_friends().size() >= WildFriendScript.MAX_FRIENDS:
		return

	if randf() < 0.5 and not WildRescueScript.row_for(zone).is_empty():
		_spawn_rescue(p, zone)
		return
	_spawn_wounded(p, zone, WildWoundedScript.pick_condition(randf()), 16.0, 26.0)


var _debug_wounded_done: = false



const TUTORIAL_WOUNDED_AT: = Vector2(-0.75, -27.0)

func _spawn_tutorial_wounded(p: Node3D) -> void :
	spawn_tutorial_wounded_in(p.get_parent(), p.global_position.y)





func spawn_tutorial_wounded_in(parent: Node, near_y: = 0.0) -> void :
	if parent == null or party.is_empty() or flags.get("wounded_tutorial_done", false):
		return
	for w in get_tree().get_nodes_in_group("wounded"):
		if is_instance_valid(w) and not w.is_queued_for_deletion():
			return
	var at: = Vector3(TUTORIAL_WOUNDED_AT.x, 0.0, TUTORIAL_WOUNDED_AT.y)
	at.y = ground_y(at, near_y)
	var c = Encounters.spawn_creature({"species": "Rattata", "level_range": [3, 3]}, parent, at, true)
	c.make_wounded(WildWoundedScript.LOW_HP)
	c.set_meta("tutorial", true)
	Debug.log("[N18] tutorial wounded Rattata at %s" % str(at))



func _spawn_wounded(p: Node3D, zone: String, cond: String, min_d: float, max_d: float) -> void :

	var entry: = {}
	var table: = _event_table(p, zone)
	if table != "":
		entry = Encounters.roll(table, "visible", Encounters.ctx_at(p.global_position))
	if entry.is_empty():
		entry = {"species": "Rattata", "level_range": [4, 8]}
	var at: = _event_spot(p, min_d, max_d)
	if not at.is_finite():
		return
	var c = Encounters.spawn_creature(entry, p.get_parent(), at, true)
	c.make_wounded(cond)
	_wounded_node = c
	_wounded_alive = 0.0
	_wounded_cry_t = 1.0
	Debug.log("[N18] wounded %s (%s) at %s" % [str(c.species), cond, str(at)])





const TUTORIAL_FLAG: = "rescue_tutorial_done"
const TUTORIAL_ZONE: = "viridian_forest"
const TUTORIAL_CLEARING: = Vector2(0.0, -280.0)

func spawn_tutorial_standoff() -> Node3D:
	if flags.has(TUTORIAL_FLAG):
		return null
	var zs: = get_tree().get_first_node_in_group("zone_streamer")
	var p: = get_player()
	if zs == null or p == null or String(zs.get("active")) != TUTORIAL_ZONE:
		return null
	if rescue_event != null and is_instance_valid(rescue_event):
		return rescue_event


	var at: = Vector3(TUTORIAL_CLEARING.x, 0.0, TUTORIAL_CLEARING.y)
	at.y = ground_y(at)
	var ev = RescueEventScript.spawn_scripted(p.get_parent(), at, {
		"victim": "Caterpie", "boss": "Kakuna", "others": ["Weedle", "Weedle"], "level": 5})
	if ev != null:
		rescue_event = ev
	return ev



func note_rescue_resolved() -> void :
	flags[TUTORIAL_FLAG] = true



func _spawn_rescue(p: Node3D, zone: String) -> void :
	var at: = _event_spot(p, 20.0, 30.0)
	if not at.is_finite():
		return
	var table: = _event_table(p, zone)
	var band: Vector2i = WildRescueScript.level_band(Encounters.load_table(table)) if table != ""\
	else WildRescueScript.LEVEL_FALLBACK
	var ev = RescueEventScript.spawn(p.get_parent(), at, zone, p, band)
	if ev == null:
		return
	rescue_event = ev




func event_zone(p: Node3D) -> String:
	var zs: = get_tree().get_first_node_in_group("zone_streamer")
	if zs != null:
		return String(zs.get("active"))
	var shell: = _interior_shell()
	if shell == null or p == null:
		return ""
	return _room_id(String(shell.room_at(p.global_position)))




static func _hosts_event(zone: String) -> bool:
	for pre in ["route_", "mt_moon_", "rock_tunnel_"]:
		if zone.begins_with(pre):
			return true
	return false



func _interior_shell() -> Node:
	var scene: = get_tree().current_scene
	return scene if scene != null and scene.has_method("room_at") else null



static func _room_id(room: String) -> String:
	if room == "":
		return ""


	var m: = RegEx.create_from_string("^(.*?)([Bb]?)([0-9]+[Ff])$").search(room)
	if m != null:
		return "%s_%s%s" % [m.get_string(1).to_snake_case(), m.get_string(2).to_lower(), 
			m.get_string(3).to_lower()]
	return room.to_snake_case()




func _event_table(p: Node3D, zone: String) -> String:
	var path: = "res://data/encounters/%s.json" % zone
	if _interior_shell() == null:
		return path if ResourceLoader.exists(path) else ""
	var best: = ""
	var best_d: = INF
	for z in _spawn_zones():
		var d: float = Vector2(z.rect.get_center()).distance_to(Vector2(p.global_position.x, p.global_position.z))
		if d < best_d:
			best_d = d
			best = String(z.zone.get("encounter_table"))
	return best




func _spawn_zones() -> Array:
	var out: Array = []
	var scene: = get_tree().current_scene
	if scene == null:
		return out
	for n in scene.find_children("*", "Node3D", true, false):
		if n.get("encounter_table") == null:
			continue
		var size: Vector2 = n.get("size")
		if size == Vector2.ZERO:
			continue
		var c: Vector3 = n.global_position
		out.append({"zone": n, "rect": Rect2(Vector2(c.x, c.z) - size * 0.5, size)})
	return out











func _outdoor_event_spot(p: Node3D, min_d: float, max_d: float) -> Vector3:
	var flat: = Vector2(p.global_position.x, p.global_position.z)
	var habitats: Array = []
	for z in _spawn_zones():
		if str(z.zone.get("mode")) != "swim":
			habitats.append(z.rect)
	var near_ok: = Vector3.INF
	if not habitats.is_empty():
		for _i in 48:
			var r: Rect2 = habitats[randi() % habitats.size()]
			var at2: = Vector2(r.position.x + randf() * r.size.x, r.position.y + randf() * r.size.y)
			var d: = at2.distance_to(flat)
			if d < 8.0 or d > max_d * 1.6:
				continue
			var at: = _event_ok(p, at2)
			if not at.is_finite():
				continue
			if d >= min_d and d <= max_d:
				return at
			if not near_ok.is_finite():
				near_ok = at
	if near_ok.is_finite():
		return near_ok
	for _i in 24:
		var a: = randf() * TAU
		var at: = _event_ok(p, flat + Vector2(cos(a), sin(a)) * randf_range(min_d, max_d))
		if at.is_finite():
			return at
	return Vector3.INF



func _event_ok(p: Node3D, at2: Vector2) -> Vector3:
	if surface_at(at2.x, at2.y) != Water.Surface.GROUND:
		return Vector3.INF
	var y: = ground_y(Vector3(at2.x, p.global_position.y, at2.y), p.global_position.y)
	if absf(y - p.global_position.y) > 1.2:
		return Vector3.INF
	var ball: = SphereShape3D.new()
	ball.radius = 0.6
	var q: = PhysicsShapeQueryParameters3D.new()
	q.shape = ball
	q.collision_mask = 1
	q.transform = Transform3D(Basis(), Vector3(at2.x, y + 1.0, at2.y))
	if not p.get_world_3d().direct_space_state.intersect_shape(q, 1).is_empty():
		return Vector3.INF
	return Vector3(at2.x, y, at2.y)


func _event_spot(p: Node3D, min_d: float, max_d: float) -> Vector3:
	var shell: = _interior_shell()
	var flat: = Vector2(p.global_position.x, p.global_position.z)
	if shell == null:
		return _outdoor_event_spot(p, min_d, max_d)
	var room: = String(shell.room_at(p.global_position))
	var patches: Array = []
	for z in _spawn_zones():
		if String(shell.room_at(z.zone.global_position)) == room:
			patches.append(z.rect)
	if patches.is_empty():
		return Vector3.INF
	var far: Rect2 = patches[0]
	for r in patches:
		if r.get_center().distance_to(flat) > far.get_center().distance_to(flat):
			far = r
	for _i in 20:
		var r: Rect2 = patches[randi() % patches.size()]
		var at: = Vector3(r.position.x + randf() * r.size.x, p.global_position.y, 
			r.position.y + randf() * r.size.y)
		if Vector2(at.x, at.z).distance_to(flat) < min_d:
			continue
		at.y = ground_y(at, p.global_position.y)
		return at
	var c: = far.get_center()
	var last: = Vector3(c.x, ground_y(Vector3(c.x, p.global_position.y, c.y), p.global_position.y), c.y)
	return last



func _wounded_tick(delta: float) -> void :
	var c = _wounded_node
	if c == null or not is_instance_valid(c) or String(c.wounded) == "":
		if c != null:
			note_event_ended()
		_wounded_node = null
		return
	_wounded_alive += delta
	if _wounded_alive > WildWoundedScript.LIFETIME:
		_wounded_notice(c, "The wounded %s is gone..." % str(c.species))
		c.shed_wounded()
		_wounded_node = null
		note_event_ended()
		return
	_wounded_cry_t -= delta
	if _wounded_cry_t <= 0.0:
		_wounded_cry_t = WildWoundedScript.CRY_EVERY
		Audio.whimper(str(c.species), c.global_position, 0.74, WildWoundedScript.CRY_DB)




const WildFriendScript: = preload("res://scripts/wild_friend.gd")

var _wf_walk_t: = 0.0
var _wf_out: = {}



func live_friends() -> Array:
	var out: Array = []
	for f in state.friend_nodes:
		if is_instance_valid(f) and f.friend >= 0 and not f.is_queued_for_deletion():
			out.append(f)
	state.friend_nodes = out
	return out



func track_friend(c) -> void :
	var l: = live_friends()
	if not l.has(c):
		l.append(c)
	state.friend_nodes = l
	_sync_saved_friends()
	_msg("%s is following you!" % str(c.species), 2.0)



func _sync_saved_friends() -> void :
	var keep: Array = []
	for f in live_friends():
		if WildFriendScript.in_save(f.friend):
			keep.append({"species": str(f.species), "level": int(f.level), 
				"hp": int(f.hp), "f": int(f.friend)})
	state.friends = keep



func _wild_friend_tick(delta: float) -> void :
	var friends: = live_friends()
	if friends.is_empty():
		_wf_walk_t = 0.0
		return
	var p: = get_player()
	_wf_walk_t += delta
	if _wf_walk_t >= WildFriendScript.WALK_EVERY:
		_wf_walk_t -= WildFriendScript.WALK_EVERY
		for f in friends:
			set_friend_value(f, f.friend + 1)
	for f in friends:
		if p == null:
			break
		var far: bool = f.global_position.distance_to(p.global_position) > WildFriendScript.LOST_M
		_wf_out[f] = float(_wf_out.get(f, 0.0)) + delta if far else 0.0
		if _wf_out[f] >= WildFriendScript.LOST_S:
			_wf_out.erase(f)
			_msg("%s gave up and wandered off..." % str(f.species), 2.0)
			state.friend_nodes.erase(f)
			f.shed_friend()
			_sync_saved_friends()



func set_friend_value(c, v: int) -> void :
	var before: int = c.friend
	c.set_friend_value(v)
	if c.friend != before:
		_sync_saved_friends()



func pet_friend(c) -> bool:
	var key: = "wf_%d" % c.get_instance_id()
	if _cooldown.get(key, 0.0) > 0.0:
		_pet_notice(c, "Still happy from your last pat.")
		return false
	_cooldown[key] = PET_CD
	set_friend_value(c, c.friend + WildFriendScript.PET_GAIN)
	if c.has_method("react_pet"):
		c.react_pet()
	_pet_notice(c, "Enjoyed your pat!")
	return true



func feed_friend(c) -> bool:
	var key: = "wf_%d" % c.get_instance_id()
	if _cooldown.get(key, 0.0) > 0.0:
		_msg("It isn't hungry right now.", 1.5)
		return false
	_cooldown[key] = FEED_CD
	set_friend_value(c, c.friend + WildFriendScript.FEED_GAIN)
	if c.has_method("react_feed"):
		c.react_feed()
	return true



func interact_friend(c) -> void :
	if WildFriendScript.can_catch(c.friend):
		throw_at_friend(c)
	else:
		pet_friend(c)



var _friend_asking: = false

func throw_at_friend(c) -> void :
	if _friend_asking or is_busy():
		return

	var ball: = ""
	for b in ["poke_ball", "great_ball", "ultra_ball"]:
		if int(bag.get(b, 0)) > 0:
			ball = b
			break
	if ball == "":
		_ball_notice(c, "No Poké Balls!", "You don't have any to throw.")
		return
	var hud: = get_hud()
	if hud != null and hud.has_method("ask_yes_no"):
		_friend_asking = true
		var yes: bool = await hud.ask_yes_no("", "Do you want to use a %s to catch %s?" % [ItemsScript.item_name(ball), str(c.species)])
		_friend_asking = false
		if not yes or not is_instance_valid(c) or int(bag.get(ball, 0)) <= 0:
			return
	bag[ball] = int(bag.get(ball, 0)) - 1
	var odds: float = WildFriendScript.catch_odds(c.friend)
	if randf() >= odds:
		_ball_notice(c, "Argh!", "It broke free!")
		if c.has_method("bounce"):
			c.bounce(0.4)
		return
	var m = MonScript.create(str(c.species), int(c.level))
	m.owner = "player"
	m.hp = maxi(1, int(c.hp))
	m.set_friend(WildFriendScript.mon_friend(c.friend))
	m.met_zone = SaveGame.location_name() if SaveGame != null else ""
	m.met_level = int(c.level)
	state.mark_caught(m.species)
	if party.size() < 6:
		party.append(m)
	else:
		box.append(m)
	state.friend_nodes.erase(c)
	_sync_saved_friends()
	shed_creature(c)
	party_changed.emit()
	var hud2: = get_hud()
	if hud2 != null:
		hud2.show_notice("Gotcha!", "%s was caught!" % str(m.species), str(m.species))



func _ball_notice(c, title: String, text: String) -> void :
	var hud: = get_hud()
	if hud != null:
		hud.show_notice(title, text, str(c.species) if is_instance_valid(c) else ("Egg" if title == "Egg" else ""))



func shed_creature(c) -> void :
	if is_instance_valid(c):
		if c.friend_bar != null and is_instance_valid(c.friend_bar):
			c.friend_bar.queue_free()
		c.queue_free()




func clear_route_event() -> void :
	rescue_event = null


func respawn_friends(p: Node3D) -> void :
	if state.friends.is_empty() or p == null:
		return
	state.friend_nodes = []
	var i: = 0
	for d in state.friends:
		var m = MonScript.create(str(d.get("species", "Rattata")), int(d.get("level", 5)))
		var a: = TAU * float(i) / float(maxi(state.friends.size(), 1)) + 0.6
		var c = Encounters.spawn_mon(m, p.get_parent(), p.global_position + Vector3(cos(a), 0, sin(a)) * 2.2, false)
		c.make_friend(int(d.get("f", 70)))
		c.hp = int(d.get("hp", c.max_hp))
		i += 1
	_sync_saved_friends()





func receive_starter(sp_name: String, lv: = 5, m = null) -> void :
	if flags.get("starter_chosen", false):
		return
	var mon = state.add_starter(sp_name, lv, m)
	state.mark_caught(sp_name)
	_msg("You received %s!" % sp_name, 3.0)
	Audio.jingle("music/item_get")
	print("[story] starter: %s Lv%d (%s)" % [sp_name, lv, mon.nature])
	party_changed.emit()


func _party_key(i: int, shift: = false) -> void :
	var lan = get_node_or_null("/root/LanCampaign")
	if lan != null and lan.coop_battle_active():
		if not shift: lan.request_party_switch(i)
		return
	print("[pk] key=%d shift=%s picking=%s talking=%s menu=%s ambush=%s intro=%s ending=%s switching=%s cap=%s sending=%s partner=%s" % [i, shift, Battle._picking, state.talking, state.menu_open, Battle._ambush, Battle._intro, Battle._ending, Battle._switching, Progression._capturing, _sending.has(i), is_instance_valid(Battle.partner)])
	if Battle.challenge and ( not BattleTower.is_rental(BattleTower.current) or shift) and not Battle._picking:
		return
	if Battle.online_guest:

		var eng: = get_tree().get_first_node_in_group("online_battle_engine")
		if eng != null:
			eng.request_switch(i)
		return
	if Battle._picking:
		Battle.pick_resolve(i, shift)
		return
	if Battle.in_battle and Battle.is_spar():
		_msg("Only the Pokémon learning the move may fight this spar.")
		return
	if i >= party.size() or state.talking or state.menu_open or Battle._ambush or Battle._intro or Battle._ending or Battle._switching or Progression._capturing or _sending.has(i):
		return
	if is_out(i) and companions[i].evolving:
		_msg("%s is evolving! It can't go back in its ball now." % party[i].display_name, 1.8)
		return
	if Battle.in_battle and is_instance_valid(Battle.partner) and Battle.partner.evolving:
		_msg("%s is evolving!" % Battle.partner.mon.display_name, 1.5)
		return
	if Battle.in_battle:
		if not is_instance_valid(Battle.partner):
			return
		if shift:
			Battle._ally_slot(i)
			return
		if is_out(i) and companions[i] == Battle.partner:
			return
		if is_out(i) and Battle.allies.has(companions[i]):
			Battle.swap_control()
			return
		if party[i].egg:
			_ball_notice(null, "Egg", "An Egg can't battle yet.")
			return
		if party[i].hp <= 0:
			_msg("%s has fainted and can't battle!" % party[i].species)
			return
		Battle._switch_fighter(i)
		return
	if is_out(i):
		recall(i)
	else:
		send_out(i)


func heal_party() -> void :
	state.heal_all()
	for i in party.size():
		if is_out(i):
			companions[i].sync_from_mon()
	_msg("Your party is fully healed!")
	Audio.jingle("music/heal")
	party_changed.emit()



func heal_with_fade() -> void :
	await Transitions.fade(1.0, 0.35)
	heal_party()
	await get_tree().create_timer(1.8).timeout
	await Transitions.fade(0.0, 0.35)




func remember_heal_point(home: = false) -> void :
	var p: = get_player()
	if p == null:
		return
	state.last_heal_point = {
		"scene": get_tree().current_scene.scene_file_path, 
		"pos": [p.global_position.x, p.global_position.y, p.global_position.z], 
		"facing": p.row, 
		"home": home, 
	}



func whiteout() -> void :
	whiteout_count += 1
	var tid: String = Battle._an_trainer_id_of()
	Analytics.track("whiteout", {"zone": _analytics_zone(), "trainer_id": tid, 
		"attempt_n": int(Battle._an_attempts.get(tid, 1)) if tid != "" else whiteout_count})
	var p: = get_player()
	if p:
		p.controls_enabled = false
	var nm: = hero_name()
	var loss: = state.whiteout_loss()
	var lines: = PackedStringArray(["%s is out of usable Pokémon!" % nm])
	if loss > 0:
		lines.append("%s panicked and lost %s..." % [nm, GameStateScript.format_money(loss)])
	lines.append("... ... ... ...")
	lines.append("%s scurried %s, protecting the exhausted Pokémon from further harm..." % [
		nm, "home" if state.is_home_heal_point() else "to a Pokémon Center"])
	var hud: = get_hud()
	if hud:
		hud.open_dialog("", lines)
		await hud.dialog_closed
	Audio.clear_jingles()
	Audio.jingle("music/blackout")
	await Transitions.fade(1.0, 0.6)
	state.whiteout()
	Audio.jingle("music/heal")
	var point: = state.heal_point()
	await Transitions.go_to_at(String(point.get("scene", "")), _heal_pos(point), int(point.get("facing", 0)))
	await get_tree().create_timer(1.0).timeout
	await Transitions.fade(0.0, 0.6)



	cutscene = false
	var np: = get_player()
	if np:
		np.controls_enabled = true



func _analytics_zone() -> String:
	var s: = get_tree().get_first_node_in_group("zone_streamer")
	if s and String(s.get("active")) != "":
		return String(s.get("active"))
	var sc: = get_tree().current_scene
	return String(sc.scene_file_path).get_file().get_basename() if sc else ""



func use_escape_rope() -> bool:
	var p: = get_player()
	if p == null or Battle.in_battle:
		return false
	state.repel_steps = 0
	await _warp_to_point(state.heal_point())
	return true




func reset_position(home: bool) -> void :
	if get_player() == null or Battle.in_battle:
		return
	Analytics.track("reset_position", {"zone": _analytics_zone(), "to": "home" if home else "center"})
	await _warp_to_point(GameStateScript.HOME_HEAL_POINT if home else state.heal_point())



func _warp_to_point(point: Dictionary) -> void :
	menu_open = false
	talking = false
	cutscene = true
	await Transitions.fade(1.0, 0.35)
	await Transitions.go_to_at(String(point.get("scene", "")), _heal_pos(point), int(point.get("facing", 0)))
	await Transitions.fade(0.0, 0.35)
	cutscene = false
	var np: = get_player()
	if np:
		np.controls_enabled = true



func _heal_pos(point: Dictionary) -> Vector3:
	var a = point.get("pos", [])
	if a is Array and a.size() >= 3:
		return Vector3(float(a[0]), float(a[1]), float(a[2]))
	return Vector3.ZERO




const FISH_REACH: = 6.0







func _send_spot(p: Node3D) -> Vector3:
	var from: = p.global_position + Vector3(0, 0.6, 0)
	for dir: Vector3 in [p.facing_vector(), - p.facing_vector()]:
		var to: = from + dir * 2.0
		var q: = PhysicsRayQueryParameters3D.create(from, to, 1)
		q.exclude = [p.get_rid()]
		var hit: = p.get_world_3d().direct_space_state.intersect_ray(q)
		if hit.is_empty():
			return p.global_position + dir * 2.0
		var reach: float = from.distance_to(hit.position) - 0.6
		if reach >= 0.8:
			return p.global_position + dir * reach
	return p.global_position


func send_out(i: int, at = null) -> CreatureDef:
	if is_out(i) or _sending.has(i):
		return companions.get(i)
	if party[i].egg:
		_ball_notice(null, "Egg", "An Egg can't walk with you.")
		return null
	if party[i].hp <= 0:
		_msg("%s has fainted!" % party[i].species)
		return null
	var p: = get_player()
	if p == null:
		return null
	_sending[i] = true
	var target: Vector3 = at if at != null else _send_spot(p)
	target.y = Transitions.ground_y(target, p.global_position.y)


	if Battle.in_battle and Battle.arena_rect.size.x > 0.0:
		target = Battle.nearest_ok(target, party[i], Battle.arena_rect, Battle._blocked_at(target.y))
		target.y = Transitions.ground_y(target, target.y)
	var sent_mon: RefCounted = party[i]



	if not Battle.in_battle and bool(DexData.species(String(sent_mon.species)).get("fish", false)):
		var near: Vector2 = Water.nearest_point_inside(water_rects(), target.x, target.z)
		if not near.is_finite() or near.distance_to(Vector2(target.x, target.z)) > FISH_REACH:
			Dialogue.notice("%s needs water!" % sent_mon.species)
			_sending.erase(i)
			return null
		target = Vector3(near.x, target.y, near.y)
		target.y = Transitions.ground_y(target, target.y)
	var look: = await PokemonSprites.prepare_species(String(sent_mon.species))
	await get_node("/root/Vfx").prepare_shared()
	if not is_instance_valid(p) or i >= party.size() or party[i] != sent_mon:
		_sending.erase(i)
		return null
	await _throw_ball(p.global_position + Vector3(0, 1.2, 0), target, sent_mon.ball)
	if not is_instance_valid(p) or i >= party.size() or party[i] != sent_mon:
		_sending.erase(i)
		return null
	return await _release_body(i, sent_mon, target)




func _release_body(i: int, sent_mon: RefCounted, target: Vector3) -> CreatureDef:
	var p: = get_player()
	var c: = Encounters.spawn_mon(sent_mon, p.get_parent(), target, false)
	if Battle.in_battle:
		Battle.fit_cast(c)
	_restore_cooldowns(c, sent_mon)
	Audio.cry(sent_mon.species, target)
	c.mode = CreatureDef.Mode.IDLE
	companions[i] = c
	c.add_to_group("companion")

	var tw: Tween = get_node("/root/Vfx").send_out_reveal(c)
	if tw != null:
		await tw.finished
	if is_instance_valid(c) and sent_mon.shiny:
		get_node("/root/Vfx").shiny_sparkle(c)
	_sending.erase(i)
	if is_instance_valid(c) and c.mode == CreatureDef.Mode.IDLE:
		c.mode = CreatureDef.Mode.FOLLOW
		c.follow_slot = i
	party_changed.emit()
	return c




func _restore_cooldowns(c: CreatureDef, mon: RefCounted) -> void :
	var s: Dictionary = mon.cd_save
	mon.cd_save = {}
	if s.is_empty() or c == null or c.combat == null:
		return
	var el: = float(Time.get_ticks_msec() - int(s["at"])) / 1000.0
	for k in s["move_cd"].keys():
		var left: = float(s["move_cd"][k]) - el
		if left > 0.0:
			c.combat.move_cd[k] = left
	c.combat.gcd_t = maxf(float(s["gcd"]) - el, 0.0)
	c.combat.evade_cd_t = maxf(float(s["evade"]) - el, 0.0)


func recall(i: int) -> void :
	var rider: = get_player()


	if rider != null and rider.has_method("riding_slot") and rider.riding_slot() == i:
		rider.dismount(true)
	if not is_out(i):
		companions.erase(i)
		return
	var c: CreatureDef = companions[i]
	Audio.play_at("sfx/pokemon/recall", c.global_position)
	if Battle.in_battle:

		Dialogue.msg("Come back, %s!" % c.species, 1.2, "info")
		var tp: = get_player()
		if tp:
			var ball: String = c.mon.ball if c.mon else "poke_ball"
			get_node("/root/Vfx").popup(tp.global_position + Vector3(0, 1.6, 0), "Come back, %s!" % c.species, 
				Battle.CALLOUT_COL, 1.0, "callout", 1, str(tp.get_instance_id()), ball)
	if c.mon != null and c.combat != null:
		c.mon.cd_save = {"move_cd": c.combat.move_cd.duplicate(), "gcd": c.combat.gcd_t, "evade": c.combat.evade_cd_t, 
			"at": Time.get_ticks_msec()}
	companions.erase(i)
	c.remove_from_group("companion")
	c.mode = CreatureDef.Mode.IDLE
	party_changed.emit()
	var p: = get_player()
	if p == null:
		c.queue_free()
		return

	CaptureFX.recall(self, p.get_parent(), p, c, c.mon.ball if c.mon else "poke_ball")


func _throw_ball(from: Vector3, to: Vector3, ball_id: = "poke_ball") -> void :

	await CaptureFX.send_out(self, get_player().get_parent(), from, to, ball_id)





func pet(i: int) -> bool:
	if not _can_friend(i):
		return false
	if _cooldown.get(i, 0.0) > 0.0:
		_pet_notice(companions[i], "Still happy from your last pat.")
		return false
	var m = party[i]
	m.set_friend(m.friend + PET_GAIN)
	_cooldown[i] = PET_CD
	companions[i].react_pet()
	_pet_notice(companions[i], "Enjoyed your pat!")
	add_breeder_xp(BreederLevel.xp("pet"))
	return true


func _pet_notice(c: Node, text: String) -> void :
	var hud: = get_hud()
	if hud != null:
		var title: String = c.mon.display_name if c.mon != null else c.species
		hud.show_notice(title, text, c.species)



func feed(i: int) -> bool:
	if not _can_friend(i):
		return false
	if _cooldown.get(i, 0.0) > 0.0:
		_msg("%s isn't hungry right now." % party[i].display_name)
		return false
	var m = party[i]
	m.set_friend(m.friend + FEED_GAIN)
	_cooldown[i] = FEED_CD
	companions[i].react_feed()
	add_breeder_xp(BreederLevel.xp("feed"))
	return true



func _can_friend(i: int) -> bool:
	if i < 0 or i >= party.size() or not is_out(i) or party[i].hp <= 0:
		return false
	var c = companions[i]
	if c.hopping or c.evolving:
		return false
	return not is_busy() and not Progression._capturing and not _sending.has(i)







func _tired_tick(delta: float) -> void :
	if Battle.in_battle or is_busy() or get_tree().get_first_node_in_group("picnic") != null:
		_clear_tired()
		return
	var p: = get_player()
	if p == null:
		_clear_tired()
		return
	var walking: = Vector2(p.velocity.x, p.velocity.z).length() > 0.1
	for i in party.size():
		if not is_out(i) or not is_instance_valid(companions.get(i)):
			continue
		var c = companions[i]
		var m = party[i]
		var phase: = String(_tired_phase.get(i, CompanionActionsScript.PHASE_NONE))
		if phase == CompanionActionsScript.PHASE_ASK or phase == CompanionActionsScript.PHASE_SIT:
			var step: Array = CompanionActionsScript.ask_step(phase, float(_tired_left.get(i, 0.0)), delta)
			_tired_phase[i] = step[0]
			_tired_left[i] = float(step[1])
			if int(step[2]) != 0:
				m.set_friend(m.friend + int(step[2]))
			if step[0] == CompanionActionsScript.PHASE_SIT:
				c.set_act(CreatureDef.Act.SIT)
			elif step[0] == CompanionActionsScript.PHASE_NONE:
				c.clear_act()
		elif phase == CompanionActionsScript.PHASE_REST:
			var left: = float(_tired_left.get(i, 0.0)) - delta
			_tired_left[i] = left
			if left <= 0.0:
				_tired_phase[i] = CompanionActionsScript.PHASE_NONE
				c.clear_act()
		elif walking and c.act == CreatureDef.Act.NONE and m.hp > 0\
		and CompanionActionsScript.tired(m.hp, m.max_hp, m.pp, m.pp_base)\
		and CompanionActionsScript.can_ask(_act_now, float(_last_ask.get(i, -1000000000000.0))):
			_tired_phase[i] = CompanionActionsScript.PHASE_ASK
			_tired_left[i] = CompanionActionsScript.ASK_WAIT_S
			_last_ask[i] = _act_now
			c.set_act(CreatureDef.Act.ASK)
	_rest_tick_t += delta
	while _rest_tick_t >= PicnicScript.TICK:
		_rest_tick_t -= PicnicScript.TICK
		_rest_regen_tick()



func rest_with(i: int) -> bool:
	if not _can_friend(i):
		return false
	if String(_tired_phase.get(i, CompanionActionsScript.PHASE_NONE)) != CompanionActionsScript.PHASE_ASK:
		return false
	var m = party[i]
	m.set_friend(m.friend + CompanionActionsScript.REST_FRIEND)
	_tired_phase[i] = CompanionActionsScript.PHASE_NONE
	_tired_left[i] = 0.0
	_last_ask[i] = _act_now
	companions[i].clear_act()
	recall(i)
	return true



func _rest_regen_tick() -> void :
	for i in _tired_phase.keys():
		if String(_tired_phase.get(i, CompanionActionsScript.PHASE_NONE)) != CompanionActionsScript.PHASE_REST:
			continue
		if not is_out(i):
			continue
		var m = party[i]
		if m.hp <= 0:
			continue
		var step: Array = PicnicScript.hp_step(m.hp, m.max_hp, float(_tired_frac.get(i, 0.0)))
		m.hp = int(step[0])
		_tired_frac[i] = float(step[1])
		m.pp = PicnicScript.pp_step(m.pp, m.pp_base, PP_WORLD_REGEN)
		var c = companions.get(i)
		if is_instance_valid(c) and c.mon == m:
			c.hp = m.hp
			c.combat.pp_max = minf(m.pp, c.combat.pp_base)



func _clear_tired() -> void :
	var active: = false
	for i in _tired_phase.keys():
		if String(_tired_phase[i]) != CompanionActionsScript.PHASE_NONE:
			active = true
		_tired_phase[i] = CompanionActionsScript.PHASE_NONE
		_tired_left[i] = 0.0
	if not active:
		return
	for i in companions:
		var c = companions[i]
		if is_instance_valid(c) and _is_tired_act(c.act):
			c.clear_act()



func _is_tired_act(a: int) -> bool:
	return a == CreatureDef.Act.ASK or a == CreatureDef.Act.SIT or a == CreatureDef.Act.REST

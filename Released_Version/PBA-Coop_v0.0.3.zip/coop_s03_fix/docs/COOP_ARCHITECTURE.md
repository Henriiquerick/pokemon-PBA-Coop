# Atualizacao S3 Fix

Estado atual: todos os companheiros visuais, marcador no minimapa, clima coordenado pelo host e XP/conclusao unica dos encontros integrados. O XP desta entrega cobre os dois participantes ativos; reservas, dinheiro, insignias e historia continuam na S4. GUIA_FIX.md e RELATORIO_FIX.md descrevem as evidencias atuais. Notas anteriores abaixo sao historicas.

# Atualizacao S3

S3 acrescenta perfil persistente individual, IDs, backup e recuperacao. Consulte COOP_SAVE_FORMAT.md e S03_TEST_RESULTS.md para o estado atual. As notas de S01/S02 abaixo descrevem o checkpoint anterior; a limitacao de falta de gravacao foi substituida pela S3. Recompensas cooperativas, insignias, XP compartilhada e trocas continuam nas etapas seguintes.

# Arquitetura auditada — Subsprint 01

Exportação Windows Godot 4.7.1, sem projeto editável completo. O patch recompila GDScript com GDRETools e substitui recursos em uma cópia validada do PCK. O instalador compara recursos não modificados e valida Thunder Stone e evolução de Haunter por troca. EXE, DLLs, PCK completo e saves pessoais não fazem parte do ZIP distribuído.

## Fluxo atual

- `front_end.gd`: reconhece argumentos e adiciona `LanCampaign` na raiz; execução solo mantém a entrada original.
- `campaign.gd`: sessão ENet para dois PCs, importação de save, presença, mapas, batalha, representações remotas, clima e piquenique visual. Ainda concentra responsabilidades demais.
- `trainer.gd`: intercepta encontros elegíveis, bloqueia outros; permite repetir os treinadores de teste.
- `battle.gd`: aliados e adversários extras, controle remoto, encerramento cooperativo e permissão para selvagens locais.
- `combatant.gd`: separa intenção remota do input original. O host simula colisão, IA e dano; guest representa o estado recebido.
- `encounters.gd`: libera encontros originais fora da preparação/luta cooperativa.
- `save_game.gd`: bloqueia gravações enquanto o nó LAN existe. Isto é isolamento de teste, não persistência cooperativa.
- `iniciar_campanha.py`: copia o save pessoal, valida Pokémon apto, isola APPDATA, executa jogo e registra código de saída.

## Rede e movimento

ENet por IP direto, porta 24620; protocolo S01 `pba-campaign-lan-10-s01`. Ambos precisam do mesmo patch. RPCs relevantes conferem remetente e número do encontro. Presença usa canal 1 com ordenação não confiável, aproximadamente 20 Hz; movimento do guest em batalha é enviado a 30 Hz; estados de batalha a até 20 Hz. Ações e transições críticas são confiáveis. Heartbeat a cada 500 ms, timeout de 45 s. Preparação aguarda até 60 s.

No mapa, cada jogador simula seu personagem local imediatamente. A presença remota atribui posição e frame diretamente, sem buffer de interpolação. Em combate, não há previsão completa do guest: o host aplica intenção e envia estados. Não há evidência para atribuir todo atraso apenas à VPN. Carregamento de cena, preparação de sprites e gravação frequente do audit no disco também precisam ser medidos.

S01 acrescenta RTT medido no relógio local, variação suavizada do RTT, probes enviados/respondidos/expirados, totais de mensagens de presença e snapshots, último intervalo de presença, FPS e maior intervalo de frame por janela de dois segundos. Probes expirados não medem diretamente perda de pacotes ENet; contadores não representam todo tráfego nem bytes. `max_frame_ms` mede espaçamento de frames, não perfil detalhado da CPU. Não há reconciliação/interpolação nova nesta subsprint.

## Persistência e conteúdo

Cada lado importa seu estado individual e posição do save. A luta cooperativa restaura time, dinheiro e flags; recompensas não persistem. Não há identidade persistente de sessão ou transação de recompensa. `Mon.ensure_ot_id` identifica treinador de origem; não comprova identidade única global de cada Pokémon. Antes de persistir, definir UUIDs e migração sem apagar IDs de origem.

`TradeSession` nativo possui revisões de oferta e confirmação dupla; `TradeApply` valida/recebe Pokémon e consulta evolução por troca. Não foi demonstrada atomicidade recuperável entre dois arquivos em PCs diferentes. Reaproveitar interface e regras após acrescentar journal e recuperação na Subsprint 06.

Spawns e loot são locais ao estado de cada PC; não há coordenador de spawn compartilhado ou journal individual de consumo de spawn. Inventário e flags originais são candidatos a reuso, após persistência segura. A matriz do catálogo não autoriza automaticamente encontros especiais ou insígnias.

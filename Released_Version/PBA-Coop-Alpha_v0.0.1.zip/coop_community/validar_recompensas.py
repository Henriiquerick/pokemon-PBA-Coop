"""Repair an old co-op Brock win using production startup; reopen without payout duplication."""
from pathlib import Path
import argparse,json,os,subprocess
HERE=Path(__file__).resolve().parent
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--runtime',type=Path,required=True);ap.add_argument('--logs',type=Path,required=True)
    a=ap.parse_args();runtime=a.runtime.resolve();base=a.logs.resolve();base.mkdir(parents=True,exist_ok=False)
    user=base/'userdata/Godot/app_userdata'/('Pok'+chr(233)+'mon Battle Advanced');user.mkdir(parents=True)
    doc=json.loads((HERE/'fixtures/host.json').read_text(encoding='utf8'))
    doc['state']['flags']['coop_done_brock']=True
    (user/'campaign_input.json').write_text(json.dumps(doc),encoding='utf8')
    env=os.environ.copy();env['APPDATA']=str(base/'userdata');states=[]
    for name in ['repair','reopen']:
        p=subprocess.run([str(runtime/'PokemonBattleAdvanced.exe'),'--headless','--','--coop-campaign','--coop-role=offline','--coop-start=save','--coop-persist-smoke'],cwd=runtime,env=env,capture_output=True,timeout=70)
        text=(p.stdout+p.stderr).decode('utf8','replace');(base/(name+'.log')).write_text(text,encoding='utf8')
        assert p.returncode==0 and 'SCRIPT ERROR' not in text,(name,text[-2000:])
        d=json.loads(json.loads((user/'coop_s3/profile.json').read_text(encoding='utf8'))['payload']);state=d['snapshot']['state'];states.append(state)
        assert state['money']==doc['state']['money']+1900
        assert 'boulder' in state['badges'] and state['bag']['tm39']==1
        assert state['flags']['boulder_badge'] and state['flags']['trainer_brock'] and state['flags']['coop_rewards_brock']
        if name=='repair':assert '"repair":true' in text
        else:assert 'trainer_rewards"' not in text
    assert states[0]['party'][0]['coop_uid']==states[1]['party'][0]['coop_uid']
    result={'passed':True,'old_win_repaired':True,'money':states[-1]['money'],'badge':'boulder','tm39':1,'native_story_flags':True,'reopen_no_double_reward':True}
    (base/'result.json').write_text(json.dumps(result,indent=2),encoding='utf8');print(json.dumps(result))

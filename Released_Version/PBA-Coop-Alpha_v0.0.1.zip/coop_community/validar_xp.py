from pathlib import Path
import os,json,subprocess,time,argparse,hashlib
from validar_campanha import run,HERE

def main(runtime,logs):
    result=run(runtime,logs,'ui',25143,False,'youngster_ryan',False,'route2')
    base=logs/'ui';initial={};awards={};ps=[]
    def data(role):
        p=next((base/('userdata_'+role)).rglob('profile.json'))
        return json.loads(json.loads(p.read_text(encoding='utf8'))['payload'])
    for role in ['host','guest']:
        rows=[json.loads(s) for s in (base/(role+'.jsonl')).read_text(encoding='utf8').splitlines()]
        award=next(r for r in rows if r['event']=='coop_xp');awards[role]=award
        fixture=json.loads((HERE/'fixtures'/(role+'.json')).read_text(encoding='utf8'))
        d=data(role);initial[role]=d['snapshot']['state']['party'][0]['xp']
        assert initial[role]==fixture['state']['party'][0]['xp']+award['gain']
        assert d['snapshot']['state']['flags']['coop_done_youngster_ryan'] is True
    assert awards['host']['pool']==awards['guest']['pool']
    # These fixtures use their original trainer IDs, so no traded-mon multiplier.
    assert awards['host']['gain']+awards['guest']['gain']==awards['host']['pool']
    # Isolate the completed-trainer guard from another legitimate trainer's
    # sight corridor. Only fixture position changes; XP/flags remain untouched.
    for role in ['host','guest']:
        path=next((base/('userdata_'+role)).rglob('profile.json'))
        envelope=json.loads(path.read_text(encoding='utf8'));doc=json.loads(envelope['payload'])
        doc['snapshot']['pos']=[-20 if role=='host' else -22,0,-220]
        payload=json.dumps(doc);envelope['payload']=payload;envelope['sha256']=hashlib.sha256(payload.encode('utf8')).hexdigest()
        path.write_text(json.dumps(envelope),encoding='utf8')
    try:
        for role in ['host','guest']:
            env=os.environ.copy();env['APPDATA']=str(base/('userdata_'+role))
            f=(base/(role+'_guard.log')).open('w',encoding='utf8')
            cmd=[str(runtime/'PokemonBattleAdvanced.exe'),'--headless','--','--coop-campaign','--coop-role='+role,'--coop-port=25144','--coop-start=save','--coop-autotest','--coop-persist-test','--coop-test=guard']
            p=subprocess.Popen(cmd,cwd=runtime,env=env,stdout=f,stderr=f);ps.append((role,p,f));time.sleep(1)
        for role,p,f in ps:
            p.wait(timeout=65);f.close()
            text=(base/(role+'_guard.log')).read_text(encoding='utf8')
            assert p.returncode==0 and 'SCRIPT ERROR' not in text,(role,p.returncode,text[-1000:])
            rows=[json.loads(s.split('[campaign-lan] ',1)[1]) for s in text.splitlines() if '[campaign-lan] {' in s]
            guard=next(r for r in rows if r['event']=='completion_guard')
            assert guard['beaten'] and not guard['can_trigger'] and guard['xp']==initial[role],guard
            assert not any(r['event']=='battle_started' for r in rows)
            assert data(role)['snapshot']['state']['party'][0]['xp']==initial[role]
    finally:
        for _,p,f in ps:
            if p.poll() is None:p.kill();p.wait()
            f.close()
    report={'passed':True,'awards':awards,'pool_divided_once':True,'reopen_blocks_repeated_encounter':True,'xp_unchanged_on_reconnect':True,'battle':result}
    (logs/'xp_result.json').write_text(json.dumps(report,indent=2),encoding='utf8');print(json.dumps(report))

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--runtime',required=True,type=Path);ap.add_argument('--logs',required=True,type=Path)
    a=ap.parse_args();main(a.runtime.resolve(),a.logs.resolve())

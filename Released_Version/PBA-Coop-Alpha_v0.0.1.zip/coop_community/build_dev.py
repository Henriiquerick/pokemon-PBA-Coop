from pathlib import Path
import os,sys,subprocess,json,hashlib,shutil
ROOT=Path(__file__).resolve().parent
WORK=ROOT.parent
sys.path.insert(0,str(ROOT))
from packtools import patch

def generate_hooks():
    original=(WORK/'coop_lab/decompiled/front_end.gd').read_text(encoding='utf8')
    bootstrap='''func _ready() -> void :
	if "--coop-campaign" in OS.get_cmdline_user_args():
		SaveGame.enabled = false
		set_process(false)
		set_process_input(false)
		set_process_unhandled_input(false)
		var session = load("res://coop/campaign.gd").new()
		session.name = "LanCampaign"
		get_tree().root.add_child.call_deferred(session)
		return
	if "--coop" in OS.get_cmdline_user_args():
		set_process(false)
		set_process_input(false)
		set_process_unhandled_input(false)
		get_tree().change_scene_to_file.call_deferred("res://coop/arena.tscn")
		return
	print("[campaign-lan] solo_original_boot")
	_normal_ready()

func _normal_ready() -> void :'''
    (ROOT/'src/front_end.gd').write_text(original.replace('func _ready() -> void :',bootstrap,1),encoding='utf8')
    t=(WORK/'coop_lab/decompiled/trainer.gd').read_text(encoding='utf8')
    t=t.replace('func can_see(p: Node3D) -> bool:', '''func can_see(p: Node3D) -> bool:
	var lan = get_node_or_null("/root/LanCampaign")
	if lan != null and lan.blocks_trainer(self): return false''',1)
    t=t.replace('func _beaten() -> bool:', '''func _beaten() -> bool:
	var lan = get_node_or_null("/root/LanCampaign")
	if lan != null and trainer_id in lan.route_trainers: return false''',1)
    t=t.replace('func _battle_sequence(show_intro: bool) -> String:', '''func _battle_sequence(show_intro: bool) -> String:
	var lan = get_node_or_null("/root/LanCampaign")
	if lan != null:
		if lan.can_trigger(self): return await lan.trainer_encounter(self)
		_spotting = false
		Game.cutscene = false
		if Dialogue.player() != null: Dialogue.player().controls_enabled = true
		return "aborted"''',1)
    (ROOT/'src/trainer.gd').write_text(t,encoding='utf8')
    b=(WORK/'coop_lab/decompiled/battle.gd').read_text(encoding='utf8')
    b=b.replace('func _foe_mode() -> int:', '''func _foe_mode() -> int:
	if get_node_or_null("/root/LanCampaign") != null and launching_lan(): return CreatureDef.Mode.BATTLE_AI''',1)
    b += '''\nfunc launching_lan() -> bool:
	var lan = get_node_or_null("/root/LanCampaign")
	return lan != null and lan.allow_campaign_battle()
'''
    b=b.replace('func _fighter_mode(c: CreatureDef) -> int:', '''func _fighter_mode(c: CreatureDef) -> int:
	if c.has_meta("lan_remote"): return CreatureDef.Mode.REMOTE''',1)
    b=b.replace('func _on_fainted(c: CreatureDef) -> void :','''func _on_fainted(c: CreatureDef) -> void :
	var lan = get_node_or_null("/root/LanCampaign")
	if lan != null and launching_lan():
		lan.fainted(c)
		return''',1)
    # Do not let wild, Safari or dialogue events start a second encounter.
    b=b.replace('func start_battle(w: CreatureDef, training: = false) -> void :','''func start_battle(w: CreatureDef, training: = false) -> void :
	var lan = get_node_or_null("/root/LanCampaign")
	if lan != null and not launching_lan(): return''',1)
    # Input that switches local control must never seize the remote player's body.
    b=b.replace('func swap_control() -> void :','''func swap_control() -> void :
	if get_node_or_null("/root/LanCampaign") != null: return''',1)
    b=b.replace('func _switch_fighter(i: int, forced: = false) -> void :','''func _switch_fighter(i: int, forced: = false) -> void :
	if get_node_or_null("/root/LanCampaign") != null: return''',1)
    for signature in ['func request_loadout_swap(c: Node) -> bool:', 'func commit_loadout_swap(c: Node) -> bool:']:
        b=b.replace(signature,signature+'\n\tif get_node_or_null("/root/LanCampaign") != null: return false',1)
    b=b.replace('if allies.size() > 1:\n\t\textra =', 'if allies.size() > 1 and get_node_or_null("/root/LanCampaign") == null:\n\t\textra =',1)
    (ROOT/'src/battle.gd').write_text(b,encoding='utf8')
    e=(WORK/'coop_lab/decompiled/encounters.gd').read_text(encoding='utf8')
    for signature in ['func grass_encounter(p: Node3D, table: String) -> void :','func surf_encounter(p: Node3D, table: String) -> void :']:
        e=e.replace(signature,signature+'\n\tif get_node_or_null("/root/LanCampaign") != null: return',1)
    (ROOT/'src/encounters.gd').write_text(e,encoding='utf8')
    save=(WORK/'coop_lab/decompiled/save_game.gd').read_text(encoding='utf8')
    save=save.replace('static func write(d: Dictionary) -> bool:', '''static func write(d: Dictionary) -> bool:
	if Game.get_node_or_null("/root/LanCampaign") != null: return false''',1)
    (ROOT/'src/save_game.gd').write_text(save,encoding='utf8')

def build():
    generate_hooks()
    env=os.environ.copy(); env['APPDATA']=str(ROOT/'build_userdata')
    Path(env['APPDATA']).mkdir(exist_ok=True)
    files=['front_end','campaign','trainer','battle','encounters','save_game']
    args=[str(WORK/'coop_lab/tools/gdre/gdre_tools.exe'),'--headless','--bytecode=4.7.1','--output='+str(ROOT/'payload')]
    args+=['--compile='+str(ROOT/'src'/(f+'.gd')) for f in files]
    with (ROOT/'logs/compile.txt').open('w',encoding='utf8') as out:
        subprocess.run(args,stdout=out,stderr=out,env=env,timeout=60,check=True)
    changes={
        'scripts/front/front_end.gdc':(ROOT/'payload/front_end.gdc').read_bytes(),
        'scripts/trainer.gdc':(ROOT/'payload/trainer.gdc').read_bytes(),
        'scripts/battle.gdc':(ROOT/'payload/battle.gdc').read_bytes(),
        'scripts/encounters.gdc':(ROOT/'payload/encounters.gdc').read_bytes(),
        'scripts/state/save_game.gdc':(ROOT/'payload/save_game.gdc').read_bytes(),
        'coop/campaign.gdc':(ROOT/'payload/campaign.gdc').read_bytes(),
        'coop/campaign.gd.remap':b'[remap]\npath="res://coop/campaign.gdc"\n',
        'coop/arena.gdc':(ROOT/'payload/arena.gdc').read_bytes(),
        'coop/arena.gd.remap':b'[remap]\npath="res://coop/arena.gdc"\n',
        'coop/arena.tscn':(ROOT/'src/arena.tscn').read_bytes(),
    }
    runtime=WORK/'coop_lab/campaign_runtime';runtime.mkdir(exist_ok=True)
    for name in ['PokemonBattleAdvanced.exe','discord_game_sdk.dll','libdiscord_game_sdk_binding.dll','libwebrtc_native.windows.template_release.x86_64.dll']:
        if not (runtime/name).exists():shutil.copy2(WORK/name,runtime/name)
    dest=runtime/'PokemonBattleAdvanced.pck.tmp'
    patch(WORK/'PokemonBattleAdvanced.mod.pck',dest,changes)
    os.replace(dest,runtime/'PokemonBattleAdvanced.pck')
    for folder,names in [('addons/discord-rpc-gd/bin/windows',['discord_game_sdk.dll','libdiscord_game_sdk_binding.dll']),('addons/webrtc_native/lib',['libwebrtc_native.windows.template_release.x86_64.dll'])]:
        d=runtime/folder;d.mkdir(parents=True,exist_ok=True)
        for name in names:
            if not (d/name).exists():shutil.copy2(WORK/name,d/name)
    manifest={str(f.relative_to(ROOT)).replace('\\','/'):hashlib.sha256(f.read_bytes()).hexdigest() for f in (ROOT/'payload').glob('*.gdc')}
    for f in list((ROOT/'src').glob('*.gd')) + [ROOT/'src/arena.tscn']:
        manifest[f.relative_to(ROOT).as_posix()] = hashlib.sha256(f.read_bytes()).hexdigest()
    (ROOT/'payload/manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf8')
    print('Built campaign runtime',flush=True)

if __name__=='__main__':build()

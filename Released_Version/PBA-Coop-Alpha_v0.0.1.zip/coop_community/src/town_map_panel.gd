class_name TownMapPanel
extends Control











signal travel_requested(place: Dictionary)
signal closed

const DATA_PATH: = "res://data/town_map.json"
const UI: = preload("res://scripts/ui/ui_draw.gd")

const SEA: = Color8(24, 207, 208)
const MARKER: = 17.0
const LANDMARK: = 8.0
const PICK_RADIUS: = 44.0

var places: Array = []
var visited: = {}
var here: = ""
var index: = 0
var active: = false
var read_only = false
var partner_zone = ""
var partner_connected = false
var partner_info = ""

var _tex: Texture2D
var _t: = 0.0
var _shake: = 0.0
var _armed_frame: = -1
var _header: PkHeaderBar
var _hints: PkHintBar
var _confirm: PkMenuList
var _confirm_card: PanelContainer
var _confirm_label: Label


func _init() -> void :
	theme = UiKit.theme()
	UiKit.setup_input()
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	visible = false
	var data: Dictionary = JSON.parse_string(FileAccess.get_file_as_string(DATA_PATH))
	places = data.get("places", [])
	_tex = load(String(data.get("image", "")))
	_header = PkHeaderBar.new()
	_header.screen_title = "TOWN MAP"
	_header.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
	_header.offset_bottom = PkHeaderBar.HEIGHT
	add_child(_header)

	_hints = PkHintBar.new()
	_hints.anchor_left = 1.0
	_hints.anchor_right = 1.0
	_hints.grow_horizontal = Control.GROW_DIRECTION_BEGIN
	_hints.alignment = BoxContainer.ALIGNMENT_END
	_hints.offset_right = - PkHintBar.INSET
	_hints.offset_top = (PkHeaderBar.HEIGHT - PkHintBar.HEIGHT) * 0.5
	_hints.offset_bottom = _hints.offset_top + PkHintBar.HEIGHT
	add_child(_hints)
	_build_confirm()
	UiKit.connect_version(queue_redraw)


func _build_confirm() -> void :
	_confirm_card = PanelContainer.new()
	_confirm_card.add_theme_stylebox_override("panel", UiKit.window_box())
	_confirm_card.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	_confirm_card.visible = false
	var box: = VBoxContainer.new()
	box.add_theme_constant_override("separation", 12)
	_confirm_card.add_child(box)
	_confirm_label = Label.new()
	_confirm_label.add_theme_font_override("font", UiKit.header_font())
	_confirm_label.add_theme_font_size_override("font_size", UiKit.SIZE_HEADER)
	_confirm_label.add_theme_color_override("font_color", UiKit.SLATE_900)
	_confirm_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(_confirm_label)
	_confirm = PkMenuList.new()
	_confirm.active = false
	_confirm.custom_minimum_size = Vector2(360, 0)
	_confirm.chosen.connect(_on_confirm_chosen)
	_confirm.cancelled.connect(_close_confirm)
	box.add_child(_confirm)
	add_child(_confirm_card)





func open(visited_ids: Array, here_id: = "") -> void :
	visited = {}
	for v in visited_ids:
		visited[String(v)] = true
	here = here_id
	var at: = find(here)
	index = at if at >= 0 else 0
	visible = true
	active = true
	_armed_frame = Engine.get_process_frames()
	_close_confirm()
	UiKit.pop_in(self)
	UiKit.sfx("menu_open")
	_refresh()


func close() -> void :
	if not visible:
		return
	active = false
	_close_confirm()
	UiKit.sfx("menu_close")
	visible = false
	closed.emit()




static func visited_from(flags: Dictionary, list: Array) -> Array:
	var out: = []
	for p in list:
		var id: = String(p.id)
		var badge: = String(p.get("badge", ""))
		if id == "pallet_town" or flags.get("visited_" + id, false) or (badge != "" and flags.get(badge, false)):
			out.append(id)
	return out


func find(id: String) -> int:
	for i in places.size():
		if String(places[i].id) == id:
			return i
	return -1


func selected() -> Dictionary:
	return places[index] if index >= 0 and index < places.size() else {}


func is_town(p: Dictionary) -> bool:
	return String(p.get("kind", "")) != "landmark"



func can_travel(p: Dictionary) -> bool:
	if read_only: return false
	return is_town(p) and visited.has(String(p.id)) and String(p.id) != here and String(p.get("spawn", "")) != ""


func visited_towns() -> Array:
	var out: = []
	for p in places:
		if is_town(p) and visited.has(String(p.id)):
			out.append(p)
	return out


func select(i: int) -> void :
	if i == index or i < 0 or i >= places.size():
		return
	index = i
	UiKit.sfx("cursor")
	_refresh()





func image_rect() -> Rect2:
	var area: = Rect2(0, PkHeaderBar.HEIGHT, size.x, size.y - PkHeaderBar.HEIGHT)
	if _tex == null:
		return area
	var ts: = _tex.get_size()
	var s: = minf(area.size.x / ts.x, area.size.y / ts.y)
	var d: = ts * s
	return Rect2(area.position + (area.size - d) * 0.5, d)


func place_pos(p: Dictionary) -> Vector2:
	var r: = image_rect()
	return r.position + Vector2(float(p.x) * r.size.x, float(p.y) * r.size.y)



func _k() -> float:
	return maxf(size.y, 1.0) / 1080.0





func neighbour(from: int, dir: Vector2) -> int:
	var o: = Vector2(float(places[from].x) * 16.0, float(places[from].y) * 9.0)
	var best: = -1
	var best_score: = INF
	for i in places.size():
		if i == from:
			continue
		var d: = Vector2(float(places[i].x) * 16.0, float(places[i].y) * 9.0) - o
		var ang: = absf(d.angle_to(dir))
		if ang > deg_to_rad(70.0):
			continue
		var score: = d.length() * (1.0 + 2.0 * ang)
		if score < best_score:
			best_score = score
			best = i
	return best



func cycle(step: int) -> void :
	var towns: = visited_towns()
	if towns.is_empty():
		UiKit.sfx("error")
		return
	var cur: = -1
	for i in towns.size():
		if String(towns[i].id) == String(selected().get("id", "")):
			cur = i
	var nxt: int = (cur + step + towns.size()) % towns.size() if cur >= 0 else 0
	select(find(String(towns[nxt].id)))


func confirm() -> void :
	var p: = selected()
	if can_travel(p):
		_open_confirm(p)
	else:
		UiKit.sfx("error")
		_shake = 1.0


func _process(delta: float) -> void :
	if not visible:
		return
	_t += delta
	_shake = maxf(0.0, _shake - delta * 3.0)
	queue_redraw()
	if not active or _confirm_card.visible or Engine.get_process_frames() == _armed_frame:
		return
	for pair in [["pk_left", Vector2.LEFT], ["pk_right", Vector2.RIGHT], ["pk_up", Vector2.UP], ["pk_down", Vector2.DOWN]]:
		if Input.is_action_just_pressed(pair[0]):
			select(neighbour(index, pair[1]))
	if Input.is_action_just_pressed("pk_prev"):
		cycle(-1)
	elif Input.is_action_just_pressed("pk_next"):
		cycle(1)
	elif Input.is_action_just_pressed("pk_ok"):
		confirm()
	elif Input.is_action_just_pressed("pk_back"):
		close()


func _gui_input(e: InputEvent) -> void :
	if not active or _confirm_card.visible:
		return


	if e is InputEventMouseMotion and not Controls.is_touch():
		var i: = place_at(e.position)
		if i >= 0:
			select(i)
	elif e is InputEventMouseButton and e.pressed and e.button_index == MOUSE_BUTTON_LEFT:
		var i: = place_at(e.position)
		if i < 0:
			return
		if i == index:
			confirm()
		else:
			select(i)
		accept_event()
	elif e is InputEventMouseButton and e.pressed and e.button_index == MOUSE_BUTTON_RIGHT:
		close()



func place_at(pt: Vector2) -> int:
	var best: = -1
	var best_d: = PICK_RADIUS * _k()
	for i in places.size():
		var d: = place_pos(places[i]).distance_to(pt)
		if d < best_d:
			best_d = d
			best = i
	return best



func _open_confirm(p: Dictionary) -> void :
	UiKit.sfx("confirm")
	_confirm_label.text = "Quick travel to %s?" % String(p.name)
	_confirm.set_items([{"id": "yes", "label": "TRAVEL"}, {"id": "no", "label": "CANCEL"}])
	_confirm.index = 0
	_confirm_card.visible = true
	_confirm_card.reset_size()
	_confirm_card.position = (size - _confirm_card.size) * 0.5
	_confirm.active = true
	UiKit.pop_in(_confirm_card)
	_refresh()


func _close_confirm() -> void :
	if _confirm == null:
		return
	_confirm.active = false
	_confirm_card.visible = false
	_armed_frame = Engine.get_process_frames()
	_refresh()


func _on_confirm_chosen(id: String) -> void :
	var p: = selected()
	_close_confirm()
	if id == "yes" and can_travel(p):
		travel_requested.emit(p)



func _refresh() -> void :
	var p: = selected()
	var list: Array = [[["pk_up", "pk_down", "pk_left", "pk_right"], "Move"]]
	if _confirm_card != null and _confirm_card.visible:
		list = [["pk_ok", "Select"], ["pk_back", "Cancel"]]
	else:
		if visited_towns().size() > 0:
			list.append([["pk_prev", "pk_next"], "Visited"])
		if can_travel(p):
			list.append(["pk_ok", "Quick travel"])
		list.append(["pk_back", "Close"])
	_hints.set_hints(list)
	var n: = visited_towns().size()
	var total: = 0
	for q in places:
		if is_town(q):
			total += 1
	_header.screen_title = "TOWN MAP   ·   VISITED %d/%d" % [n, total]
	queue_redraw()



func _draw() -> void :
	draw_rect(Rect2(Vector2.ZERO, size), SEA)
	if _tex != null:
		draw_texture_rect(_tex, image_rect(), false)
	var k: = _k()

	for p in places:
		if not is_town(p):
			_draw_landmark(place_pos(p), k)
	for p in places:
		if is_town(p):
			_draw_town(p, place_pos(p), k)
	var sel: = selected()
	if not sel.is_empty():
		_draw_cursor(place_pos(sel), k, is_town(sel))
	var h: = find(here)
	if h >= 0:
		_draw_player(place_pos(places[h]), k)
	if not sel.is_empty():
		_draw_tag(sel, place_pos(sel), k)
		_draw_card(sel, k)
	if partner_connected:
		var peer_index = find(partner_zone)
		if peer_index >= 0:
			var dot = place_pos(places[peer_index]) + Vector2(14,-14)*k
			draw_circle(dot,13.0*k,Color.BLACK)
			draw_circle(dot,10.0*k,Color.CYAN)
			draw_string(UiKit.header_font(),dot+Vector2(18,5)*k,"PARCEIRO",HORIZONTAL_ALIGNMENT_LEFT,-1,int(22*k),Color.BLACK)
		UI.text(self,Vector2(24,120)*k,partner_info,22,Color.WHITE)


func _diamond(c: Vector2, r: float) -> PackedVector2Array:
	return PackedVector2Array([c + Vector2(0, - r), c + Vector2(r, 0), c + Vector2(0, r), c + Vector2( - r, 0)])


func _draw_town(p: Dictionary, c: Vector2, k: float) -> void :
	var r: = MARKER * k
	var seen: = visited.has(String(p.id))
	draw_colored_polygon(_diamond(c + Vector2(0, 3) * k, r + 3.0 * k), Color(0, 0, 0, 0.22))
	draw_colored_polygon(_diamond(c, r + 3.0 * k), Color.WHITE)
	draw_colored_polygon(_diamond(c, r), UiKit.accent() if seen else UiKit.SLATE_500)
	if seen:
		draw_colored_polygon(_diamond(c, r * 0.42), Color(1, 1, 1, 0.9))
	else:
		var f: = UiKit.header_font()
		draw_string(f, c + Vector2( - r, 7.0 * k), "?", HORIZONTAL_ALIGNMENT_CENTER, r * 2.0, int(20 * k), Color.WHITE)


func _draw_landmark(c: Vector2, k: float) -> void :
	draw_circle(c + Vector2(0, 2) * k, (LANDMARK + 3.0) * k, Color(0, 0, 0, 0.2))
	draw_circle(c, (LANDMARK + 3.0) * k, Color.WHITE)
	draw_circle(c, LANDMARK * k, UiKit.SLATE_700)



func _draw_cursor(c: Vector2, k: float, town: bool) -> void :
	var off: = Vector2(sin(_shake * 40.0) * 8.0 * _shake * k, 0)
	var s: = ((MARKER if town else LANDMARK) + 12.0 + 3.0 * sin(_t * 5.0)) * k
	var arm: = 9.0 * k
	var col: = UiKit.accent()
	for sx in [-1.0, 1.0]:
		for sy in [-1.0, 1.0]:
			var corner: Vector2 = c + off + Vector2(sx * s, sy * s)
			var pts: = PackedVector2Array([corner - Vector2(sx * arm, 0), corner, corner - Vector2(0, sy * arm)])
			draw_polyline(pts, Color.WHITE, 7.0 * k)
			draw_polyline(pts, col, 4.0 * k)



func _draw_player(c: Vector2, k: float) -> void :
	var tip: = c + Vector2(0, - (MARKER + 4.0) * k + sin(_t * 3.0) * 3.0 * k)
	var head: = tip + Vector2(0, -22.0 * k)
	var rad: = 14.0 * k
	draw_colored_polygon(PackedVector2Array([tip, head + Vector2( - rad * 0.8, rad * 0.5), head + Vector2(rad * 0.8, rad * 0.5)]), UiKit.accent_dark())
	draw_circle(head, rad + 2.0 * k, Color.WHITE)
	draw_circle(head, rad, UiKit.accent_dark())
	UI.ball_icon(self, Rect2(head - Vector2.ONE * rad * 0.75, Vector2.ONE * rad * 1.5))



func _draw_tag(p: Dictionary, c: Vector2, k: float) -> void :
	var f: = UiKit.header_font()
	var fs: = int(22 * k)
	var name_text: = String(p.name)
	var w: = f.get_string_size(name_text, HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x + 28.0 * k
	var h: = 34.0 * k
	var lift: = (MARKER + 30.0) * k + (26.0 * k if String(p.id) == here else 0.0)
	var r: = Rect2(c.x - w * 0.5, c.y - lift - h, w, h)

	r.position.x = clampf(r.position.x, 12.0 * k, size.x - w - 12.0 * k)
	r.position.y = maxf(r.position.y, PkHeaderBar.HEIGHT + 8.0 * k)
	var fill: = UiKit.accent() if is_town(p) else UiKit.SLATE_800
	UiKit.skew_rect(self, r.grow(2.0 * k), Color.WHITE)
	UiKit.skew_rect(self, r, fill)
	draw_string(f, Vector2(r.position.x, r.position.y + h * 0.5 + fs * 0.36), name_text, HORIZONTAL_ALIGNMENT_CENTER, w, fs, Color.WHITE)



func _draw_card(p: Dictionary, k: float) -> void :
	var w: = 440.0 * k
	var h: = 132.0 * k
	var r: = Rect2(size.x - w - 24.0 * k, size.y - h - 24.0 * k, w, h)
	var sb: = UiKit.window_box()
	draw_style_box(sb, r)
	UiKit.skew_rect(self, Rect2(r.position + Vector2(18, 16) * k, Vector2(10, 30) * k), UiKit.accent())
	var hf: = UiKit.header_font()
	var bf: = UiKit.body_font()
	draw_string(hf, r.position + Vector2(40, 42) * k, String(p.name), HORIZONTAL_ALIGNMENT_LEFT, w - 56.0 * k, int(28 * k), UiKit.SLATE_900)
	var blurb: = String(p.get("blurb", ""))
	if not is_town(p) and blurb == "":
		blurb = "A landmark on your journey."
	draw_string(bf, r.position + Vector2(40, 76) * k, blurb, HORIZONTAL_ALIGNMENT_LEFT, w - 56.0 * k, int(19 * k), UiKit.SLATE_500)
	var status: = ""
	var col: = UiKit.SLATE_500
	if String(p.id) == here:
		status = "YOU ARE HERE"
		col = UiKit.accent_dark()
	elif not is_town(p):
		status = "ROUTE" if String(p.id).begins_with("rt_") else "LANDMARK"
	elif not visited.has(String(p.id)):
		status = "NOT VISITED YET"
	elif String(p.get("spawn", "")) == "":
		status = "CLOSED FOR NOW"
	else:
		status = "QUICK TRAVEL AVAILABLE"
		col = UiKit.accent()
	var cr: = Rect2(r.position + Vector2(40, 92) * k, Vector2(hf.get_string_size(status, HORIZONTAL_ALIGNMENT_LEFT, -1, int(16 * k)).x + 24.0 * k, 26.0 * k))
	draw_style_box(UiKit.pill(col, col, 13.0 * k), cr)
	draw_string(hf, cr.position + Vector2(0, 19.0 * k), status, HORIZONTAL_ALIGNMENT_CENTER, cr.size.x, int(16 * k), Color.WHITE)

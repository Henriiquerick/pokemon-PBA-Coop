# Plano e gates de teste

Para cada resultado guardar versão, hash, comando, logs dos dois PCs, mapa, inputs e resultado observado. Automação com ações de teste não substitui gamepad ou homologação Radmin.

| Etapa | Verificação | Gate |
|---|---|---|
| S01 | loopback Ryan/Brock, dano dos dois, HP consistente, retorno; diagnóstico nos dois lados; versão diferente; queda e transição | sem erro de script ou regressão crítica; dois PCs pendentes |
| S02 | entrar por interface/Enter, erros, andar/correr/mudar direção; perfis de latência/jitter/perda documentados | local responsivo, remoto suave, sem deriva; comparar métricas |
| S03 | nova campanha, iniciais individuais, gravar, fechar ambos, reabrir, trocar host, reconectar, falhar durante gravação | estado de cada jogador íntegro; original solo intacto |
| S04 | cada treinador/variante, ginásios e pré-requisitos, reservas/KO, ajudar após vitória, XP 2 e 3 participantes, evoluções | recompensa/flag aplicada uma vez; nenhuma insígnia sem pré-requisito |
| S05 | capturar mesmo spawn individualmente, combate simultâneo, coletar item dos dois lados, reconectar e reiniciar | UUIDs distintos e nenhum consumo repetido |
| S06 | trocar/cancelar/alterar oferta, confirmar, cair em cada fase, reiniciar | sem duplicação/perda; evolução por troca correta |
| S07 | sessão prolongada, mapas separados, interfaces simultâneas, quedas host/guest em cada operação | checklist completo com evidência em dois PCs |

Na S01, ativar `--debug-rede` em ambos os PCs, caminhar/correr, atravessar portões até Pewter e lutar contra Ryan/Brock. Enviar logs e relatar se a queda coincide com pico de `max_frame_ms`, RTT ou mudança de cena. Não afirmar causalidade só pela coincidência.

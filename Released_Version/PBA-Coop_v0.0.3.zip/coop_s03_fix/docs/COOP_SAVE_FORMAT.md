# Formato S3 — schema 1

Arquivo `user://coop_s3/profile.json`, sob APPDATA isolado da instalação. JSON externo com `schema`, `sha256` e `payload`. O payload é uma string JSON; o hash é calculado sobre essa string UTF-8, evitando diferenças de ordenação ou representação entre leitores.

Payload: `player_id`, `session_id`, `participants`, `generation`, `snapshot`. IDs são 16 bytes aleatórios em hexadecimal. `snapshot` usa a estrutura original de SaveGame: estado, cena, spawn, posição, orientação, localização, versão do jogo e metadados nativos. `coop_uid` é preservado em Mon.to_dict/from_dict, inclusive para box. `ot_id` conserva o treinador de origem e não é substituído pelo ID do Pokémon.

Não há schema cooperativo anterior em produção a migrar: S01/S02 importavam saves descartáveis. Um perfil vazio importa o formato nativo compatível através de SaveGame.peek_file. Schema futuro é recusado; futuras migrações devem manter backup e preservar IDs.

Commit: criar `.tmp`, flush/fechar, ler e validar checksum/estrutura, copiar o principal válido para backup temporário, promover backup por rename, promover `.tmp` por rename. Erro retorna falso e não incrementa a revisão. O backup válido nunca é substituído por principal corrompido. Inicialização prefere principal válido; usa backup quando necessário; não promove `.tmp` interrompido. Não é garantia de durabilidade contra qualquer falha de energia.

Somente o processo local grava o perfil. O lançador usa lock de arquivo Windows, liberado pelo sistema na morte do processo. BAT e CLI usam a mesma pasta de perfil em ambos os papéis. Abrir diretamente o EXE contorna o isolamento e o lock do lançador; para co-op, usar COOPERATIVO.bat ou iniciar_campanha.py.

O host coordena o ID da sessão e os dois lados conservam identidades individuais. Esses metadados não sincronizam inventário ou flags. Clonar um perfil para dois participantes viola a identidade e é recusado na conexão. Trocas e resultados com aplicação única exigirão journals próprios nas subsprints seguintes.

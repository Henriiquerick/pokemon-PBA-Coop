class_name PkHintBar
extends HBoxContainer








const INSET: = 20.0
const HEIGHT: = 28.0


class KeyCap extends Control:
	var label: = ""

	var hold: = false

	const FS: = 16

	func _init(text: String, is_hold: = false) -> void :
		label = text
		hold = is_hold
		var w: = UiKit.header_font().get_string_size(text, HORIZONTAL_ALIGNMENT_LEFT, -1, FS).x
		custom_minimum_size = Vector2(maxf(30.0, w + 18.0), 28)

	func _draw() -> void :
		var r: = Rect2(Vector2(0, 2), size - Vector2(0, 4))
		var sb: = UiKit.pill(UiKit.SLATE_800, UiKit.accent_border(), 7)
		sb.set_border_width_all(2)
		draw_style_box(sb, r)

		draw_string(UiKit.header_font(), Vector2(0, r.get_center().y + 6), label, 
			HORIZONTAL_ALIGNMENT_CENTER, size.x, FS, UiKit.accent())
		if hold:

			var cx: = size.x * 0.5
			var top: = r.position.y - 2.0
			draw_polyline(PackedVector2Array([
				Vector2(cx - 6.0, top), Vector2(cx, top - 5.0), Vector2(cx + 6.0, top)]), 
				UiKit.accent(), 2.0)



class BallIcon extends Control:
	const UI: = preload("res://scripts/ui/ui_draw.gd")

	func _init() -> void :
		custom_minimum_size = Vector2(24, 28)

	func _draw() -> void :
		UI.ball_icon(self, Rect2(0, 2, 24, 24))



var show_background: = true:
	set(v):
		show_background = v
		queue_redraw()

var _spec: Array = []



const GROUP: = "hint_bar"




func action_label(action: String) -> String:
	for h in _spec:
		var a = h[0]
		if a is String and String(a) == action:
			return String(h[1])
		if a is Array and (a as Array).has(action):
			return String(h[1])
	return ""


func _init() -> void :
	theme = UiKit.theme()
	add_theme_constant_override("separation", 8)
	add_to_group(GROUP)


	Controls.on_device_changed(_on_device_changed)
	UiKit.connect_version(_on_version)


func _exit_tree() -> void :
	Controls.off_device_changed(_on_device_changed)


func _on_device_changed(_device: String) -> void :
	_rebuild()


func _on_version() -> void :
	_rebuild()
	queue_redraw()


func set_hints(list: Array) -> void :
	_spec = list.duplicate(true)
	for hint in _spec:
		if hint is Array and hint.size()>1: hint[1] = preload("res://coop/pt_br.gd").text(String(hint[1]))
	_rebuild()




static func _cap(v) -> String:
	if Controls.is_touch():
		return _touch_cap(v)
	if v is Array:
		var parts: = PackedStringArray()
		for a in v:
			parts.append(Controls.key_label(String(a)))
		return "/".join(parts)
	var s: = String(v)
	return Controls.key_label(s) if Controls.ACTIONS.has(s) else s





const TOUCH_CAPS: = {"pk_ok": "A", "pk_back": "B", "pk_alt": "ALT", "pk_start": "START", "pk_pause": "START", "pk_stats": "IV/EV", 
	"interact": "A", "inspect": "INSPECT", "ride": "R", "pilot": "C"}


static func _touch_cap(v) -> String:
	if v is Array:
		return ""
	return String(TOUCH_CAPS.get(String(v), ""))


func _rebuild() -> void :
	for c in get_children():
		remove_child(c)
		c.queue_free()
	for h in _spec:
		if Controls.is_touch() and _touch_cap(h[0]) == "":
			continue
		if h[0] is String and String(h[0]) == "":

			var dash: = Label.new()
			dash.theme_type_variation = "SmallLabel"
			dash.text = "–"
			dash.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
			dash.add_theme_color_override("font_color", UiKit.SLATE_300)
			add_child(dash)
		else:
			add_child(KeyCap.new(_cap(h[0]), h.size() > 2 and String(h[2]) == "hold"))
		if h.size() > 2 and String(h[2]) == "ball":
			add_child(BallIcon.new())
		var l: = Label.new()
		l.text = String(h[1]).to_upper() + "   "
		l.add_theme_font_override("font", UiKit.header_font())
		l.add_theme_font_size_override("font_size", 15)
		l.add_theme_color_override("font_color", UiKit.SLATE_300)
		l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		add_child(l)


func _draw() -> void :
	if show_background and get_child_count() > 0:
		var sb: = UiKit.pill(Color(UiKit.SLATE_900, 0.88), UiKit.SLATE_700, 7)
		sb.set_border_width_all(2)
		draw_style_box(sb, Rect2(Vector2.ZERO, size).grow(8))

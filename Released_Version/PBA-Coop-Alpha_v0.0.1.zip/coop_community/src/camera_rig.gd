extends Node3D



@export var target_path: NodePath
@export_range(15.0, 75.0) var pitch_deg: = 38.0
@export var distance: = 16.0
@export var battle_extra_per_meter: = 0.9
@export var follow_sharpness: = 6.0

@export var dof_band: = 3.5

@export var occluder_alpha: = 0.05
@export var tree_occluder_alpha: = 0.35
@export var occluder_half_width: = 5.0


@export var building_alpha: = 0.4

var _punch_cur: = 0.0

var _hold_zoom: = 0.0
var _hold_cur: = 0.0
var target: Node3D
var _a: Node3D
var _b: Node3D
var _dist: = 16.0
var _shake: = 0.0


var _punch: = 0.0
var _punch_t: = 0.0
var _shake_decay: = 2.5

var clearing_owner: Node
var clearing_at: = Vector3.ZERO
var _fixed: = false
var _fixed_at: = Vector3.ZERO
var _fixed_dist: = 16.0




const ZOOM_PAD: = 2.2
const ZOOM_MIN_DIST: = 9.0



const ZOOM_OUT_RATE: = 6.0
const ZOOM_IN_RATE: = 1.0
const ZOOM_DEADBAND: = 0.3


var _fighters: Array = []

var _zone_dist: = 0.0



var _zone_yaw: = 0.0
var _zone_pitch: = 0.0
var _yaw_off: = 0.0
var _pitch_off: = 0.0




var _zone_pitch_near: = 0.0
var _pitch_near_rect: = Rect2()


var _far: = 220.0

@onready var camera: Camera3D = $Camera3D


func _ready() -> void :
	add_to_group("camera_rig")
	target = get_node_or_null(target_path) as Node3D
	_dist = distance
	_far = camera.far if camera else _far
	if target:
		global_position = target.global_position
	_apply()



func snap() -> void :
	if is_instance_valid(target):
		global_position = _bounded(target.global_position)
	_dist = _base_dist()
	reset_physics_interpolation()
	_apply()




func _bounded(p: Vector3) -> Vector3:
	for b in get_tree().get_nodes_in_group("cam_bounds"):
		if b.covers(p):
			return b.clamp_point(p)
	return p






func _drawn(n: Node3D) -> Vector3:
	return n.get_global_transform_interpolated().origin




func set_zone_distance(d: float) -> void :
	_zone_dist = maxf(d, 0.0)



func set_zone_camera(yaw: float, pitch: float) -> void :
	_zone_yaw = yaw
	_zone_pitch = pitch




func set_zone_camera_near(pitch: float, rect: Rect2) -> void :
	_zone_pitch_near = pitch
	_pitch_near_rect = rect



func _pitch_near_blend() -> float:
	if _pitch_near_rect.size.x <= 0.0 or not is_instance_valid(target):
		return 0.0
	var p: = target.global_position
	if p.z < _pitch_near_rect.position.y or p.z > _pitch_near_rect.end.y:
		return 0.0
	return clampf((p.x - _pitch_near_rect.position.x) / _pitch_near_rect.size.x, 0.0, 1.0)




func set_zone_far(d: float) -> void :
	if camera:
		camera.far = d if d > 0.0 else _far




func _flat_camera() -> bool:
	var d: = get_node_or_null("/root/Debug")
	return d != null and bool(d.flat_camera)


func _base_dist() -> float:
	return _zone_dist if _zone_dist > 0.0 else distance




func shake(amount: float, secs: = 0.0) -> void :
	_shake = maxf(_shake, amount)
	_shake_decay = maxf(amount / secs, 0.001) if secs > 0.0 else 2.5



func punch(zoom: = 0.09) -> void :
	_punch = maxf(_punch, zoom)
	_punch_t = 0.26



func hold_zoom(zoom: float) -> void :
	_hold_zoom = zoom


func focus_battle(a: Node3D, b: Node3D) -> void :
	focus_fighters([a, b])




func focus_fighters(list: Array) -> void :
	if _fixed:

		var st: = get_node_or_null("/root/Settings")
		if st != null and bool(st.zoom_battle):
			_fighters = list.filter( func(f): return is_instance_valid(f))
		return
	_a = list[0] if list.size() > 0 else null
	_b = list[1] if list.size() > 1 else null



func focus_fixed(at: Vector3, dist: float) -> void :
	_fixed = true
	_fixed_at = at
	_fixed_dist = dist
	_a = null
	_b = null
	_fighters.clear()






func visible_ground(dist: float) -> Vector2:
	var p: = deg_to_rad(pitch_deg)
	var f: = deg_to_rad(camera.fov * 0.5)
	var h: = dist * sin(p)
	return Vector2(dist * cos(p) - h / tan(p + f), dist * cos(p) - h / tan(maxf(p - f, 0.05)))








func zoom_fit_dist(pa: Vector3, pb: Vector3, ha: = 0.0, hb: = 0.0) -> float:
	return zoom_fit_points([pa, pb], [ha, hb])



func zoom_fit_points(pts: Array, heights: Array) -> float:
	var ax: = _cam_axes()
	var away: = 1.0 / maxf(tan(deg_to_rad(pitch_deg)), 0.1)


	var sum: = Vector3.ZERO
	for p in pts:
		sum += p
	var focus: = sum / maxf(float(pts.size()), 1.0)
	var all: Array = pts.duplicate()
	for i in pts.size():
		all.append(pts[i] - ax[0] * (float(heights[i]) * away))
	var fwd_c: = focus.dot(ax[0])
	var side_c0: = focus.dot(ax[1])
	var ext_fwd: = 0.0
	var ext_side: = 0.0
	for p in all:
		ext_fwd = maxf(ext_fwd, absf(p.dot(ax[0]) - fwd_c))
		ext_side = maxf(ext_side, absf(p.dot(ax[1]) - side_c0))
	var unit: = visible_ground(1.0)
	var fwd_c0: = maxf(minf(unit.x, - unit.y), 0.05)
	var size: = get_viewport().get_visible_rect().size if is_inside_tree() else Vector2(16, 9)
	var side_c: = tan(deg_to_rad(camera.fov) * 0.5) * maxf(size.x / maxf(size.y, 1.0), 0.35)
	var side: = ext_side + ZOOM_PAD * _cast_k()
	var fwd: = ext_fwd + ZOOM_PAD * 0.7 * _cast_k()
	return maxf(side / side_c, fwd / fwd_c0)




func _body_height(n: Node3D) -> float:
	if n == null:
		return 0.0
	if n.has_method("look_height"):
		return float(n.call("look_height"))
	return 0.0


func hold_clearing(owner: Node, at: Vector3) -> void :
	clearing_owner = owner
	clearing_at = at


func release_clearing(owner: Node) -> void :
	if clearing_owner == owner:
		clearing_owner = null


func focus_follow(t: Node3D) -> void :
	_fixed = false
	_a = null
	_b = null
	_fighters.clear()
	target = t


func _process(delta: float) -> void :
	var focus: = global_position
	var want: = _base_dist()
	var zooming: = false
	if _fixed:
		focus = _fixed_at
		want = _fixed_dist
		_fighters = _fighters.filter( func(f): return is_instance_valid(f) and f.is_inside_tree())

		if _fighters.size() >= 2:
			var pts: Array = []
			var heights: Array = []
			var sum: = Vector3.ZERO
			for f in _fighters:
				var feet: = _drawn(f)
				sum += feet
				pts.append(feet)
				heights.append(_body_height(f))
			zooming = true
			focus = sum / float(_fighters.size())
			want = clampf(zoom_fit_points(pts, heights), ZOOM_MIN_DIST * _cast_k(), _fixed_dist)
	elif is_instance_valid(_a) and is_instance_valid(_b):
		var pa: = _drawn(_a)
		var pb: = _drawn(_b)
		focus = (pa + pb) * 0.5
		want = distance * 0.85 + pa.distance_to(pb) * battle_extra_per_meter
	elif is_instance_valid(clearing_owner):
		focus = clearing_at
	elif is_instance_valid(target):
		focus = _bounded(_drawn(target))
	global_position = global_position.lerp(focus, 1.0 - exp( - follow_sharpness * delta))
	var dist_rate: = 3.0
	if zooming:

		dist_rate = ZOOM_OUT_RATE if want > _dist else (ZOOM_IN_RATE if want < _dist - ZOOM_DEADBAND else 0.0)
	if dist_rate > 0.0:
		_dist = lerpf(_dist, want, 1.0 - exp( - dist_rate * delta))
	if _punch_t > 0.0:
		_punch_t = maxf(_punch_t - delta, 0.0)
		var pp: = 1.0 - _punch_t / 0.26
		_punch_cur = _punch * (1.0 - (1.0 - pow(1.0 - pp, 3.0)))
	else:
		_punch_cur = 0.0
	_hold_cur = lerpf(_hold_cur, _hold_zoom, 1.0 - exp( - (7.0 if _hold_zoom > _hold_cur else 3.5) * delta))
	_punch_cur = maxf(_punch_cur, _hold_cur)




	var reset: = _flat_camera()


	var rate: = 12.0 if reset else 1.1
	_yaw_off = lerpf(_yaw_off, 0.0 if reset else _zone_yaw, 1.0 - exp( - rate * delta))
	var pitch_target: = 0.0 if (reset or _in_battle()) else _zone_pitch


	if not reset and not _in_battle() and _pitch_near_rect.size.x > 0.0:
		pitch_target = lerpf(_zone_pitch, _zone_pitch_near, _pitch_near_blend())
	_pitch_off = lerpf(_pitch_off, pitch_target, 1.0 - exp( - rate * delta))
	_apply(delta)
	if _shake > 0.0:
		camera.position += Vector3(randf_range(-1, 1), randf_range(-1, 1), 0) * _shake
		_shake = maxf(_shake - delta * _shake_decay, 0.0)
	_fade_occluders()
	_fade_buildings(delta)





const Props: = preload("res://scripts/world/props.gd")
const FADE_RADIUS: = 18.0
var _fading: = {}





func _cam_axes() -> Array:
	var b: = global_transform.basis
	return [Vector3(b.z.x, 0.0, b.z.z).normalized(), Vector3(b.x.x, 0.0, b.x.z).normalized()]




func _cam_span(r: Rect2, f: Vector3, d: Vector3, s: Vector3) -> PackedFloat32Array:
	var c: = Vector2(r.position.x + r.size.x * 0.5 - f.x, r.position.y + r.size.y * 0.5 - f.z)
	var hx: = r.size.x * 0.5
	var hz: = r.size.y * 0.5
	var ac: = c.x * d.x + c.y * d.z
	var ar: = absf(hx * d.x) + absf(hz * d.z)
	var sc: = c.x * s.x + c.y * s.z
	var sr: = absf(hx * s.x) + absf(hz * s.z)
	return PackedFloat32Array([ac - ar, ac + ar, sc - sr, sc + sr])


func _fade_occluders() -> void :
	var f: = global_position
	var ax: = _cam_axes()
	var d: Vector3 = ax[0]
	var s_axis: Vector3 = ax[1]

	for n in get_tree().get_nodes_in_group("fade_occluder"):
		var s: = n as Sprite3D
		if s == null:
			continue
		var off: = s.global_position - f
		var along: = off.x * d.x + off.z * d.z
		var side: = off.x * s_axis.x + off.z * s_axis.z
		var cover: = along > 0.8 and along < _dist and absf(side) < occluder_half_width
		if cover and s.alpha_cut != SpriteBase3D.ALPHA_CUT_DISABLED:
			s.alpha_cut = SpriteBase3D.ALPHA_CUT_DISABLED
			s.modulate.a = occluder_alpha
		elif not cover and s.alpha_cut == SpriteBase3D.ALPHA_CUT_DISABLED:
			s.alpha_cut = SpriteBase3D.ALPHA_CUT_DISCARD
			s.modulate.a = 1.0



func _fade_target(n: Node3D, f: Vector3) -> float:
	var ax: = _cam_axes()
	var d: Vector3 = ax[0]
	var s_axis: Vector3 = ax[1]
	if n.is_in_group("fade_building") and n.has_meta("rect"):
		var r: Rect2 = n.get_meta("rect")
		var height: float = n.get_meta("height", 5.0)
		var tan_p: = tan(deg_to_rad(pitch_deg))


		var sp: = _cam_span(r, f, d, s_axis)
		var back_dist: = float(sp[0])
		var hidden: bool = back_dist > 0.0 and back_dist < height / tan_p and sp[2] < 0.0 and sp[3] > 0.0
		return 1.0 - building_alpha if hidden else 0.0
	if _in_battle():
		return 1.0 if _in_battle_view(n, f) else 0.0
	var alpha: = float(n.get_meta("occluder_alpha", tree_occluder_alpha)) if n.has_meta("tree_card") else occluder_alpha

	if n.get_meta("fade_foreground", false) and _in_battle_view(n, f):
		return 1.0 - alpha
	var p: = n.global_position
	var off: = p - f
	var along: = off.x * d.x + off.z * d.z
	var side: = off.x * s_axis.x + off.z * s_axis.z
	var cover: = along > 0.8 and along < _dist * 0.8
	if n.has_meta("rect"):


		var r2: Rect2 = n.get_meta("rect")
		if r2.has_point(Vector2(f.x, f.z)):


			cover = true
		else:
			var sp2: = _cam_span(r2, f, d, s_axis)
			if n.has_meta("tree_card"):


				var reach: = float(n.get_meta("height", 100.0)) / maxf(tan(deg_to_rad(pitch_deg + _pitch_off)), 0.1)
				cover = sp2[1] > 0.8 and sp2[0] < minf(_dist * 0.8, reach)
			cover = cover and sp2[2] < 0.0 and sp2[3] > 0.0
	else:
		cover = cover and absf(side) < occluder_half_width
	return 1.0 - alpha if cover else 0.0





func _cast_k() -> float:
	var b: = get_node_or_null("/root/Battle")
	return float(b.cast_scale) if b != null and b.in_battle else 1.0


func _in_battle() -> bool:
	return _fixed or (is_instance_valid(_a) and is_instance_valid(_b))




func _in_battle_view(n: Node3D, f: Vector3) -> bool:
	var r: Rect2
	if n.has_meta("rect"):
		r = n.get_meta("rect")
	else:
		r = Rect2(n.global_position.x - 1.0, n.global_position.z - 1.0, 2.0, 2.0)


	var ax: = _cam_axes()
	var sp: = _cam_span(r, f, ax[0], ax[1])
	var cam_along: = cos(deg_to_rad(pitch_deg)) * _dist
	if sp[1] < 0.5 or sp[0] > cam_along + 2.0:
		return false
	var size: = get_viewport().get_visible_rect().size if is_inside_tree() else Vector2(16, 9)

	var aspect: = maxf(size.x / maxf(size.y, 1.0), 16.0 / 9.0)
	var half_w: = _dist * tan(deg_to_rad(camera.fov) * 0.5) * aspect + 1.0
	return sp[3] > - half_w and sp[2] < half_w


func _fade_buildings(delta: float) -> void :
	var f: = global_position

	var radius: = maxf(FADE_RADIUS, _dist + 4.0) if _in_battle() else FADE_RADIUS
	for n in Props.faders_near(f, radius):
		_fading[n] = true
	var eye: = camera.global_position
	var at: = target.global_position if is_instance_valid(target) else f
	for n in _fading.keys():
		if not is_instance_valid(n):
			_fading.erase(n)
			continue
		var want: = _fade_target(n, f)

		if is_instance_valid(clearing_owner) and not _in_battle() and is_instance_valid(target):
			want = maxf(want, _fade_target(n, target.global_position))
		var cur: float = n.get_meta("fade", 0.0)
		var nv: = cur
		if is_equal_approx(cur, want):
			if want == 0.0:
				_fading.erase(n)
				if cur > 0.0:
					_set_fade(n, 0.0, eye, at)
				continue
		else:
			nv = move_toward(cur, want, delta * 4.0)
			n.set_meta("fade", nv)
		_set_fade(n, nv, eye, at)





func _set_fade(n: Node3D, nv: float, eye: Vector3, at: Vector3) -> void :
	var partial: = nv > 0.0 and not _in_battle() and n.is_in_group("fade_building")
	for g in n.get_meta("geoms", []):
		if not is_instance_valid(g):
			continue
		var gi: = g as GeometryInstance3D
		var a: = nv
		if partial:
			var inv: = gi.global_transform.affine_inverse()
			if gi.get_aabb().intersects_segment(inv * eye, inv * at) == null:
				a = 0.0
		if not n.has_meta("tree_card"):
			_keep_shadow(gi, a)
		if n.is_in_group("fade_building"):
			_blend_while_faded(gi, a > 0.0)
		if n.has_meta("tree_card"):
			preload("res://scripts/world/tree_cards.gd").set_fade(gi as MeshInstance3D, a)
		else:
			gi.transparency = a





func _keep_shadow(gi: GeometryInstance3D, a: float) -> void :
	var mi: = gi as MeshInstance3D
	var twin: MeshInstance3D = gi.get_meta("shadow_twin") if gi.has_meta("shadow_twin") else null
	if mi == null or mi.mesh == null:
		if a > 0.0:
			if not gi.has_meta("fade_shadow"):
				gi.set_meta("fade_shadow", gi.cast_shadow)
			gi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		elif gi.has_meta("fade_shadow"):
			gi.cast_shadow = gi.get_meta("fade_shadow")
			gi.remove_meta("fade_shadow")
		return
	if twin == null:
		if a <= 0.0 or gi.has_meta("fade_mats"):
			return
		twin = MeshInstance3D.new()
		twin.name = "ShadowTwin"
		twin.mesh = mi.mesh
		for i in mi.mesh.get_surface_count():
			twin.set_surface_override_material(i, mi.get_active_material(i))
		twin.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_SHADOWS_ONLY
		twin.set_meta("orig_cast", gi.cast_shadow)
		mi.add_child(twin)
		mi.set_meta("shadow_twin", twin)
	var casts: bool = int(twin.get_meta("orig_cast", 1)) != GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	if a > 0.0:
		if not gi.has_meta("fade_shadow"):
			gi.set_meta("fade_shadow", gi.cast_shadow)
		gi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		twin.visible = casts and a < 0.999
	else:
		if gi.has_meta("fade_shadow"):
			gi.cast_shadow = gi.get_meta("fade_shadow")
			gi.remove_meta("fade_shadow")
		twin.visible = false






static var _blend_twins: = {}


func _blend_while_faded(gi: GeometryInstance3D, fading: bool) -> void :
	var mi: = gi as MeshInstance3D
	if mi == null or mi.mesh == null:
		return
	if fading:
		if gi.has_meta("fade_mats"):
			return
		var saved: = []
		for i in mi.mesh.get_surface_count():
			saved.append(mi.get_surface_override_material(i))
			var m: = mi.get_active_material(i) as BaseMaterial3D
			if m != null and m.transparency == BaseMaterial3D.TRANSPARENCY_ALPHA_SCISSOR:
				var tw: BaseMaterial3D = _blend_twins.get(m)
				if tw == null:
					tw = m.duplicate()
					tw.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA_DEPTH_PRE_PASS
					_blend_twins[m] = tw
				mi.set_surface_override_material(i, tw)
		gi.set_meta("fade_mats", saved)
	elif gi.has_meta("fade_mats"):
		var saved_mats: Array = gi.get_meta("fade_mats")
		for i in saved_mats.size():
			mi.set_surface_override_material(i, saved_mats[i])
		gi.remove_meta("fade_mats")


func _apply(delta: = 1.0 / 60.0) -> void :
	var p: = deg_to_rad(pitch_deg + _pitch_off)
	rotation.y = deg_to_rad(_yaw_off)
	var d: = _dist * (1.0 - _punch_cur)
	camera.position = Vector3(0.0, sin(p) * d, cos(p) * d)
	camera.rotation = Vector3( - p, 0.0, 0.0)

	RenderingServer.global_shader_parameter_set("main_cam_pos", camera.global_position)
	var attr: = camera.attributes as CameraAttributesPractical
	if attr:
		attr.dof_blur_far_distance = _dist + dof_band
		attr.dof_blur_near_distance = maxf(_dist - dof_band, 0.5)

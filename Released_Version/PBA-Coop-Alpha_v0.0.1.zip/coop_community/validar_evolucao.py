from pathlib import Path
import argparse,os,subprocess,json
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--runtime',required=True,type=Path);ap.add_argument('--logs',required=True,type=Path)
    ap.add_argument('--arena',action='store_true')
    a=ap.parse_args();base=a.logs.resolve();base.mkdir(parents=True,exist_ok=False)
    env=os.environ.copy();env['APPDATA']=str(base/'userdata')
    p=subprocess.run([str(a.runtime.resolve()/'PokemonBattleAdvanced.exe'),'--headless','--','--coop-campaign','--coop-role=offline','--coop-start=route2','--coop-autotest','--coop-persist-test','--coop-arena-smoke' if a.arena else '--coop-evolution-smoke'],cwd=a.runtime.resolve(),env=env,capture_output=True,timeout=80)
    text=(p.stdout+p.stderr).decode('utf8','replace');(base/'game.log').write_text(text,encoding='utf8')
    assert p.returncode==0 and 'SCRIPT ERROR' not in text,(p.returncode,text[-2500:])
    rows=[json.loads(s.split('[campaign-lan] ',1)[1]) for s in text.splitlines() if '[campaign-lan] {' in s]
    if a.arena:
        arena=next(r for r in rows if r['event']=='physical_wall_test')
        back=next(r for r in rows if r['event']=='physical_wall_return')
        assert arena['battle'] and arena['wall_clear'],arena
        assert not back['battle'] and back['controls'],back
        result={'passed':True,'real_static_body_wall':True,'native_battle_started':True,'arena_did_not_cross_wall':True,'returned_controls':True,'specific_mt_moon_encounter_pending':True}
        (base/'result.json').write_text(json.dumps(result,indent=2),encoding='utf8');print(json.dumps(result));raise SystemExit(0)
    guard=next(r for r in rows if r['event']=='evolution_guard_test')
    after=next(r for r in rows if r['event']=='evolution_restore_test')
    assert guard['busy'] and not guard['wild_allowed'] and not guard['battle'] and guard['trainer']=='aborted',guard
    assert after['species']=='Kakuna' and not after['evolving'] and after['sprite_visible'] and after['groups']==0 and not after['busy'],after
    assert after['wall_free'] and after['plan_score']>=.98,after
    assert any(r['event']=='evolution_saved' and r['saved'] for r in rows)
    result={'passed':True,'evolution_blocks_wild_cave_trainer':True,'sprite_restored':True,'weedle_to_kakuna':True,'synthetic_wall_plan_clear':True,'mt_moon_physical_scene_pending':True}
    (base/'result.json').write_text(json.dumps(result,indent=2),encoding='utf8');print(json.dumps(result))

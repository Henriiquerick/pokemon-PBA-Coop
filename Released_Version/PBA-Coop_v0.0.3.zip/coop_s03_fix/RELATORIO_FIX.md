# Diagnóstico e validação da S3 Fix

## Logs recebidos

Os dois arquivos mostram importação de saves individuais, commits e encerramento com código 0. O host teve desconexão manual; o guest registrou timeout de conexão e depois venceu uma batalha selvagem local. Nenhum deles contém `connected` ou uma batalha co-op dessa sessão. Não há `SCRIPT ERROR`. Os avisos de Discord, shadow_twin e recursos ao encerrar permanecem separados do diagnóstico: os logs não demonstram a causa do episódio visual de chuva relatado.

## Correções

- A presença serializava somente um Pokémon e executava `break` no primeiro companheiro. Agora envia todos os companheiros visíveis do time e identifica cada réplica por slot/UUID. Recolher, trocar espécie e mudar de cena removem/recriam a réplica correspondente.
- O clima do guest aplicava o snapshot do host, mas voltava a avançar as células pelo relógio individual do save. Essa disputa pode envelhecer/remover células logo após sincronizar. Na sessão conectada o guest representa o clima do host sem avançar a simulação climática local. Os relógios da campanha não são sobrescritos. A reprodução com relógios diferentes confirma estabilidade do estado de chuva localmente; o caso visual do usuário ainda precisa ser repetido.
- Minimap.gd deixa de exigir Town Map para mostrar o mapa ao ar livre. Um marcador ciano usa a posição recebida do parceiro e uma seta na borda indica parceiro distante. Uma etiqueta textual cobre cenas diferentes. Não são concedidos itens nem alterados desbloqueios.
- A substituição de `_beaten` que forçava encontros de teste repetíveis foi removida. A vitória recebe uma flag cooperativa individual de conclusão, respeitando flags originais. XP e conclusão são gravados no mesmo snapshot; a repetição/reconexão não aplica a parcela novamente.
- O pool usa a fórmula nativa dos adversários e um nível de referência comum aos dois participantes. Divide pelos participantes elegíveis, distribui o resto e preserva o modificador nativo de treinador de origem. Não concede dinheiro/insígnias nem copia flags de história. Os eventos de nível/golpe usam Mon.add_exp e Progression originais; prompts de substituição pendentes são recuperáveis por UUID.
- O instalador migra perfis S3 com checksum validado, respeitando o lock do lançador. O schema permanece 1 e os IDs não são regenerados. Migração não substitui os arquivos anteriores.

## Evidências locais

- `logs/world_final/result.json`: três Pokémon soltos chegaram ao guest; após recall restaram dois. Minimap ativo nos dois perfis sem Town Map. Dezesseis amostras do guest mantiveram chuva, com relógio propositalmente deslocado 6000 minutos. Teste headless de estado; aparência do marcador não foi homologada visualmente.
- `logs/verified_xp/xp_result.json`: Ryan concluído com dois jogadores, 30 estados de HP iguais, pool de 170 XP dividido em 85/85, gravação confirmada nos dois lados. Após reabrir e reconectar, `_beaten` verdadeiro, `can_trigger` falso, XP inalterado e nenhuma nova batalha.
- `logs/level/level/level_result.json`: ambos aumentaram para nível 13 e mantiveram XP e golpes após gravação. A suíte prepara Pokémon a um ponto do próximo nível; não é um resultado obtido em campanha manual.
- `logs/drew/win/result.json`: Drew concluído com 34 estados de HP iguais, pool de 132 XP dividido em 66/66 e gravação nos dois perfis.
- `logs/migration/result.json`: principal e backup migrados com os mesmos bytes e IDs, mantendo a pasta S3 anterior.
- Um primeiro roteiro de conferência de conclusão encerrou o host antes de a tentativa do guest terminar. O roteiro foi ajustado para manter os peers ativos durante a observação; o teste final acima passou. Essa falha de automação foi preservada nos logs de trabalho.

## Arquivos e limites

Fontes em `src`: campaign.gd, trainer.gd, minimap.gd, weather.gd e persistence.gd modificados nesta correção. Compilador/instalador/validadores e manifesto atualizados. Checkpoint da S3 anterior em `coop_checkpoints/s03-before-fix.zip`. Não há EXE, DLL ou PCK completo no ZIP distribuído.

Pendente: homologação Radmin, apresentação do ponto/seta, chuva em mudanças reais de cidade, gamepad, cenários de aprendizado com quatro golpes e ajuda a jogadores com progressos diferentes. Os treinadores/gatilhos continuam limitados aos encontros integrados. Campos de estado da campanha, bag e badges são conferidos sem alterações indevidas nos testes de vitória. A campanha completa não foi marcada como adaptada.

O rollback de HP/PP/itens transitórios da batalha co-op permanece como na S3; somente o resultado único de XP/conclusão é aplicado depois dele. Encontros selvagens preservam as regras normais. Rematches e assistência a jogadores com conclusões diferentes ainda precisam da adaptação completa da S4.

Instalação, migração, roteiro manual e rollback em GUIA_FIX.md.

extends Node
# One local player profile. Peer saves are never accepted over RPC.
const DIR = "user://coop_s3"
const PATH = DIR + "/profile.json"
const SCHEMA = 1
var player_id = ""
var session_id = ""
var participants: Array = []
var generation = 0
var ready_profile = false
var last_error = ""
var last_save_ms = 0
var last_safe: Dictionary = {}
var failed = false
var pending_save = false
var last_scene = ""
var status_label: Label

static func uid() -> String:
	return Crypto.new().generate_random_bytes(16).hex_encode()

static func decode(path: String) -> Dictionary:
	if not FileAccess.file_exists(path): return {}
	var doc = JSON.parse_string(FileAccess.get_file_as_string(path))
	if not doc is Dictionary or int(doc.get("schema",0)) != SCHEMA: return {}
	var payload = doc.get("payload","")
	if not payload is String or payload.sha256_text() != doc.get("sha256",""): return {}
	var data = JSON.parse_string(payload)
	if not data is Dictionary: return {}
	var snap = data.get("snapshot",{})
	if not snap is Dictionary or not snap.get("state") is Dictionary or not snap.state.get("party") is Array: return {}
	if String(data.get("player_id","")).length() != 32 or String(data.get("session_id","")).length() != 32: return {}
	if not snap.get("pos") is Array or snap.pos.size() != 3 or not ResourceLoader.exists(String(snap.get("scene",""))): return {}
	return data

func open_profile() -> Dictionary:
	DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(DIR))
	var data = decode(PATH)
	if data.is_empty() and FileAccess.file_exists(PATH):
		var raw = JSON.parse_string(FileAccess.get_file_as_string(PATH))
		if raw is Dictionary and int(raw.get("schema",0)) > SCHEMA:
			failed = true
			last_error = "Save de versao futura: atualize o mod."
			return {}
	if data.is_empty():
		data = decode(PATH + ".bak")
		if not data.is_empty():
			print("[coop-save] recovered_backup generation=",data.generation)
	if data.is_empty() and (FileAccess.file_exists(PATH) or FileAccess.file_exists(PATH + ".bak")):
		failed = true
		last_error = "Save e backup invalidos. Arquivos preservados para recuperacao."
		return {}
	if not data.is_empty():
		player_id = data.player_id
		session_id = data.session_id
		participants = data.get("participants",[])
		generation = int(data.generation)
		last_safe = data.snapshot
	else:
		player_id = uid()
		session_id = uid()
	participants = participants.duplicate()
	if not participants.has(player_id): participants.append(player_id)
	ready_profile = true
	return last_safe.duplicate(true)

func _ready():
	get_tree().auto_accept_quit = false
	Game.party_changed.connect(func(): pending_save = true)
	Game.battle_ended.connect(func(_result): pending_save = true)
	var layer = CanvasLayer.new()
	layer.layer = 49
	add_child(layer)
	status_label = Label.new()
	status_label.position = Vector2(18,205)
	layer.add_child(status_label)

func can_save() -> bool:
	if not ready_profile or failed or not is_instance_valid(Game.get_player()): return false
	var lan = get_node_or_null("/root/LanCampaign")
	if lan != null and not lan.phase in ["world","offline"]: return false
	return Game.get_player().controls_enabled and not Battle.in_battle and not Battle._ambush and not Game.is_busy() and not Transitions.busy()

func ensure_mon_ids():
	var seen = {}
	for mon in Game.party + Game.state.box:
		if mon == null: continue
		if mon.coop_uid == "" or seen.has(mon.coop_uid): mon.coop_uid = uid()
		seen[mon.coop_uid] = true

func save_current(reason: String) -> bool:
	if not can_save(): return false
	ensure_mon_ids()
	return persist_snapshot(SaveGame.snapshot(),reason)

func persist_snapshot(snapshot: Dictionary,reason: String = "native") -> bool:
	if not can_save(): return false
	# Snapshot after assigning IDs so native saves cannot omit new captures.
	ensure_mon_ids()
	# Keep outstanding learn prompts until native teaching has completed.
	var learning: Array = []
	for entry in Game.flags.get("coop_pending_learning",[]):
		var pending = false
		for queued in Progression.pending_moves:
			if queued.mon.coop_uid == entry.get("uid","") and queued.move == entry.get("move",""): pending = true
		if Progression._teaching != null and Progression._teaching.coop_uid == entry.get("uid",""): pending = true
		if reason == "trainer_result" or pending: learning.append(entry)
	Game.flags["coop_pending_learning"] = learning
	snapshot = SaveGame.snapshot()
	snapshot["game_version"] = "0.6.2a"
	var payload = JSON.stringify({"player_id":player_id,"session_id":session_id,"participants":participants,"generation":generation+1,"snapshot":snapshot})
	var envelope = JSON.stringify({"schema":SCHEMA,"sha256":payload.sha256_text(),"payload":payload})
	var temp = PATH + ".tmp"
	var f = FileAccess.open(temp,FileAccess.WRITE)
	if f == null: return _error("write_temp")
	f.store_string(envelope)
	f.flush()
	f.close()
	if decode(temp).is_empty(): return _error("verify_temp")
	# Never replace the last good backup with a corrupt primary.
	if not decode(PATH).is_empty():
		var backup_temp = PATH + ".bak.tmp"
		if DirAccess.copy_absolute(ProjectSettings.globalize_path(PATH),ProjectSettings.globalize_path(backup_temp)) != OK: return _error("backup_copy")
		if DirAccess.rename_absolute(ProjectSettings.globalize_path(backup_temp),ProjectSettings.globalize_path(PATH + ".bak")) != OK: return _error("backup_replace")
	if DirAccess.rename_absolute(ProjectSettings.globalize_path(temp),ProjectSettings.globalize_path(PATH)) != OK: return _error("commit_replace")
	generation += 1
	last_safe = snapshot.duplicate(true)
	last_save_ms = Time.get_ticks_msec()
	pending_save = false
	if is_instance_valid(status_label): status_label.text = "Co-op salvo / revisao %d / F5: salvar" % generation
	print("[coop-save] committed reason=",reason," generation=",generation," player=",player_id)
	return true

func _error(stage: String) -> bool:
	last_error = "Falha ao salvar: " + stage
	if is_instance_valid(status_label): status_label.text = last_error
	push_error("[coop-save] " + last_error)
	return false

func _process(_delta):
	var scene = get_tree().current_scene
	if scene != null and can_save() and scene.scene_file_path != last_scene:
		last_scene = scene.scene_file_path
		pending_save = true
	if (pending_save and can_save()) or Time.get_ticks_msec() - last_save_ms > 5000:
		last_save_ms = Time.get_ticks_msec()
		save_current("autosave")

func _input(event):
	if event is InputEventKey and event.pressed and not event.echo and (event.physical_keycode == KEY_F5 or event.keycode == KEY_F5):
		save_current("manual")

func _notification(what):
	if what == NOTIFICATION_WM_CLOSE_REQUEST:
		# During combat/loading the last committed safe snapshot remains authoritative.
		if can_save() and not save_current("close"):
			push_error("[coop-save] Close refused; use last backup or retry.")
			return
		get_tree().quit()

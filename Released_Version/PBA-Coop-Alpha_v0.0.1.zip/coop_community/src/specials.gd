extends Node
const Mon = preload("res://scripts/stats/mon.gd")
const Capture = preload("res://scripts/stats/capture.gd")
const FX = preload("res://scripts/capture_fx.gd")
const Items = preload("res://scripts/items.gd")
# Authored early evolved encounters; legendaries, rescues and scripted bosses stay native.
const IDS = ["pw_nidorino","r1_raticate","r2_pidgeotto","r22_primeape","vf_butterfree","vf_beedrill"]
var lan
var uid = ""
var rewards: Array = [[],[]]
var spent: Array = [{},{}]
var balls: Array = [{},{}]
var captured_slots: Array = []
var busy = false
var adapter
var capture_button: Button
var test_started = false
var test_aimed = false
var test_attempt_ms = 0
var test_quota = false

class WildAdapter extends Node3D:
	var trainer_id = ""
	var npc_name = ""
	var _def = {"class":"wild","ai_tier":"low"}
	var _spot_home = Vector3.ZERO
	var _spot_facing = 0
	var _spotting = false
	var _sight_cd = 0.0
	var talking = false
	var row = 0
	var mons: Array = []
	var arena = Vector2(13,13)
	func _mons(): return mons.map(func(m):return preload("res://scripts/stats/mon.gd").from_dict(m))
	func _battle_opts(_p): return {"center":global_position,"arena":arena,"music":"music/battle_wild","trainer_class":"wild"}

func _ready():
	lan = get_parent()
	var layer = CanvasLayer.new()
	layer.layer = 74
	add_child(layer)
	capture_button = Button.new()
	capture_button.text = "Capturar alvo (F9 / Select)"
	capture_button.position = Vector2(380,165)
	capture_button.pressed.connect(func(): Progression.throw_capture())
	layer.add_child(capture_button)

func is_special() -> bool:
	return uid != "" and lan.coop_battle_active()

func ball_inventory() -> Dictionary:
	var result = {"__space":maxi(0,Game.MAX_PARTY-Game.party.size())+maxi(0,Game.state.BOX_CAPACITY-Game.state.box.size())}
	for key in Game.bag:
		if Items.pocket_of(String(key)) == "balls": result[key] = int(Game.bag[key])
	return result

func intercept(body) -> bool:
	if not lan.peer_ready or String(body.static_uid) not in IDS or lan.launching: return false
	if lan.phase != "world" or Battle.in_battle or Game.menu_open or Game.cutscene or not get_tree().get_nodes_in_group("evolution").is_empty(): return true
	body.peace_timer = 8.0
	if lan.role == "guest":
		Game.talking = false
		Game.cutscene = false
		lan.player.controls_enabled = true
		_request.rpc_id(1,String(body.static_uid))
	else: _start(body)
	return true

@rpc("any_peer","call_remote","reliable")
func _request(id: String):
	if lan.role != "host" or multiplayer.get_remote_sender_id() != lan.remote_id or id not in IDS: return
	for _i in 20:
		if not lan.remote_busy: break
		await get_tree().create_timer(0.05).timeout
	for c in Creatures._all:
		if is_instance_valid(c) and String(c.static_uid)==id and c.visible and c.global_position.distance_to(lan.remote_at)<12:
			_start(c)
			return

func _start(body):
	if lan.role != "host" or lan.phase != "world" or lan.remote_busy or Game.flags.get("static_"+String(body.static_uid),false): return
	if lan.remote_scene != get_tree().current_scene.scene_file_path or lan.remote_zone != String(Game.event_zone(lan.player)):
		Game._msg("Aproxime seu parceiro no mesmo mapa para este encontro em dupla.")
		return
	uid = String(body.static_uid)
	rewards = [[],[]]
	spent = [{},{}]
	captured_slots.clear()
	balls = [ball_inventory(),{}]
	busy = false
	adapter = WildAdapter.new()
	adapter.trainer_id = "coop_static/"+uid
	adapter.npc_name = "%s SELVAGENS" % body.species.to_upper()
	adapter.mons = [body.mon.to_dict(),body.mon.to_dict().duplicate(true)]
	lan.player.get_parent().add_child(adapter)
	adapter.global_position = body.static_arena_center if body.static_arena_center.is_finite() else body.global_position
	adapter._spot_home = adapter.global_position
	if body.static_arena_size.x>0: adapter.arena = body.static_arena_size
	Battle.wild_arena = Vector2.ZERO
	Battle.wild_arena_center = Vector3.INF
	lan._log("special_requested",{"uid":uid,"species":body.species,"count":2})
	lan._host_encounter(adapter)

func accept_id(id: String) -> bool:
	return id.begins_with("coop_static/") and id.get_slice("/",1) in IDS

func begin_guest(id: String):
	uid = id.get_slice("/",1) if accept_id(id) else ""
	rewards = [[],[]]
	spent = [{},{}]
	captured_slots.clear()
	busy = false

func request_capture(ball = ""):
	if not is_special() or lan.phase != "fighting" or not is_instance_valid(Battle.partner): return
	var index = lan.fighters.find(Battle.partner.opponent)
	if index not in [2,3]:
		Game._msg("Mire em um dos dois adversarios com o controle de foco.")
		return
	if ball == "": ball = Progression.usable_ball()
	if lan.role == "host": _capture(0,index,String(ball))
	else: _catch_request.rpc_id(1,lan.battle_number,index,int(lan.fighter_epochs[index]),String(ball))

@rpc("any_peer","call_remote","reliable")
func _catch_request(number: int,index: int,epoch: int,ball: String):
	if lan.role != "host" or multiplayer.get_remote_sender_id() != lan.remote_id or number != lan.battle_number or index not in [2,3] or epoch != lan.fighter_epochs[index]: return
	_capture(1,index,ball)

func _notice(player_index: int,text: String):
	if player_index == 0: Game._msg(text,3.0)
	elif lan.peer_ready: _message.rpc_id(lan.remote_id,text)

@rpc("authority","call_remote","reliable")
func _message(text: String): Game._msg(text,3.0)

func _capture(player_index: int,index: int,ball: String):
	if not is_special() or lan.phase != "fighting": return
	if busy:
		_notice(player_index,"Captura em andamento. Aguarde antes de lançar outra bola.")
		return
	if not rewards[player_index].is_empty():
		_notice(player_index,"Voce ja capturou um Pokemon neste encontro. Ajude seu parceiro!")
		lan._log("capture_quota_rejected",{"player":player_index})
		return
	if not is_instance_valid(lan.fighters[index]) or not lan.fighters[index].alive(): return
	if int(balls[player_index].get("__space",0))<=0:
		_notice(player_index,"Sua equipe e o PC estao cheios.")
		return
	if Items.pocket_of(ball) != "balls" or int(balls[player_index].get(ball,0))<=0:
		_notice(player_index,"Sem Poké Bolas deste tipo.")
		return
	busy = true
	var number = lan.battle_number
	var body = lan.fighters[index]
	var freeze = {}
	for c in lan.fighters:
		if is_instance_valid(c) and c.alive():
			freeze[c] = c.mode
			c.mode = preload("res://scripts/creature.gd").Mode.IDLE
			c.velocity = Vector3.ZERO
	balls[player_index][ball] -= 1
	spent[player_index][ball] = int(spent[player_index].get(ball,0))+1
	if player_index == 0: Game.state.remove_item(ball,1)
	elif lan.peer_ready: _ball_consumed.rpc_id(lan.remote_id,lan.battle_number,ball)
	var result = Capture.throw_ball(body.max_hp,body.hp,body.mon.catch_rate(),ball,body.status,body.level)
	lan._log("special_capture_attempt",{"player":player_index,"target":index,"ball":ball,"caught":result.caught})
	if lan.peer_ready: _message.rpc_id(lan.remote_id,"Captura no alvo %d: %s. Aguarde..." % [index-1,body.species])
	var sprite_pos = body.sprite.position
	var ball_node = await FX.throw_and_wobble(Game,lan.player.get_parent(),lan.fighters[player_index].global_position+Vector3(0,1.2,0),body,ball,result.shakes)
	if not is_instance_valid(body) or not Battle.in_battle or lan.phase != "fighting" or number != lan.battle_number:
		if is_instance_valid(ball_node): ball_node.queue_free()
		busy = false
		return
	if result.caught:
		var mon = Mon.from_dict(body.mon.to_dict())
		mon.coop_uid = lan.persistence.uid()
		mon.owner = "player"
		mon.ball = ball
		mon.met_level = mon.level
		mon.met_zone = SaveGame.location_name()
		mon.set_friend(Mon.FRIEND_START)
		for stat in mon.evs: mon.evs[stat] = 0
		mon.recalc()
		rewards[player_index].append(mon.to_dict())
		captured_slots.append(index-2)
		await FX.success(Game,ball_node)
		_notice(player_index,"Capturado! A captura sera salva ao vencer este encontro.")
		lan._log("special_captured",{"player":player_index,"target":index,"species":mon.species,"uid":mon.coop_uid})
		body.take_damage(body.max_hp+1,Vector3.ZERO,0.0)
	else:
		await FX.release(Game,ball_node,body,sprite_pos)
		_notice(player_index,"O Pokemon escapou! Voce pode tentar outra vez.")
	for c in freeze:
		if is_instance_valid(c) and c.alive(): c.mode = freeze[c]
	busy = false

@rpc("authority","call_remote","reliable")
func _ball_consumed(number: int,ball: String):
	if number==lan.battle_number and is_special(): Game.state.remove_item(ball,1)

func summary() -> Dictionary:
	return {"uid":uid,"rewards":rewards.duplicate(true),"spent":spent.duplicate(true),"captured_slots":captured_slots.duplicate()}

func settle(outcome: String,data: Dictionary):
	if uid == "": return
	if outcome == "won" and data.get("uid","")==uid:
		var index = 0 if lan.role == "host" else 1
		for ball in data.spent[index]: Game.state.remove_item(String(ball),int(data.spent[index][ball]))
		for row in data.rewards[index]:
			var mon = Mon.from_dict(row)
			mon.ensure_ot_id(Game.state.trainer_id,Game.state.player_name)
			if Game.party.size()<Game.MAX_PARTY: Game.party.append(mon)
			else: Game.state.box.append(mon)
			Game.state.mark_caught(mon.species)
		Game.flags["static_"+uid] = true
		Game.party_changed.emit()
		for c in Creatures._all.duplicate():
			if is_instance_valid(c) and String(c.static_uid)==uid: c.queue_free()
		lan._log("special_settled",{"uid":uid,"captures":data.rewards[index].size(),"saved":lan.persistence.save_current("special_result")})
	else: Game._msg("Encontro interrompido ou perdido: capturas e bolas voltaram ao checkpoint.",5.0)
	for marker in get_tree().get_nodes_in_group("static_encounters"):
		if marker.uid == uid:
			if outcome == "won": marker.queue_free()
			else: marker._fired = false
	if is_instance_valid(adapter): adapter.queue_free()
	uid = ""
	busy = false

func _input(event):
	if not is_special(): return
	if event is InputEventKey and event.pressed and not event.echo and event.keycode==KEY_F9: Progression.throw_capture()
	if event is InputEventJoypadButton and event.pressed and event.button_index==JOY_BUTTON_BACK: Progression.throw_capture()

func _process(_delta):
	capture_button.visible = is_special() and lan.phase=="fighting"
	if not lan.auto_test or lan.test_case not in ["special","primeape"]: return
	var wanted = "r22_primeape" if lan.test_case=="primeape" else "r1_raticate"
	var zone = "route_22" if lan.test_case=="primeape" else "route_1"
	if not test_started and lan.role=="host" and lan.peer_ready and lan.phase=="world" and lan.remote_zone==zone:
		for c in Creatures._all:
			if is_instance_valid(c) and String(c.static_uid)==wanted:
				test_started = true
				Battle.start_battle(c)
				break
	if lan.phase!="fighting" or lan.fighters.size()!=4: return
	var index = 2 if lan.role=="host" else 3
	if not test_aimed and is_instance_valid(lan.fighters[index]):
		test_aimed = true
		Battle.set_target(lan.fighters[index])
		test_attempt_ms = Time.get_ticks_msec()
	if lan.role=="host" and not test_quota and not rewards[0].is_empty() and not busy:
		test_quota = true
		_capture(0,3,"master_ball")
	if test_aimed and Time.get_ticks_msec()-test_attempt_ms>1500:
		test_attempt_ms = Time.get_ticks_msec()
		Progression.throw_capture("master_ball")

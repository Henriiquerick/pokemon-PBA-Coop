from pathlib import Path
import os,subprocess,time,json,argparse
def main(runtime,logs):
    logs.mkdir(parents=True,exist_ok=False);ps=[];rows={}
    try:
        for role in ['host','guest']:
            env=os.environ.copy();env['APPDATA']=str(logs/role)
            f=(logs/(role+'.log')).open('w',encoding='utf8')
            cmd=[str(runtime/'PokemonBattleAdvanced.exe'),'--headless','--','--coop-campaign','--coop-role='+role,'--coop-port=25142','--coop-start=route2','--coop-autotest','--coop-persist-test','--coop-test=worldfix']
            p=subprocess.Popen(cmd,cwd=runtime,env=env,stdout=f,stderr=f);ps.append((role,p,f));time.sleep(1)
        for role,p,f in ps:
            p.wait(timeout=75);f.close()
            text=(logs/(role+'.log')).read_text(encoding='utf8')
            assert p.returncode==0 and 'SCRIPT ERROR' not in text,(role,p.returncode,text[-1800:])
            rows[role]=[json.loads(line.split('[campaign-lan] ',1)[1]) for line in text.splitlines() if '[campaign-lan] {' in line]
        audits={role:[r for r in data if r['event']=='world_audit'] for role,data in rows.items()}
        assert any(r['remote_count']==3 for r in audits['guest']),audits['guest']
        assert any(r['remote_count']==2 for r in audits['guest']),audits['guest']
        for role in audits:
            assert any(r['minimap'] and not r['has_town_map'] for r in audits[role]),(role,audits[role])
        rainy=[r for r in audits['guest'] if r['rain']>0.5]
        assert len(rainy)>=6, rainy
        report={'passed':True,'three_companions_and_recall':True,'minimap_without_item_both':True,'guest_rain_samples':len(rainy),'guest_clock_offset_minutes':6000,'visual_marker_manual_pending':True}
        (logs/'result.json').write_text(json.dumps(report,indent=2),encoding='utf8');print(json.dumps(report))
    finally:
        for _,p,f in ps:
            if p.poll() is None:p.kill();p.wait()
            f.close()
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--runtime',required=True,type=Path);ap.add_argument('--logs',required=True,type=Path)
    a=ap.parse_args();main(a.runtime.resolve(),a.logs.resolve())

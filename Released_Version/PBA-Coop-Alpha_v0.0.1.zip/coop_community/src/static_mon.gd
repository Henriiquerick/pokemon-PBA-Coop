extends Node3D
















const ROW_VEC: = [Vector3(0, 0, 1), Vector3(-1, 0, 0), Vector3(1, 0, 0), Vector3(0, 0, -1)]

const SCALE: = 1.25

const BURST_DIST: = 2.2




const Combatant: = preload("res://scripts/combat/combatant.gd")
const WildMark: = preload("res://scripts/wild_mark.gd")
const FLY_CRUISE: = 1.3
const BREATH: = 0.02
const TURN_MIN: = 3.0
const TURN_MAX: = 6.0
const HOP_MIN: = 5.0
const HOP_MAX: = 8.0



const RITE_SPIN: = 2.4
const RITE_HOP_MIN: = 0.55
const RITE_HOP_MAX: = 0.95
const RITE_SING_MIN: = 2.2
const RITE_SING_MAX: = 4.5
const SING_FX: = "sing_notes"
const SING_SLOT: = "sfx/moves/sing"

@export var uid: = ""
@export var species: = ""
@export var level: = 5
@export var hidden: = false

@export var facing: = 0


@export var arena_center: = Vector3.INF
@export var arena_size: = Vector2.ZERO


@export var arena_lead: = Vector3.INF


@export var arena_burst: = Vector3.INF

@export var arena_wide_camera: = false


@export var battle: = true



@export var blocking: = false
@export var talk_message: = ""



@export var sleeper: = false

@export var requires_flag: = ""


@export var hidden_by_flag: = ""


@export var terrain: = ""

@export var moves: PackedStringArray = PackedStringArray()

@export var serum: = false

@export var specimen: Dictionary = {}

@export var adds: Array = []

@export var ai_tier: = ""



@export var touch: = false


@export var caged: = false
@export var cage_height: = 1.1
const HURT_MIN: = 3.0
const HURT_MAX: = 7.0

const TOUCH_RANGE: = 1.1

var _fired: = false
var _sleeping: = false

var _parked: = false
var _zzz: Node3D
var _talking: = false

var _pet: Creature
var _flier: = false
var _scale: = SCALE
var _hurt_t: = 0.0
var _idle_t: = 0.0
var _turn_t: = 0.0
var _hop_t: = 0.0

var _celebrate: = false
var _heading: = 0.0
var _spin: = 0.0
var _sing_t: = 0.0


func _exit_tree() -> void :
	if caged and is_instance_valid(_pet):
		_pet.queue_free()


func _ready() -> void :
	add_to_group("static_encounters")
	if requires_flag != "" and not Game.flags.get(requires_flag, false):
		queue_free()
		return
	if hidden_by_flag != "" and Game.flags.get(hidden_by_flag, false):
		queue_free()
		return
	if battle and Game.flags.get("static_" + uid, false):
		queue_free()
		return
	if terrain != "" and battle:
		Game.battle_started.connect(_terrain_on_battle)
	if talk_message != "" or sleeper:
		add_to_group("npc")
	if sleeper:
		_sleeping = not Game.flags.get(uid + "_awake", false)
		touch = not _sleeping
	if hidden:
		_make_trigger()
	else:


		_spawn_creature.call_deferred(global_position)
		if touch:
			_make_touch_area()




func _make_touch_area() -> void :
	var area: = Area3D.new()
	area.collision_layer = 0
	area.collision_mask = 1
	area.monitorable = false
	var cs: = CollisionShape3D.new()
	var sh: = SphereShape3D.new()
	sh.radius = TOUCH_RANGE
	cs.shape = sh
	cs.position.y = 0.9
	area.add_child(cs)
	add_child(area)
	area.body_entered.connect(_on_touch)


func _on_touch(body: Node) -> void :
	if _fired or not body.is_in_group("player") or Game.is_busy() or Game.party.is_empty():
		return
	_fired = true
	_touch_fight()








func _touch_fight() -> void :
	Game.talking = false
	if _pet == null or not is_instance_valid(_pet):
		_fired = false
		return
	Battle.engage(_pet)
	if not Battle.in_battle:
		_fired = false
		return
	await Game.battle_ended
	_fired = false
	_repark()






func _repark() -> void :
	if _pet == null or not is_instance_valid(_pet) or not _pet.alive() or Game.flags.get("static_" + uid, false):
		return
	_parked = true
	_pet.set_physics_process(false)


	if "physics_interpolation_mode" in _pet:
		_pet.physics_interpolation_mode = 2
	_pet.global_position = global_position
	Transitions.reset_interp(_pet)
	_pet.mode = Creature.Mode.IDLE
	_pet.velocity = Vector3.ZERO
	_pet.peace_timer = 0.0
	_pet.mon.hp = mini(int(_pet.mon.hp), int(_pet.mon.max_hp))
	_pet.sync_from_mon()
	_pet.facing = ROW_VEC[clampi(facing, 0, 3)]
	_pet._animate(0.0, false)



func prompt_verb() -> String:
	if _sleeping:
		return "Wake up" if (Game.item_count("poke_flute") > 0 and Game.item_count("silph_scope") > 0) else "Check"
	return "Check" if talk_message != "" else "Battle"


func focus_reach() -> float:
	return 3.4 if blocking else 2.0


func prompt_anchor() -> Vector3:
	return global_position + Vector3(0, 2.2, 0)



func interact(_p: Node) -> void :
	if _sleeping:
		_sleeper_talk()
	elif sleeper:
		_touch_fight()
	elif talk_message != "":
		var hud: Node = Game.get_hud()
		if hud != null and hud.has_method("show_notice"):
			hud.show_notice(species.to_upper(), talk_message, species, 4.0)
		else:
			Game._msg(talk_message, 4.0)



func _sleeper_talk() -> void :
	if _talking or Battle.in_battle:
		return
	_talking = true
	await Story.begin(false)
	var msg: = talk_message if talk_message != "" else "A POKéMON is sprawled out in a deep and comfortable slumber."
	if Game.item_count("poke_flute") <= 0:
		await Story.say("", [msg, "It will not budge. Nothing you can do will wake it...\nMaybe a special flute could."])
		Story.end()
		_talking = false
		return
	if Game.item_count("silph_scope") <= 0:
		await Story.say("", [msg, "You have a POKé FLUTE, but something is off...\nYou can't make out what this POKéMON is up to.\nA SILPH SCOPE might help."])
		Story.end()
		_talking = false
		return
	await Story.say("", [msg])
	if not await Story.ask("", "Play the POKé FLUTE?"):
		Story.end()
		_talking = false
		return
	await _wake_up()
	_talking = false



func _wake_up() -> void :
	var p: Node3D = Story.player()
	p.face_toward(global_position)
	var notes: = Vector3(0, 2.2, 0)
	Vfx.pmd_fx(SING_FX, p.global_position + notes, Vector3(0, 0, 1), {"billboard": true, "scale": 1.6})
	Audio.play_at(SING_SLOT, p.global_position, 0.0, 1.0)
	await get_tree().create_timer(1.3).timeout
	Vfx.pmd_fx(SING_FX, p.global_position + notes, Vector3(0, 0, 1), {"billboard": true, "scale": 1.6})
	Audio.play_at(SING_SLOT, p.global_position, 0.0, 1.15)
	await get_tree().create_timer(1.3).timeout
	Game.flags[uid + "_awake"] = true
	_wake_body()
	Vfx.shake(0.5, 0.6)
	_hop()
	Audio.cry(species, _pet.global_position, 0.8)
	await get_tree().create_timer(0.9).timeout
	await Story.say("", ["%s woke up!\nIt is furious!" % species.to_upper()])
	Story.end()
	_touch_fight()



func _wake_body() -> void :
	_sleeping = false
	touch = true
	_make_touch_area()
	if is_instance_valid(_zzz):
		_zzz.queue_free()
	if _pet == null or not is_instance_valid(_pet):
		return
	_pet._napping = false
	_pet._pmd_anim = ""
	_pet.add_to_group("wild")
	_pet.is_wild = true
	_pet.peace_timer = 0.0


	_pet.label.visible = true


func _make_trigger() -> void :
	var area: = Area3D.new()
	area.collision_layer = 0
	area.collision_mask = 1
	area.monitorable = false
	var cs: = CollisionShape3D.new()
	var sh: = BoxShape3D.new()
	sh.size = Vector3(2.0, 3.0, 2.0)
	cs.shape = sh
	cs.position.y = 1.5
	area.add_child(cs)
	add_child(area)
	area.body_entered.connect(_on_body_entered)


func _on_body_entered(body: Node) -> void :
	if _fired or not body.is_in_group("player") or Game.is_busy() or Game.party.is_empty():
		return
	_fired = true
	_burst_out(body)




func _burst_out(p: Node3D) -> void :
	Battle._ambush = true
	p.controls_enabled = false
	p.show_alert(true)
	await get_tree().create_timer(0.6).timeout
	p.show_alert(false)
	var target: Vector3 = p.global_position + p.facing_vector() * BURST_DIST

	if arena_size.x > 0.0 and arena_center.is_finite():
		var center: Vector3 = get_parent().to_global(arena_center)
		var r: = Rect2(center.x - arena_size.x * 0.5, center.z - arena_size.y * 0.5, 
			arena_size.x, arena_size.y)
		target.x = clampf(target.x, r.position.x + 0.6, r.end.x - 0.6)
		target.z = clampf(target.z, r.position.y + 0.6, r.end.y - 0.6)
	if arena_burst.is_finite():
		target = get_parent().to_global(arena_burst)
	target.y = Transitions.ground_y(target, p.global_position.y)
	var c: = _spawn_creature(target + Vector3(0, -0.8, 0))
	var tw: = create_tween()
	tw.tween_property(c, "position", target + Vector3(0, 1.3, 0), 0.2).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	tw.tween_property(c, "position", target, 0.22).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
	await tw.finished
	Battle._ambush = false
	_start_fixed_battle(c)





func _start_fixed_battle(c: Creature) -> void :
	var fixed: = arena_size.x > 0.0 and arena_center.is_finite()
	if fixed:
		Battle.wild_arena = arena_size
		Battle.wild_arena_center = get_parent().to_global(arena_center)
	var was: = Battle.in_battle
	Battle.start_battle(c)
	if fixed and not was and Battle.in_battle:
		await Game.battle_ended
	if fixed:
		Battle.wild_arena = Vector2.ZERO
		Battle.wild_arena_center = Vector3.INF


func _spawn_creature(at: Vector3) -> Creature:
	var c: Creature
	if moves.is_empty() and specimen.is_empty():
		c = Encounters.spawn_creature(
			{"species": species, "level": level, "behaviour": "passive"}, get_parent(), at, 
			battle)
	else:
		var m = preload("res://scripts/stats/mon.gd").create(species, level)
		if not moves.is_empty():
			m.moves = Array(moves)
		if not specimen.is_empty():
			if specimen.has("ivs_min"):
				for st in ["hp", "atk", "def", "spa", "spd", "spe"]:
					m.ivs[st] = randi_range(int(specimen.ivs_min), 31)
			else:
				m.ivs = specimen.ivs.duplicate()
			m.nature = specimen.nature
			for s in specimen.get("evs", {}):
				m.evs[s] = int(specimen.evs[s])
			m.recalc()
			m.heal_full()
		c = Encounters.spawn_mon(m, get_parent(), at, battle, Creature.Behaviour.PASSIVE)
	c.static_uid = uid if battle else ""
	if serum:
		preload("res://scripts/world/cape_fx.gd").serum_on(c)
	if battle:
		c.static_arena_center = get_parent().to_global(arena_center)
		c.static_arena_size = arena_size
		if arena_lead.is_finite():
			c.static_arena_lead = get_parent().to_global(arena_lead)
		c.static_wide_camera = arena_wide_camera
		c.boss_adds = adds
		c.boss_ai_tier = ai_tier
	if not battle:
		c.remove_from_group("wild")
		c.is_wild = false
		c.label.visible = false
		c.collision_layer = 1 if blocking else 0



		c.set_physics_process(false)
	if sleeper and _sleeping:
		c.remove_from_group("wild")
		c.set_physics_process(false)
		c._napping = true
		c.is_wild = false
		c.label.visible = false
	c.mode = Creature.Mode.IDLE
	c.peace_timer = 0.0
	c.facing = ROW_VEC[clampi(facing, 0, 3)]
	c._animate(0.0, false)
	if caged:
		c.global_position = global_position
		_scale = minf(1.0, cage_height / maxf(c.look_height(), 0.1))
		_hurt_t = randf_range(1.0, HURT_MAX)
	c.sprite.scale = Vector3.ONE * _scale


	_pet = c
	_flier = c.combat.locomotion != "ground" and not caged
	if _flier:
		c.combat.flight = Combatant.Flight.AIRBORNE
		c.combat.fly_height = minf(c.combat.fly_height, FLY_CRUISE)
	_turn_t = randf_range(TURN_MIN, TURN_MAX)
	_hop_t = randf_range(HOP_MIN, HOP_MAX)
	var vis: = c.look_height()
	c.label.position.y = vis * _scale + 0.4
	if caged:
		return c
	if sleeper and _sleeping:
		_zzz = WildMark.spawn(get_parent(), c, "sleep")
		return c

	var sparkle: = Vfx.emitter(Color(1.0, 0.95, 0.6), 10, 1.4, 0.3, 0.09, 25.0, Vector3.UP, Vector3(0, -0.15, 0), 0.6)
	sparkle.position = Vector3(0, vis * 0.7, 0)
	sparkle.emitting = true
	c.add_child(sparkle)
	return c









func _physics_process(_delta: float) -> void :
	if _pet == null or not is_instance_valid(_pet) or not _pet.alive():
		return
	if _pet.mode != Creature.Mode.IDLE:
		return
	if sleeper or _parked:
		_pet.global_position = global_position


func celebrate(on: = true) -> void :
	if _celebrate == on:
		return
	_celebrate = on
	if not on:
		return
	_heading = randf() * TAU
	_spin = RITE_SPIN * randf_range(0.8, 1.2) * (1.0 if randi() % 2 == 0 else -1.0)
	_hop_t = randf_range(0.0, RITE_HOP_MAX)
	_sing_t = randf_range(0.0, RITE_SING_MAX)






func _process(delta: float) -> void :
	if _pet == null or not is_instance_valid(_pet):
		return
	if _pet.mode != Creature.Mode.IDLE:
		return



	if sleeper or _parked:
		_pet.global_position = global_position
	_idle_t += delta
	if caged:
		_pet.global_position = global_position
		_hurt_t -= delta
		if _hurt_t <= 0.0:
			_hurt_t = randf_range(HURT_MIN, HURT_MAX)
			_flinch()
		return
	if _flier:
		_pet._animate(delta, false)
		return
	if _celebrate:
		_rite_step(delta)
		return
	_pet.sprite.scale = Vector3.ONE * _scale * Vector3(1.0, 1.0 + sin(_idle_t * 1.6) * BREATH, 1.0)
	if _sleeping:
		return
	_turn_t -= delta
	if _turn_t <= 0.0:
		_turn_t = randf_range(TURN_MIN, TURN_MAX)
		_pet.facing = ROW_VEC[randi() % 4]
		_pet._animate(0.0, false)
	_hop_t -= delta
	if _hop_t <= 0.0:
		_hop_t = randf_range(HOP_MIN, HOP_MAX)
		_hop()





func _rite_step(delta: float) -> void :
	_heading += _spin * delta
	_pet.facing = Vector3(sin(_heading), 0.0, cos(_heading))
	_pet._animate(0.0, false)
	_hop_t -= delta
	if _hop_t <= 0.0:
		_hop_t = randf_range(RITE_HOP_MIN, RITE_HOP_MAX)
		_hop()
	_sing_t -= delta
	if _sing_t <= 0.0:
		_sing_t = randf_range(RITE_SING_MIN, RITE_SING_MAX)
		_sing()




func _sing() -> void :
	var head: = _pet.global_position + Vector3(0, _pet.look_height() * _scale + 0.5, 0)
	Vfx.pmd_fx(SING_FX, head, Vector3(0, 0, 1), {"billboard": true, "scale": 1.5})
	if randf() < 0.5:
		Audio.cry(species, _pet.global_position, randf_range(0.9, 1.15))
	else:
		Audio.play_at(SING_SLOT, _pet.global_position, -3.0, randf_range(0.95, 1.1))



func _flinch() -> void :
	if not _pet._pmd().is_empty():
		_pet._pmd_hurt()
		return
	var spr: = _pet.sprite
	var tw: = spr.create_tween()
	for dx in [0.05, -0.05, 0.04, -0.04, 0.0]:
		tw.tween_property(spr, "position:x", dx, 0.04)



func _hop() -> void :
	var spr: = _pet.sprite
	var tw: = spr.create_tween()
	tw.tween_property(spr, "position:y", 0.18, 0.16).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	tw.tween_property(spr, "position:y", 0.0, 0.2).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)



func _terrain_on_battle(_fighter, wild) -> void :
	if not is_instance_valid(wild) or String(wild.get("static_uid")) != uid:
		return
	var t: Node3D = preload("res://scripts/story/finale_terrain.gd").new()
	t.name = "BossTerrain"
	t.origin = get_parent().to_global(arena_center)
	t.half = Vector2(maxf(arena_size.x * 0.5 - 1.0, 2.0), maxf(arena_size.y * 0.5 - 1.0, 2.0))
	get_tree().current_scene.add_child(t)
	t.apply(terrain)
	Battle.ai_hazard = t.ai_hazard
	await Game.battle_ended
	Battle.ai_hazard = Callable()
	if is_instance_valid(t):
		t.clear()
		t.queue_free()

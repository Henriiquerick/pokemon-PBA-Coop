extends Node
const MapPanel = preload("res://scripts/ui/town_map_panel.gd")
const Sprites = preload("res://scripts/pokemon_sprites.gd")
var lan
var layer: CanvasLayer
var map_panel
var map_button: Button
var watch_button: Button
var watching = false
var watch_ui: Control
var viewport: SubViewport
var stage: Node3D
var caption: Label
var stats: Label
var remote_battle: Dictionary = {}
var actors: Dictionary = {}
var moves: Dictionary = {}
var timer = 0.0
var last_remote_ms = 0
var generation = 0
var test_stage = 0
var test_at = 0
var test_map_capture = false

func _ready():
	lan = get_parent()
	layer = CanvasLayer.new()
	layer.layer = 75
	add_child(layer)
	map_panel = MapPanel.new()
	map_panel.read_only = true
	map_panel.closed.connect(_release)
	layer.add_child(map_panel)
	map_button = Button.new()
	map_button.text = "Mapa (F7)"
	map_button.position = Vector2(380,165)
	map_button.pressed.connect(toggle_map)
	layer.add_child(map_button)
	watch_button = Button.new()
	watch_button.text = "Assistir (F8)"
	watch_button.position = Vector2(490,165)
	watch_button.pressed.connect(toggle_watch)
	layer.add_child(watch_button)
	Moves.move_released.connect(func(body,move):
		if is_instance_valid(body): moves[body.get_instance_id()] = String(move.get("name",move.get("id","")))
	)

func zone_id(zone: String) -> String:
	if zone.begins_with("route_"): return zone.replace("route_","rt_")
	for name in ["pallet","viridian","pewter","cerulean","vermilion","lavender","celadon","saffron","fuchsia","cinnabar","mt_moon","rock_tunnel"]:
		if zone.begins_with(name):
			if name in ["mt_moon","rock_tunnel"]: return name
			if name == "cinnabar": return "cinnabar_island"
			return name + ("_town" if name in ["pallet","lavender"] else "_city") if not zone == "viridian_forest" else zone
	return zone

func _available() -> bool:
	return lan.phase in ["world","offline"] and not Game.is_busy() and not watching

func toggle_map():
	if map_panel.visible:
		map_panel.close()
		return
	if not _available(): return
	if not lan.persistence.save_current("before_map"): return
	var here = zone_id(String(Game.event_zone(lan.player)))
	map_panel.open(MapPanel.visited_from(Game.flags,map_panel.places),here)
	Game.menu_open = true
	lan.player.controls_enabled = false
	_update_map()
	lan._log("community_map_open",{"here":here,"partner":map_panel.partner_zone,"connected":lan.peer_ready})

func _update_map():
	map_panel.partner_connected = lan.peer_ready
	map_panel.partner_zone = zone_id(lan.remote_zone)
	if not lan.peer_ready: map_panel.partner_info = "Parceiro desconectado. F7 ou Esc para voltar."
	elif lan.remote_scene == get_tree().current_scene.scene_file_path:
		var diff = lan.remote_at-lan.player.global_position
		map_panel.partner_info = "Parceiro: %s / %.0f m / leste %.0f m / norte %.0f m" % [lan.remote_zone,diff.length(),diff.x,-diff.z]
	else: map_panel.partner_info = "Parceiro em outro mapa: %s. Marcador ciano = regiao do parceiro." % lan.remote_zone
	map_panel.queue_redraw()

func _release():
	Game.menu_open = false
	if is_instance_valid(lan.player) and not Battle.in_battle and lan.phase in ["world","offline"]: lan.player.controls_enabled = true

func toggle_watch():
	if watching:
		_close_watch()
		return
	if not _available() or not remote_battle.get("active",false) or not lan.peer_ready: return
	if not lan.persistence.save_current("before_spectator"): return
	watching = true
	generation += 1
	Game.menu_open = true
	lan.player.controls_enabled = false
	watch_ui = Control.new()
	watch_ui.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	layer.add_child(watch_ui)
	var container = SubViewportContainer.new()
	container.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	container.stretch = true
	watch_ui.add_child(container)
	viewport = SubViewport.new()
	viewport.size = Vector2i(1280,720)
	viewport.own_world_3d = true
	container.add_child(viewport)
	stage = Node3D.new()
	viewport.add_child(stage)
	var env = WorldEnvironment.new()
	env.environment = Environment.new()
	env.environment.background_mode = Environment.BG_COLOR
	env.environment.background_color = Color(0.12,0.18,0.17)
	env.environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.environment.ambient_light_color = Color.WHITE
	env.environment.ambient_light_energy = 0.8
	stage.add_child(env)
	var floor_mesh = MeshInstance3D.new()
	var plane = PlaneMesh.new()
	plane.size = Vector2(48,36)
	floor_mesh.mesh = plane
	var material = StandardMaterial3D.new()
	material.albedo_color = Color(0.32,0.48,0.30)
	material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	floor_mesh.material_override = material
	stage.add_child(floor_mesh)
	var cam = Camera3D.new()
	cam.position = Vector3(0,17,14)
	cam.projection = Camera3D.PROJECTION_ORTHOGONAL
	cam.size = 16
	stage.add_child(cam)
	cam.look_at(Vector3.ZERO)
	cam.current = true
	caption = Label.new()
	caption.position = Vector2(25,25)
	caption.add_theme_font_size_override("font_size",22)
	watch_ui.add_child(caption)
	stats = Label.new()
	stats.position = Vector2(25,135)
	stats.add_theme_font_size_override("font_size",18)
	stats.add_theme_constant_override("outline_size",4)
	watch_ui.add_child(stats)
	var leave = Button.new()
	leave.text = "Voltar (F8 / Esc)"
	leave.position = Vector2(25,90)
	leave.pressed.connect(_close_watch)
	watch_ui.add_child(leave)
	lan._log("spectator_open")
	_render_state()

func _close_watch():
	if not watching: return
	watching = false
	generation += 1
	actors.clear()
	if is_instance_valid(watch_ui): watch_ui.queue_free()
	_release()
	lan._log("spectator_closed",{"controls":lan.player.controls_enabled})

@rpc("any_peer","call_remote","unreliable_ordered",4)
func _view_state(data: Dictionary):
	if multiplayer.get_remote_sender_id() != lan.remote_id or not lan.peer_ready: return
	if not data.get("actors",[]) is Array or data.get("actors",[]).size()>12: return
	last_remote_ms = Time.get_ticks_msec()
	remote_battle = data
	if not data.get("active",false): _close_watch()
	elif watching: _render_state()

func _render_state():
	if not watching: return
	caption.text = "ASSISTINDO AO PARCEIRO — %s\nSomente observacao / golpes e HP em tempo real" % String(remote_battle.get("zone",""))
	var seen = {}
	var readings = PackedStringArray()
	for data in remote_battle.get("actors",[]):
		readings.append("%s: %s Lv%d — HP %d/%d — %s" % ["Aliado" if int(data.get("side",0))==0 else "Adversario",data.species,data.level,data.hp,data.max_hp,data.get("move","")])
		var id = int(data.id)
		seen[id] = true
		if not actors.has(id):
			actors[id] = {"loading":true,"target":data.pos}
			_make_actor(data,generation)
		var actor: Dictionary = actors[id]
		actor.target = data.pos
		if actor.get("loading",true): continue
		actor.label.text = "%s Lv%d" % [data.species,data.level]
		actor.sprite.modulate.a = 1.0 if data.hp>0 else 0.3
		Sprites.animate(actor.sprite,actor.look,data.facing,int(Time.get_ticks_msec()/180))
	stats.text = "\n".join(readings)
	for id in actors.keys():
		if not seen.has(id):
			if actors[id].has("node"): actors[id].node.queue_free()
			actors.erase(id)

func _make_actor(data: Dictionary,version: int):
	await Sprites.prepare_species(String(data.species))
	if not watching or generation != version or not actors.has(int(data.id)): return
	var node = Node3D.new()
	stage.add_child(node)
	node.position = data.pos
	var sprite = Sprite3D.new()
	node.add_child(sprite)
	var look = Sprites.apply(sprite,String(data.species),bool(data.get("shiny",false)))
	var cell_height = float(sprite.texture.get_height()) / maxi(sprite.vframes,1) * sprite.pixel_size
	sprite.scale = Vector3.ONE * (2.2 / maxf(cell_height,0.1))
	var label = Label3D.new()
	label.position.y = 2.5
	label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	label.font_size = 32
	label.pixel_size = 0.02
	node.add_child(label)
	actors[int(data.id)] = {"loading":false,"node":node,"sprite":sprite,"look":look,"label":label,"target":data.pos}

func _input(event):
	if event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_F7: toggle_map();get_viewport().set_input_as_handled()
		if event.keycode == KEY_F8: toggle_watch();get_viewport().set_input_as_handled()
		if event.keycode == KEY_ESCAPE and watching: _close_watch();get_viewport().set_input_as_handled()
	if event is InputEventJoypadButton and event.pressed and event.button_index == JOY_BUTTON_BACK and (map_panel.visible or _available()): toggle_map()

func _process(delta):
	if not is_instance_valid(lan.player): return
	if lan.auto_test and lan.test_case=="community": _test_tick()
	map_button.visible = _available()
	watch_button.visible = _available() and remote_battle.get("active",false) and lan.peer_ready
	if map_panel.visible:
		if Battle.in_battle or lan.phase not in ["world","offline"]: map_panel.close()
		else: _update_map()
	if watching:
		if not lan.peer_ready or Time.get_ticks_msec()-last_remote_ms>5000 or lan.phase not in ["world","offline"]: _close_watch()
		else:
			for actor in actors.values():
				if not actor.get("loading",true): actor.node.position = actor.node.position.lerp(actor.target,minf(delta*14,1))
	timer += delta
	if timer<0.1 or not lan.peer_ready: return
	timer = 0
	var active = Battle.in_battle and not Battle._intro and not Battle._ending and not lan.coop_battle_active()
	var data = []
	if active:
		var center = Vector3(Battle.arena_rect.get_center().x,Transitions.ground_y(lan.player.global_position,lan.player.global_position.y),Battle.arena_rect.get_center().y)
		for body in (Battle.allies+Battle.foes()).slice(0,12):
			if not is_instance_valid(body): continue
			data.append({"id":body.get_instance_id(),"side":body.side,"species":body.species,"level":body.level,"shiny":body.mon.shiny,"pos":body.global_position-center,"facing":body.facing,"hp":body.hp,"max_hp":body.max_hp,"move":moves.get(body.get_instance_id(),"")})
	_view_state.rpc_id(lan.remote_id,{"active":active,"actors":data,"zone":String(Game.event_zone(lan.player))})

func _test_tick():
	var now = Time.get_ticks_msec()
	if test_stage==5 and now-test_at>2500:
		lan._log("community_test_done",{"controls":lan.player.controls_enabled,"battle":Battle.in_battle,"watching":watching,"connected":lan.peer_ready})
		get_tree().quit()
		return
	if not lan.peer_ready: return
	if test_stage==1 and now-test_at>800 and not test_map_capture:
		test_map_capture = true
		if DisplayServer.get_name()!="headless": lan._request_capture("map")
	if test_stage==0 and lan.remote_zone!="" and _available():
		test_stage = 1
		test_at = now
		toggle_map()
		var pt = preload("res://coop/pt_br.gd")
		lan._log("translation_test",{"oak":pt.text("Gramps! I'm fed up with waiting!"),"move":pt.text("Rock Tomb"),"locale":TranslationServer.get_locale(),"entries":pt.catalogue.size()})
	elif test_stage==1 and now-test_at>1700:
		lan._log("map_marker_test",{"visible":map_panel.visible,"partner":map_panel.partner_zone,"found":map_panel.find(map_panel.partner_zone)>=0,"read_only":map_panel.read_only})
		map_panel.close()
		lan._log("map_return_test",{"controls":lan.player.controls_enabled})
		test_stage = 2
		test_at = now
	elif test_stage==2:
		if lan.role=="host" and now-test_at>1800:
			test_stage = 3
			Encounters.grass_encounter(lan.player,"res://data/encounters/route_2.json")
		elif lan.role=="guest" and remote_battle.get("active",false) and _available():
			toggle_watch()
			test_stage = 3
			test_at = now
	elif test_stage==3:
		if lan.role=="host" and Battle.in_battle and not Battle._intro:
			test_stage = 4
			test_at = now
		elif lan.role=="guest" and watching and now-test_at>2000:
			if DisplayServer.get_name()!="headless": lan._request_capture("spectator")
			lan._log("spectator_state_test",{"actors":actors.size(),"readonly":not Battle.in_battle,"hp":remote_battle.actors.map(func(a):return a.hp)})
			test_stage = 4
	elif test_stage==4 and lan.role=="host" and now-test_at>6500:
		Battle.end_battle("aborted")
		test_stage = 5
		test_at = now
	elif test_stage==4 and lan.role=="guest" and not watching:
		test_stage = 5
		test_at = now
	elif test_stage==5 and now-test_at>3000:
		lan._log("community_test_done",{"controls":lan.player.controls_enabled,"battle":Battle.in_battle,"watching":watching,"connected":lan.peer_ready})
		get_tree().quit()

extends Node
# Native Cable Club UI/session/apply, carried over the existing LAN peer.
# A durable host decision and per-profile receipt make retries idempotent.
const Session = preload("res://scripts/net/trade_session.gd")
const Apply = preload("res://scripts/net/trade_apply.gd")
const Screen = preload("res://scripts/ui/cable_club/trade_screen.gd")
const JOURNAL = "user://coop_s3/trade_pending.json"
var room_id = "LAN"
var pin = ""
var lan
var session
var screen
var layer: CanvasLayer
var button: Button
var invitation: ConfirmationDialog
var transaction = ""
var journal: Dictionary = {}
var peer_ready = false
var offered = false
var accepted = false
var waiting = false
var applying = false
var connection_seen = false
var auto_started = false
var cancel_exit_pending = false
var started_ms = 0

func _ready():
	lan = get_parent()
	layer = CanvasLayer.new()
	layer.layer = 70
	add_child(layer)
	button = Button.new()
	button.text = "Trocar LAN (F6)"
	button.position = Vector2(205,165)
	button.pressed.connect(request)
	layer.add_child(button)
	invitation = ConfirmationDialog.new()
	invitation.dialog_text = "Seu parceiro quer trocar Pokemon. Abrir a troca?"
	invitation.confirmed.connect(func(): _answer.rpc_id(lan.remote_id,transaction,true))
	invitation.canceled.connect(func(): _answer.rpc_id(lan.remote_id,transaction,false))
	layer.add_child(invitation)
	if FileAccess.file_exists(JOURNAL):
		var doc = JSON.parse_string(FileAccess.get_file_as_string(JOURNAL))
		if doc is Dictionary and doc.get("payload","") is String and String(doc.payload).sha256_text() == doc.get("sha256",""):
			var parsed = JSON.parse_string(doc.payload)
			if parsed is Dictionary: journal = parsed
		if journal.is_empty():
			waiting = true
			_lock(true)
			lan.label.text = "Troca pendente invalida: preserve o perfil e o journal para recuperacao."
		else:
			transaction = String(journal.id)
			waiting = true
			_lock(true)
			if journal.state == "commit": _apply_decision()

func _peer_id() -> String:
	return lan.remote_player_id

func _safe() -> bool:
	return lan.peer_ready and lan.phase == "world" and not Game.is_busy() and not waiting and not is_instance_valid(screen) and lan.remote_scene == get_tree().current_scene.scene_file_path and is_instance_valid(lan.remote_avatar) and lan.remote_avatar.visible and lan.player.global_position.distance_to(lan.remote_avatar.global_position) <= 8.0

func request():
	if not _safe() or lan.remote_busy: return
	if not lan.persistence.save_current("before_trade"): return
	transaction = Crypto.new().generate_random_bytes(16).hex_encode()
	waiting = true
	_lock(true)
	started_ms = Time.get_ticks_msec()
	lan.label.text = "Troca LAN: aguardando seu parceiro aceitar..."
	_invite.rpc_id(lan.remote_id,transaction)

@rpc("any_peer","call_remote","reliable")
func _invite(id: String):
	if multiplayer.get_remote_sender_id() != lan.remote_id: return
	# The reliable invite may arrive before the first unreliable presence packet.
	# Let the peer's scene/position settle, without locking or changing a party.
	for _i in 20:
		if _safe() or not lan.peer_ready: break
		await get_tree().create_timer(0.05).timeout
	if not _safe():
		lan._log("trade_invite_declined",{"reason":"busy_scene_or_distance"})
		_answer.rpc_id(lan.remote_id,id,false)
		return
	if not lan.persistence.save_current("before_trade"):
		_answer.rpc_id(lan.remote_id,id,false)
		return
	transaction = id
	waiting = true
	_lock(true)
	started_ms = Time.get_ticks_msec()
	if lan.auto_test: _answer.rpc_id(lan.remote_id,id,true)
	else: invitation.popup_centered()

@rpc("any_peer","call_remote","reliable")
func _answer(id: String,yes: bool):
	if multiplayer.get_remote_sender_id() != lan.remote_id or id != transaction or not waiting: return
	if not yes:
		_cancel.rpc_id(lan.remote_id,id)
		_close("Troca recusada.")
		return
	_open.rpc_id(lan.remote_id,id)
	_open_local()

@rpc("any_peer","call_remote","reliable")
func _open(id: String):
	if multiplayer.get_remote_sender_id() == lan.remote_id and waiting and id == transaction: _open_local()

func _open_local():
	session = Session.new()
	screen = Screen.new()
	screen.net = self
	screen.session = session
	screen.peer_name = "PARCEIRO LAN"
	screen.finished.connect(_screen_done)
	layer.add_child(screen)
	started_ms = Time.get_ticks_msec()
	lan._log("trade_open",{"id":transaction})

func send(msg: Dictionary):
	if lan.peer_ready: _message.rpc_id(lan.remote_id,transaction,msg)

@rpc("any_peer","call_remote","reliable")
func _message(id: String,msg: Dictionary):
	if multiplayer.get_remote_sender_id() != lan.remote_id or id != transaction or not is_instance_valid(screen) or not journal.is_empty(): return
	if String(msg.get("t","")) == "offer" and (not Apply.valid_offer(msg.get("mon",{})) or String(msg.mon.get("coop_uid","")).length() != 32): return
	screen.handle(msg)

func _write(data: Dictionary) -> bool:
	var payload = JSON.stringify(data)
	var f = FileAccess.open(JOURNAL+".tmp",FileAccess.WRITE)
	if f == null: return false
	f.store_string(JSON.stringify({"payload":payload,"sha256":payload.sha256_text()}))
	f.flush()
	f.close()
	if DirAccess.rename_absolute(ProjectSettings.globalize_path(JOURNAL+".tmp"),ProjectSettings.globalize_path(JOURNAL)) != OK: return false
	journal = data
	return true

func _screen_done(result: String):
	if result != "done":
		if lan.peer_ready: _cancel.rpc_id(lan.remote_id,transaction)
		_close("Troca cancelada.")
		return
	var slot = int(session.my_slot)
	if slot < 0 or slot >= Game.party.size() or Game.party[slot].coop_uid != String(session.my_mon.get("coop_uid","")) or not Apply.valid_offer(session.their_mon): return
	var data = {"id":transaction,"peer":_peer_id(),"state":"prepared","slot":slot,"give":session.my_mon,"got":session.their_mon}
	if not _write(data):
		lan.label.text = "Falha ao registrar a troca. Nao feche o jogo; preserve os logs."
		return
	lan._log("trade_prepared",{"id":transaction})
	_ready_peer.rpc_id(lan.remote_id,transaction,String(data.give.coop_uid),String(data.got.coop_uid))
	_try_commit()

@rpc("any_peer","call_remote","reliable")
func _ready_peer(id: String,give: String,got: String):
	if multiplayer.get_remote_sender_id() != lan.remote_id or id != transaction or session == null: return
	if give != String(session.their_mon.get("coop_uid","")) or got != String(session.my_mon.get("coop_uid","")): return
	peer_ready = true
	_try_commit()

func _try_commit():
	if lan.role != "host" or not peer_ready or journal.is_empty() or journal.state != "prepared": return
	var data = journal.duplicate(true)
	data.state = "commit"
	if not _write(data): return
	_apply_decision()
	_decision.rpc_id(lan.remote_id,transaction)

@rpc("authority","call_remote","reliable")
func _decision(id: String):
	if Game.flags.get("coop_trade_receipts",{}).has(id):
		_ack.rpc_id(lan.remote_id,id)
		if not journal.is_empty() and journal.id == id:
			DirAccess.remove_absolute(ProjectSettings.globalize_path(JOURNAL))
			journal.clear()
			_present()
		return
	if id != transaction or journal.is_empty() or journal.peer != _peer_id(): return
	var data = journal.duplicate(true)
	data.state = "commit"
	if not _write(data): return
	if lan.auto_test and lan.test_case == "trade_drop":
		lan._log("trade_injected_exit",{"id":id})
		get_tree().quit()
		return
	if _apply_decision():
		_ack.rpc_id(lan.remote_id,id)
		DirAccess.remove_absolute(ProjectSettings.globalize_path(JOURNAL))
		journal.clear()
		_present()

func _save() -> bool:
	Game.menu_open = false
	lan.player.controls_enabled = true
	var ok = lan.persistence.save_current("trade")
	_lock(true)
	return ok

func _apply_decision() -> bool:
	if journal.is_empty(): return false
	var receipts: Dictionary = Game.flags.get("coop_trade_receipts",{}).duplicate()
	if receipts.has(String(journal.id)): return true
	var slot = int(journal.slot)
	if slot < 0 or slot >= Game.party.size() or Game.party[slot].coop_uid != String(journal.give.coop_uid):
		lan.label.text = "Troca pendente: Pokemon original nao encontrado. Preserve o perfil."
		return false
	var before = Game.state.to_dict().duplicate(true)
	var result = Apply.apply(slot,journal.got)
	if not result.get("ok",false): return false
	var into = String(result.get("evolve_into",""))
	if into != "":
		for move in result.mon.evolve(into):
			Progression.queue_move(result.mon,String(move))
			var pending: Array = Game.flags.get("coop_pending_learning",[])
			pending.append({"uid":result.mon.coop_uid,"move":String(move)})
			Game.flags["coop_pending_learning"] = pending
		Game.state.mark_caught(into)
	receipts[String(journal.id)] = true
	Game.flags["coop_trade_receipts"] = receipts
	if not _save():
		Game.state.from_dict(before)
		return false
	lan._log("trade_committed",{"id":journal.id,"given":journal.give.species,"received":result.mon.species,"uid":result.mon.coop_uid,"saved":true})
	return true

@rpc("any_peer","call_remote","reliable")
func _ack(id: String):
	if lan.role != "host" or multiplayer.get_remote_sender_id() != lan.remote_id or journal.is_empty() or journal.id != id or journal.state != "commit": return
	if not _apply_decision(): return
	DirAccess.remove_absolute(ProjectSettings.globalize_path(JOURNAL))
	journal.clear()
	_present()

func _present():
	if applying: return
	applying = true
	if is_instance_valid(screen) and not lan.auto_test:
		await screen.play_transfer(Game.party[session.my_slot])
	_close("Troca concluida e salva nos dois perfis.")
	lan._log("trade_complete",{"id":transaction})
	if lan.auto_test:
		await get_tree().create_timer(4.0 if lan.role == "host" else 1.0).timeout
		lan._log("trade_test_exit")
		get_tree().quit()

@rpc("any_peer","call_remote","reliable")
func _cancel(id: String):
	if multiplayer.get_remote_sender_id() != lan.remote_id or id != transaction or (not journal.is_empty() and journal.state == "commit"): return
	DirAccess.remove_absolute(ProjectSettings.globalize_path(JOURNAL))
	journal.clear()
	_close("Troca cancelada. Nenhum Pokemon transferido.")

@rpc("any_peer","call_remote","reliable")
func _recover(id: String):
	if multiplayer.get_remote_sender_id() != lan.remote_id or lan.role != "host": return
	if journal.is_empty() and Game.flags.get("coop_trade_receipts",{}).has(id):
		_decision.rpc_id(lan.remote_id,id)
		return
	if not journal.is_empty() and journal.id == id and journal.state == "commit" and journal.peer == _peer_id():
		_decision.rpc_id(lan.remote_id,id)
	else:
		_cancel.rpc_id(lan.remote_id,id)
		if not journal.is_empty() and journal.state == "prepared" and journal.id == id:
			DirAccess.remove_absolute(ProjectSettings.globalize_path(JOURNAL))
			journal.clear()
			_close("Troca interrompida antes da decisao; cancelada.")

func _lock(value: bool):
	Game.menu_open = value
	if is_instance_valid(lan.player): lan.player.controls_enabled = not value

func _close(text: String):
	if is_instance_valid(screen): screen.queue_free()
	screen = null
	session = null
	waiting = false
	peer_ready = false
	offered = false
	accepted = false
	applying = false
	invitation.hide()
	_lock(false)
	lan.label.text = text
	if lan.persistence != null: lan.persistence.save_current("trade_exit")
	if lan.auto_test and lan.test_case == "trade_cancel" and not cancel_exit_pending:
		cancel_exit_pending = true
		_test_cancel_exit()

func _test_cancel_exit():
	# Keep the real peer alive long enough to deliver its reliable cancellation.
	await get_tree().create_timer(3.0 if lan.role=="host" else 1.0).timeout
	lan._log("trade_test_cancelled")
	get_tree().quit()

func _input(event):
	if event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_F6: request()

func _process(_delta):
	button.visible = lan.peer_ready and lan.phase == "world" and not waiting
	if waiting: _lock(true)
	if lan.peer_ready and not connection_seen:
		connection_seen = true
		if not journal.is_empty() and journal.peer == _peer_id():
			if lan.role == "host" and journal.state == "commit": _decision.rpc_id(lan.remote_id,String(journal.id))
			elif lan.role == "guest": _recover.rpc_id(lan.remote_id,String(journal.id))
	if not lan.peer_ready:
		connection_seen = false
		if waiting and journal.is_empty(): _close("Troca cancelada pela desconexao.")
		elif waiting: lan.label.text = "Troca pendente: reconecte o mesmo parceiro com estes perfis."
	if waiting and journal.is_empty() and not is_instance_valid(screen) and Time.get_ticks_msec()-started_ms > 30000:
		if lan.peer_ready: _cancel.rpc_id(lan.remote_id,transaction)
		_close("Convite de troca expirou.")
	if lan.auto_test and lan.test_case.begins_with("trade"):
		if not auto_started and lan.test_case != "trade_recover" and lan.role == "host" and _safe() and not lan.remote_busy:
			auto_started = true
			request()
		if is_instance_valid(screen) and session != null:
			if not offered:
				offered = true
				screen._pick(1)
				screen.press("confirm")
			if not accepted and not session.my_mon.is_empty() and not session.their_mon.is_empty():
				accepted = true
				if lan.test_case == "trade_cancel" and lan.role == "host": screen.press("cancel")
				elif lan.test_case != "trade_cancel": screen.press("trade")

extends RefCounted
# Exact catalogue only: identifiers, move names and saved data are never translated.
static var catalogue: Dictionary = {}
static var loaded = false
static var started = false

static func _load_catalogue():
	if loaded: return
	loaded = true
	var data = JSON.parse_string(FileAccess.get_file_as_string("res://coop/pt_br.json"))
	if data is Dictionary: catalogue = data

static func start():
	if started: return
	started = true
	_load_catalogue()
	var language = Translation.new()
	language.locale = "pt_BR"
	for key in catalogue: language.add_message(StringName(key),StringName(catalogue[key]))
	TranslationServer.add_translation(language)
	TranslationServer.set_locale("pt_BR")

static func text(value: String) -> String:
	_load_catalogue()
	return String(catalogue.get(value,value))

static func lines(values) -> PackedStringArray:
	var result = PackedStringArray()
	for value in values: result.append(text(String(value)))
	return result

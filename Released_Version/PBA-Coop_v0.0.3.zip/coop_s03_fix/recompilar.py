from pathlib import Path
import subprocess,os,argparse,json,hashlib
ROOT=Path(__file__).resolve().parent
if __name__=='__main__':
    ap=argparse.ArgumentParser(description='Recompila as fontes fornecidas usando GDRETools 2.7.4')
    ap.add_argument('--gdre',required=True,type=Path)
    args=ap.parse_args()
    env=os.environ.copy();data=ROOT/'build_userdata';data.mkdir(exist_ok=True);env['APPDATA']=str(data)
    names=['front_end','campaign','trainer','battle','combatant','encounters','save_game','arena','mon','persistence','minimap','weather']
    cmd=[str(args.gdre.resolve()),'--headless','--bytecode=4.7.1','--output='+str(ROOT/'payload')]
    cmd+=['--compile='+str(ROOT/'src'/(n+'.gd')) for n in names]
    (ROOT/'logs').mkdir(exist_ok=True)
    with (ROOT/'logs/compile.txt').open('w',encoding='utf8') as f:subprocess.run(cmd,stdout=f,stderr=f,env=env,check=True,timeout=60)
    manifest={f.as_posix():hashlib.sha256((ROOT/f).read_bytes()).hexdigest() for f in [Path('payload')/(n+'.gdc') for n in names]}
    for f in list((ROOT/'src').glob('*.gd')) + [ROOT/'src/arena.tscn']:
        manifest[f.relative_to(ROOT).as_posix()] = hashlib.sha256(f.read_bytes()).hexdigest()
    (ROOT/'payload/manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf8')
    print('Recompilado. Instale em um destino novo e valide antes de distribuir.')

# Atualizacao S3 Fix

Estado atual: todos os companheiros visuais, marcador no minimapa, clima coordenado pelo host e XP/conclusao unica dos encontros integrados. O XP desta entrega cobre os dois participantes ativos; reservas, dinheiro, insignias e historia continuam na S4. GUIA_FIX.md e RELATORIO_FIX.md descrevem as evidencias atuais. Notas anteriores abaixo sao historicas.

# Atualizacao S3

S3 acrescenta perfil persistente individual, IDs, backup e recuperacao. Consulte COOP_SAVE_FORMAT.md e S03_TEST_RESULTS.md para o estado atual. As notas de S01/S02 abaixo descrevem o checkpoint anterior; a limitacao de falta de gravacao foi substituida pela S3. Recompensas cooperativas, insignias, XP compartilhada e trocas continuam nas etapas seguintes.

# Plano incremental

1. **S01 — auditoria:** checkpoint v9, inventário, diagnóstico opcional, revisão do protocolo e regressão local. Homologação em dois PCs pendente.
2. **S02 — movimento e conexão:** usar métricas de ambos os PCs; buffer de interpolação com limitação de extrapolação; direção/animação; interface original para hospedar/entrar/desconectar, com erros e timeout. Manter CLI.
3. **S03 — persistência:** diretório separado versionado, IDs de jogador/Pokémon/sessão, gravação temporária e renomeação, backup e recuperação; campanha nova pelo fluxo original de inicial; continuar e reconectar. Testar fechamento completo dos dois jogos antes de liberar progresso.
4. **S04 — campanha:** percorrer matriz, distinguir batalha comum e evento roteirizado; pré-requisitos por jogador, troca de Pokémon e reservas; journal de resultado idempotente, XP total dividido entre participantes e recompensas únicas. Ginásios somente após teste de flags antes/depois e derrota.
5. **S05 — mundo:** priorizar catálogo de spawn com consumo individual persistente e atributos locais; loot por jogador; nenhuma multiplicação adicional se houver spawn compartilhado. Alternativa 1,5x depende de diagnóstico de inviabilidade, não está adotada.
6. **S06 — trocas:** reutilizar TradeSession/TradeApply após journal de commit, confirmações com revisões e recuperação entre os dois PCs; validar evolução por troca e UUIDs.
7. **S07 — homologação:** sessões prolongadas, quedas, reconexão, campanha, itens, capturas e trocas. Registrar evidências por build.

Não iniciar a próxima etapa se houver regressão crítica nesta. Não habilitar todos os treinadores por remover a whitelist: os eventos, bloqueios e recompensas ainda precisam de adaptação. Cada etapa gera patch e relatório próprios. Sem servidores dedicados ou mercado nesta sprint.

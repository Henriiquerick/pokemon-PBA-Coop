# Histórico consolidado

- Arena inicial: usuário confirmou dois PCs contra Rattata.
- Campanha Route 2 e duplas: usuário confirmou Ryan/Drew; regressões de KO, aparência e saída foram iteradas.
- V6: usuário confirmou fluidez e Pokémon solto visível nos dois PCs.
- V7: usuário confirmou Brock sem bugs; logs mostram saída do ginásio encerrando sessão.
- V8: testes locais entre mapas; usuário relatou desconexão em portões/Pewter e bloqueio de selvagens.
- V9: saves pessoais importados em cópias, selvagens solo liberados, heartbeat fora da existência do personagem, timeout 45 s e código de saída. Testada localmente; homologação posterior em dois PCs não recebida.
- S01/v10: checkpoint v9, documentação central, catálogo de compatibilidade e diagnóstico de rede opcional. Não modifica frequência normal ou regras de batalha/persistência.

- S3/v12: perfil versionado, IDs de jogador/sessao/Pokemon, saves individuais, continua??o local, inicio pelo fluxo original, backups, checksum, recuperacao, lock local e reconexao. Testes em S03_TEST_RESULTS.md; homologacao em dois PCs pendente.

- S3 Fix/v13: corrige multiplos companheiros, minimapa livre com parceiro, autoridade climatica e XP/conclusao idempotente dos encontros integrados. Migra perfis S3 sem alterar o original.

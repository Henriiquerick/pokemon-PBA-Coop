# Evidências S3

| Cenário | Estado | Evidência |
|---|---|---|
| Criar perfil de save importado, alterar dinheiro/HP/flag, salvar | testado localmente em executável real | `logs/persistence_with_box/result.json` |
| Fechar/reabrir alternando papel host/guest, preservar IDs e posição | testado localmente | casos 02/03 da suíte de persistência |
| Preservar bag e Pokémon de box com UUID distinto do time | testado localmente | asserts da suíte `validar_persistencia.py` |
| Recuperar backup; ambos inválidos; schema futuro; temporário incompleto | testado localmente | casos 04–07, códigos 0/9 conforme esperado |
| Falha ao abrir temporário preserva principal | testado localmente | `logs/persistence_final/extra_result.json` |
| Duas aberturas pelo lançador no mesmo perfil | segunda recusada localmente | `logs/persistence_final/extra_result.json` |
| Dois perfis, fechar ambos, reabrir/reconectar e batalhar Ryan | testado localmente em duas instâncias | `logs/network_final/reconnect_result.json`, 31 estados de HP iguais |
| Brock com persistência e reunião entre mapas | testado localmente | `logs/brock_persistent/travel/result.json`, 42 estados iguais |
| Nova campanha pelo prólogo original e escolha manual de inicial | implementado, pendente manual | roteiro GUIA_S03 item 1 |
| Captura real/loot, XP e PP em eventos originais | snapshot implementado; evento real pendente manual | roteiro GUIA_S03 itens 2/3 |
| Radmin, gamepad e troca de anfitrião em dois PCs | pendente de homologação | roteiro GUIA_S03 item 4 |
| Queda no meio da captura/batalha e fechamento da janela | recuperação do último ponto seguro implementada; cenários manuais pendentes | roteiro GUIA_S03 item 6 |
| Encerramento forçado após commit e reinício | testado localmente; bag/box e identidade preservados | `logs/persistence_with_box/forced_exit_result.json` |
| Modo solo original | inicialização headless sem erro de script | `logs/solo/result.json`; campanha solo completa não reexecutada |
| Rollback | executado em cópia de teste | `restaurar.py` repôs PCK anterior validado |
| Build final com F5 centralizado no controlador | regressão UI/Ryan local passou | `logs/release_ui/ui/result.json`, 37 estados iguais; pressionar F5 manualmente continua no roteiro do usuário |

As modificações de dinheiro/HP/flag da suíte são entradas artificiais para testar serialização e reinício, não prova de recompensa/XP/captura real. Ações de batalha automatizadas usam o combate original. O fechamento imediato do roteiro após carregamento foi ajustado para aguardar um segundo; não foi identificada a causa de todos os fechamentos anteriores do usuário.

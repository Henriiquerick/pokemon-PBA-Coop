extends Control













const UI: = preload("res://scripts/ui/ui_draw.gd")
const HintBar: = preload("res://scripts/ui/kit/pk_hint_bar.gd")
const ExpBarMath: = preload("res://scripts/ui/exp_bar_math.gd")
const Controls: = preload("res://scripts/controls.gd")
const Dex: = preload("res://scripts/dex.gd")
const PokemonSprites: = preload("res://scripts/pokemon_sprites.gd")
const Growth: = preload("res://scripts/stats/growth.gd")


const PANEL_X: = 20.0
const PANEL_TOP: = 16.0
const PANEL_W: = 210.0
const PANEL_H: = 74.0
const SLOT_S: = 26.0
const SLOT_GAP: = 6.0
const SLOT_COUNT: = 6
const PANEL_PAD: = 12.0

const FOE_BLUE: = Color("#3b82f6")


const PLATE_W: = 144.0
const PLATE_H: = 46.0
const PLATE_H_FOE: = 34.0
const PLATE_ABOVE: = 12.0
const PLATE_CLAMP: = 6.0

const PLATE_SPEED: = 90.0

const PLATE_CATCHUP_MAX: = 0.6

const PLATE_TELEPORT: = 160.0


const MOVE_W: = 128.0
const MOVE_H: = 46.0
const MOVE_GAP: = 6.0



const TOUCH_MOVE: = 92.0
const TOUCH_DODGE: = 112.0


const TOUCH_ROUND_FRAC: = 0.55

const TOUCH_ROUND_LIFT: = 1.0
const TOUCH_SWAP_W: = 72.0
const TOUCH_GAP: = 12.0
const TOUCH_MARGIN: = 26.0



const TOUCH_DIAMOND_X: = 0.56
const TOUCH_DIAMOND_Y_GAP: = 0.6
const ACTION_W: = 70.0
const ACTION_H: = 46.0
const ACTION_GAP: = 6.0
const BAR_LEFT: = 20.0
const BAR_BOTTOM: = 18.0

const TOUCH_A: = 0.64
const TOUCH_A_PRESSED: = 0.92


const LOG_W: = 560.0
const LOG_TOP: = 116.0
const LOG_H: = 32.0

var controlled_marker: Control
var _player_card: Control
var _foe_card: Control
var _ally_card: Control
var _player_panel: Control
var _foe_panel: Control
var _chip_player: Control
var _chip_foe: Control
var _moves: Array = []


var _loadouts: Control
var _back: Array = []
const BACK_OFF: = Vector2(12.0, -26.0)
const BACK_DIM: = Color(0.62, 0.66, 0.74, 1.0)
var _flip_base: Array = []

var _flip: = -1.0
var _flip_swapped: = false

const FLIP_SECS: = 0.26
var _items_btn: Control
var _jump_btn: Control
var _swap_btn: Control
var _party_btn: Control
var _sprint_btn: Control
var _pips: Control
var _shown: = false
var _layout_key: = ""
var _plate_targets: = {}
var _lan_extra: Control
var _tw: Tween
var _hint: Control
var _hint_tw: Tween

var _popups: Array = []
const POPUP_LIFE: = 1.8
const POPUP_H: = 27.0
const POPUP_GAP: = 12.0
const POPUP_RISE: = 6.0
const POPUP_MAX: = 4


func _ready() -> void :
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	modulate.a = 0.0
	visible = false
	_lan_extra = FighterCard.new()
	_lan_extra.role = "foe"
	_lan_extra.foe = true
	add_child(_lan_extra)
	_lan_extra.hide()
	controlled_marker = preload("res://scripts/ui/controlled_fighter_marker.gd").new()
	add_child(controlled_marker)

	_player_panel = TrainerPanel.new()
	_player_panel.foe = false
	add_child(_player_panel)

	_foe_panel = TrainerPanel.new()
	_foe_panel.foe = true
	add_child(_foe_panel)

	_chip_player = PortraitChip.new()
	add_child(_chip_player)
	_chip_foe = PortraitChip.new()
	_chip_foe.foe = true
	add_child(_chip_foe)

	_foe_card = FighterCard.new()
	_foe_card.role = "foe"
	_foe_card.foe = true
	add_child(_foe_card)

	_player_card = FighterCard.new()
	_player_card.role = "you"
	add_child(_player_card)

	_ally_card = FighterCard.new()
	_ally_card.role = "ally"
	add_child(_ally_card)


	_pips = PipsRow.new()
	_pips.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(_pips)

	_items_btn = ItemsButton.new()
	add_child(_items_btn)
	_jump_btn = JumpButton.new()
	add_child(_jump_btn)
	_sprint_btn = SprintButton.new()
	add_child(_sprint_btn)
	_party_btn = PartyButton.new()
	add_child(_party_btn)
	_swap_btn = SwapButton.new()
	_swap_btn.mouse_filter = Control.MOUSE_FILTER_STOP
	_swap_btn.visible = false
	add_child(_swap_btn)

	for i in 4:
		var bb: = MoveButton.new()
		bb.index = i
		bb.back = true
		bb.modulate = BACK_DIM
		bb.z_index = -1
		_back.append(bb)
		add_child(bb)
	_loadouts = LoadoutStrip.new()
	add_child(_loadouts)
	_loadouts.z_index = -1

	for i in 4:
		var b: = MoveButton.new()
		b.index = i
		_moves.append(b)
		add_child(b)

	var mv_sig = get_node_or_null("/root/Moves")
	if mv_sig:
		mv_sig.move_used.connect(_on_move_used)
	Game.item_used.connect(_on_item_used)



func _log() -> Node:
	var p: = get_parent()
	if p == null or p.get("battle_log") == null:
		return null
	return p.battle_log




static func chip_rect(foe: bool, vw: float) -> Rect2:
	var x: = vw - PANEL_X - PANEL_W - PANEL_H if foe else PANEL_X + PANEL_W
	return Rect2(x, PANEL_TOP, PANEL_H, PANEL_H)



static func slot_rect(foe: bool, i: int, vw: float) -> Rect2:
	var row_w: = SLOT_COUNT * SLOT_S + (SLOT_COUNT - 1) * SLOT_GAP
	var sx: = vw - PANEL_X - PANEL_PAD - row_w if foe else PANEL_X + PANEL_PAD
	return Rect2(sx + i * (SLOT_S + SLOT_GAP), PANEL_TOP + 38.0, SLOT_S, SLOT_S)


static func confirm_key() -> String:
	return Controls.key_label("confirm")



func show_hint(hints: Array, secs: = 3.5) -> void :
	if hints.is_empty():
		return
	if _hint == null:
		_hint = HintBar.new()
		add_child(_hint)
		_hint.visible = false
		_hint.modulate.a = 0.0
	_hint.set_hints(hints)
	_hint.position = Vector2(size.x * 0.5 - _hint.get_combined_minimum_size().x * 0.5, 152.0)
	if _hint_tw:
		_hint_tw.kill()
	_hint.visible = true
	_hint_tw = create_tween()
	_hint_tw.tween_property(_hint, "modulate:a", 1.0, 0.15)
	_hint_tw.tween_interval(secs)
	_hint_tw.tween_property(_hint, "modulate:a", 0.0, 0.3)
	_hint_tw.tween_callback( func(): _hint.visible = false)



func hint_hold(hints: Array) -> void :
	if hints.is_empty():
		return
	var lg: = _log()
	if lg != null and hints.size() == 1:
		lg.hint_glyph = String(hints[0][0])
		lg.hint_text = String(hints[0][1])
		return
	if _hint == null:
		_hint = HintBar.new()
		add_child(_hint)
		_hint.visible = false
		_hint.modulate.a = 0.0
	_hint.set_hints(hints)
	_hint.position = Vector2(size.x * 0.5 - _hint.get_combined_minimum_size().x * 0.5, 152.0)
	if _hint_tw:
		_hint_tw.kill()
	_hint.visible = true
	_hint.modulate.a = 1.0



func hint_clear() -> void :
	var lg: = _log()
	if lg != null:
		lg.hint_glyph = ""
		lg.hint_text = ""
	if _hint == null:
		return
	if _hint_tw:
		_hint_tw.kill()
	_hint_tw = create_tween()
	_hint_tw.tween_property(_hint, "modulate:a", 0.0, 0.2)
	_hint_tw.tween_callback( func(): _hint.visible = false)



func _place_at(c: Control, anchor: Vector2, size_px: Vector2, center: Vector2) -> void :
	if c.get_parent() != self:
		add_child(c)
	c.mouse_filter = Control.MOUSE_FILTER_IGNORE
	c.anchor_left = anchor.x
	c.anchor_right = anchor.x
	c.anchor_top = anchor.y
	c.anchor_bottom = anchor.y
	c.offset_left = center.x - size_px.x * 0.5
	c.offset_right = center.x + size_px.x * 0.5
	c.offset_top = center.y - size_px.y * 0.5
	c.offset_bottom = center.y + size_px.y * 0.5



func _put(c: Control, anchor: Vector2, r: Rect2) -> void :
	c.anchor_left = anchor.x
	c.anchor_right = anchor.x
	c.anchor_top = anchor.y
	c.anchor_bottom = anchor.y
	c.offset_left = r.position.x
	c.offset_right = r.end.x
	c.offset_top = r.position.y
	c.offset_bottom = r.end.y


func _ui_scale() -> float:
	return Controls.ui_scale() if Controls.is_touch() else 1.0




func _layout() -> void :
	var key: = "%s|%.3f|%.1fx%.1f" % [Controls.device(), _ui_scale(), size.x, size.y]
	if key == _layout_key:
		return
	_layout_key = key
	_put(_player_panel, Vector2(0, 0), Rect2(PANEL_X, PANEL_TOP, PANEL_W, PANEL_H))
	_put(_foe_panel, Vector2(1, 0), Rect2( - PANEL_X - PANEL_W, PANEL_TOP, PANEL_W, PANEL_H))
	_put(_chip_player, Vector2(0, 0), Rect2(PANEL_X + PANEL_W, PANEL_TOP, PANEL_H, PANEL_H))
	_put(_chip_foe, Vector2(1, 0), Rect2( - PANEL_X - PANEL_W - PANEL_H, PANEL_TOP, PANEL_H, PANEL_H))
	var row_y: = PANEL_TOP + 38.0
	_put(_pips, Vector2(0, 0), Rect2(PANEL_X + PANEL_PAD, row_y, 
		SLOT_COUNT * SLOT_S + (SLOT_COUNT - 1) * SLOT_GAP, SLOT_S))
	if Controls.is_touch():
		_touch_layout()
	else:
		_kb_layout()


func _kb_layout() -> void :
	var mh: = MOVE_H
	var y: = - BAR_BOTTOM - mh
	if _loadouts != null:
		_put(_loadouts, Vector2(0, 1), Rect2(BAR_LEFT + BACK_OFF.x, y + BACK_OFF.y - LoadoutStrip.CHIP_H - 4.0, 
			300.0, LoadoutStrip.CHIP_H))
	for i in 4:
		var x: = BAR_LEFT + i * (MOVE_W + MOVE_GAP)
		_put(_moves[i], Vector2(0, 1), Rect2(x, y, MOVE_W, mh))
		_put(_back[i], Vector2(0, 1), Rect2(Vector2(x, y) + BACK_OFF, Vector2(MOVE_W, mh)))
	var x: = BAR_LEFT + 4.0 * MOVE_W + 3.0 * MOVE_GAP + 10.0
	for b: Control in [_jump_btn, _sprint_btn]:
		_put(b, Vector2(0, 1), Rect2(x, y, ACTION_W, ACTION_H))
		b.set("touch_style", false)
		x += ACTION_W + ACTION_GAP
	x += 2.0
	for b: Control in [_items_btn, _party_btn, _swap_btn]:
		_put(b, Vector2(0, 1), Rect2(x, y, ACTION_W, ACTION_H))
		b.set("touch_style", false)
		x += ACTION_W + ACTION_GAP


func _touch_layout() -> void :
	var k: = _ui_scale()
	var ms: = Controls.touch_target_scale(TOUCH_MOVE)
	var ds: = Controls.touch_target_scale(TOUCH_DODGE)
	var s: = TOUCH_MOVE * ms
	var d: = TOUCH_DODGE * ds
	var r: = d * TOUCH_ROUND_FRAC
	var gap: = TOUCH_GAP * ms
	var margin: = TOUCH_MARGIN * k

	var dodge: = Rect2( - margin - d, - margin - d, d, d)
	_put(_sprint_btn, Vector2(1, 1), dodge)

	var dy: = s + gap * TOUCH_DIAMOND_Y_GAP
	var dx: = (s + gap) * TOUCH_DIAMOND_X
	var cx: = dodge.position.x - gap * 1.5 - s * 0.5 - dx
	var cy: = - margin - s * 0.5 - dy
	var spots: = [Vector2(0, dy), Vector2(dx, 0), Vector2( - dx, 0), Vector2(0, - dy)]
	var toff: = Vector2(10.0, -10.0) * ms
	for i in 4:
		var cp: = Vector2(cx, cy) + (spots[i] as Vector2) - Vector2(s, s) * 0.5
		_put(_moves[i], Vector2(1, 1), Rect2(cp, Vector2(s, s)))
		_put(_back[i], Vector2(1, 1), Rect2(cp + toff, Vector2(s, s)))

	var rx: = dodge.get_center().x - r * 0.5
	var up_gap: = r * TOUCH_ROUND_LIFT
	var party_y: = dodge.position.y - up_gap - r
	_put(_party_btn, Vector2(1, 1), Rect2(rx, party_y, r, r))
	_put(_items_btn, Vector2(1, 1), Rect2(rx, party_y - gap * 1.5 - r, r, r))

	var bottom: = Vector2(cx, cy) + (spots[0] as Vector2)
	var sw: = TOUCH_SWAP_W * ms
	var sh: = 44.0 * k
	_put(_swap_btn, Vector2(1, 1), Rect2(bottom.x - s * 0.5 - gap - sw, bottom.y - sh * 0.5, sw, sh))

	_put(_jump_btn, Vector2(1, 1), Rect2(0, 0, 0, 0))
	for b: Control in [_party_btn, _items_btn, _swap_btn, _sprint_btn, _jump_btn]:
		b.set("touch_style", true)



func loadout_available() -> bool:
	return _loadouts != null and _loadouts.shown()



func touch_held(action: String) -> bool:
	var t: = get_node_or_null("/root/Touch")
	return t != null and t.has_method("held") and bool(t.held(action))



func cluster_rect() -> Rect2:
	var rects: Array = []
	for i in _moves.size():
		var mr: = move_rect(i)
		if mr.has_area():
			rects.append(mr)
	var bots: Array = [_jump_btn, _sprint_btn]
	if not Controls.is_touch():
		bots.append(_items_btn)
		bots.append(_party_btn)
	else:
		bots.append_array([_items_btn, _party_btn, _swap_btn])
	for b: Control in bots:
		if b != null and b.visible:
			rects.append(Rect2(b.position, b.size))
	if rects.is_empty():
		return Rect2()
	var r: Rect2 = rects[0]
	for i in range(1, rects.size()):
		r = r.merge(rects[i])
	return r




func card_rect(which: String) -> Rect2:
	var c: Control = _player_card
	if which == "foe":
		c = _foe_card
	elif which == "ally":
		c = _ally_card
	return Rect2(c.position, c.size) if c != null and c.visible else Rect2()



func log_rect() -> Rect2:
	var p: = get_parent()
	var log: Control = p.get("battle_log") if p != null else null
	var top: = float(log.offset_top) if log != null else LOG_TOP
	return Rect2(size.x * 0.5 - LOG_W * 0.5, top, LOG_W, LOG_H)



func pips_rect() -> Rect2:
	return Rect2(_pips.position, _pips.size) if _pips else Rect2()



func player_panel_rect() -> Rect2:
	return Rect2(_player_panel.position, _player_panel.size) if _player_panel else Rect2()



func foe_panel_rect() -> Rect2:
	if _foe_panel == null or not _foe_panel.visible:
		return Rect2()
	return Rect2(_foe_panel.position, _foe_panel.size)



func party_rect() -> Rect2:
	return Rect2(_party_btn.position, _party_btn.size) if _party_btn and _party_btn.visible else Rect2()


func items_rect() -> Rect2:
	return Rect2(_items_btn.position, _items_btn.size) if _items_btn and _items_btn.visible else Rect2()


func jump_rect() -> Rect2:
	return Rect2(_jump_btn.position, _jump_btn.size) if _jump_btn else Rect2()


func swap_rect() -> Rect2:
	return Rect2(_swap_btn.position, _swap_btn.size) if _swap_btn else Rect2()


func sprint_rect() -> Rect2:
	return Rect2(_sprint_btn.position, _sprint_btn.size) if _sprint_btn else Rect2()


func moves_rect() -> Rect2:
	if _moves.is_empty():
		return Rect2()
	var r: = Rect2(_moves[0].position, _moves[0].size)
	for b in _moves:
		r = r.merge(Rect2(b.position, b.size))
	return r


func move_rect(i: int) -> Rect2:
	if i < 0 or i >= _moves.size():
		return Rect2()
	if Controls.is_touch() and not _moves[i].showing_item and _moves[i].move_id() == "":
		return Rect2()
	return Rect2(_moves[i].position, _moves[i].size)




func begin_loadout_flip() -> void :
	_flip = 0.0
	_flip_swapped = false


func flipping() -> bool:
	return _flip >= 0.0


func _flip_process(delta: float) -> void :
	if _flip < 0.0:
		return
	if _flip == 0.0:
		_flip_base = _back.map( func(b): return b.position)
	_flip = minf(_flip + delta / FLIP_SECS, 1.0)
	if not _flip_swapped and _flip >= 0.5:
		_flip_swapped = true
		Battle.commit_loadout_swap(Battle.partner)

	var s_y: float = maxf(absf(cos(_flip * PI)), 0.02)


	var turn: = sin(_flip * PI)
	for i in 4:
		_moves[i].squash_y = s_y
		var bb: Control = _back[i]
		bb.position = Vector2(_flip_base[i]) - BACK_OFF * turn
		bb.z_index = 1 if _flip < 0.5 else -1
		bb.modulate = BACK_DIM.lerp(Color.WHITE, turn)
	if _flip >= 1.0:
		_flip = -1.0
		for i in 4:
			_moves[i].squash_y = 1.0
			_back[i].position = _flip_base[i]
			_back[i].z_index = -1
			_back[i].modulate = BACK_DIM



func popup(text: String, col: = UiKit.AMBER) -> void :
	_popups.append({"text": text, "t": 0.0, "col": col})
	if _popups.size() > POPUP_MAX:
		_popups[0].t = maxf(float(_popups[0].t), POPUP_LIFE - 0.3)



func exp_animating() -> bool:
	for c in [_player_card, _ally_card]:
		if is_instance_valid(c) and c.exp_animating():
			return true
	return false



func card_for(mon: RefCounted) -> Control:
	for c in [_player_card, _ally_card]:
		if is_instance_valid(c) and is_instance_valid(c.body) and c.body.mon == mon:
			return c
	return null


func _draw() -> void :
	if _popups.is_empty():
		return
	var base: = PANEL_TOP + PANEL_H + 24.0 + POPUP_MAX * (POPUP_H + POPUP_GAP)
	var n: = _popups.size()
	for i in n:
		var p: Dictionary = _popups[i]
		var slot: = n - 1 - i
		var a: = clampf(1.0 - float(p.t) / POPUP_LIFE, 0.0, 1.0)
		var drift: = minf(float(p.t), 0.3) / 0.3 * POPUP_RISE
		var ty: = base - slot * (POPUP_H + POPUP_GAP) - drift
		var s: = String(p.text)
		var w: = UI.text_width(s, 20) + 22.0
		UI.rounded(self, Rect2(30, ty - 21, w, POPUP_H), Color(UiKit.INK, 0.72 * a), 7)
		UI.text(self, Vector2(41, ty), s, 20, Color(p.col, a), 3)



func foe_chips_rect() -> Rect2:
	if _foe_card == null:
		return Rect2()
	var c: Rect2 = _foe_card.chips_rect()
	return Rect2(_foe_card.position + c.position, c.size) if c.size.x > 0.0 else Rect2()



func vs_drawn() -> bool:
	return false


func _process(delta: float) -> void :
	_flip_process(delta)
	if not _popups.is_empty():
		for p in _popups:
			p.t = float(p.t) + delta
		_popups = _popups.filter( func(p): return float(p.t) < POPUP_LIFE)
		queue_redraw()
	var want: bool = Battle.in_battle and not Battle._intro
	if want != _shown:
		_shown = want
		if _tw:
			_tw.kill()
		_tw = create_tween().set_parallel(true)
		if want:
			visible = true
			_tw.tween_property(self, "modulate:a", 1.0, 0.25)
			_tw.tween_property(self, "position:y", 0.0, 0.3).from(24.0).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
		else:
			_tw.tween_property(self, "modulate:a", 0.0, 0.3)
			_tw.chain().tween_callback( func(): visible = _shown)
	if not visible:
		return
	_layout()

	_player_card.body = Battle.partner if is_instance_valid(Battle.partner) else null
	_foe_card.body = Battle.wild if is_instance_valid(Battle.wild) else null

	if is_instance_valid(Battle.partner) and Battle.extra_foes.size() + 1 > 1 and Battle.foes().has(Battle.partner.opponent):
		_foe_card.body = Battle.partner.opponent
	_ally_card.body = Battle.ai_ally() if Battle.ai_ally() != null else Battle.guest_ally()
	_player_panel.refresh()
	_foe_panel.refresh()
	_foe_panel.visible = not Battle.trainer_battle.is_empty()
	var vs: Dictionary = Battle.trainer_battle.get("versus", {})
	_chip_player.visible = not vs.is_empty()
	_chip_foe.visible = not vs.is_empty()
	_chip_player.path = String(vs.get("hero", ""))
	_chip_foe.path = String(vs.get("foe", ""))
	var lan = get_node_or_null("/root/LanCampaign")
	if lan != null and lan.coop_battle_active():
		var living = Battle.foes()
		if not living.has(_foe_card.body) and not living.is_empty(): _foe_card.body = living[0]
		var other = living.filter(func(c):return c != _foe_card.body)
		_lan_extra.body = other[0] if not other.is_empty() else null
		_lan_extra.visible = not other.is_empty()
		_lan_extra.position = Vector2(get_viewport_rect().size.x - PLATE_W - 24.0,160.0)
	else: _lan_extra.hide()
	_place_plates(delta)
	var ally_out: bool = is_instance_valid(_ally_card.body)
	_swap_btn.visible = ally_out and not _menu_hidden()

	var menu_hide: = _menu_hidden()
	var touch: = Controls.is_touch()
	var lo_on: bool = _loadouts != null and _loadouts.shown()
	if _loadouts != null:
		_loadouts.visible = not menu_hide and not touch
	for b in _back:
		b.visible = not menu_hide and lo_on and ( not touch or b.move_id() != "")
	for b in _moves:
		b.visible = not menu_hide and ( not touch or b.showing_item or b.move_id() != "")
	_items_btn.visible = not menu_hide and not Battle.challenge and not Battle.is_spar()
	_party_btn.visible = not menu_hide and not Battle.is_spar() and ( not Battle.challenge or BattleTower.is_rental(BattleTower.current) or lan != null)
	_jump_btn.visible = not menu_hide
	_pips.visible = not menu_hide
	_sprint_btn.visible = not menu_hide
	if Battle.safari != null:

		for b: Control in [_player_card, _ally_card, _player_panel, _foe_panel, _pips, _items_btn, _jump_btn, _sprint_btn, _party_btn, _swap_btn, _moves[3]]:
			b.visible = false
	for c in get_children():
		c.queue_redraw()



func _menu_hidden() -> bool:
	var tut: Node = get_tree().get_first_node_in_group("battle_tutorial") if get_tree() != null else null
	var lesson_wait: bool = tut != null and tut.has_method("waiting_for_dismiss") and bool(tut.waiting_for_dismiss())
	var touch_layer: Node = get_node_or_null("/root/Touch")
	var touch_on: bool = touch_layer != null and touch_layer.visible
	return touch_on and (Game.menu_open or Battle._awaiting_confirm or lesson_wait)



func _screen_point(body: Node, cam: Camera3D) -> Vector2:
	var lbl: Node3D = body.get_node_or_null("Label3D")
	var top: Vector3 = body.global_position + Vector3(0, (lbl.position.y if lbl else 1.0), 0)
	if cam.is_position_behind(top):
		return Vector2.INF
	return cam.unproject_position(top)


func _place_plates(delta: float) -> void :
	var cam: = get_viewport().get_camera_3d()
	var you: Node = _player_card.body
	var foe: Node = _foe_card.body
	var ally: Node = _ally_card.body
	var valid_you: bool = is_instance_valid(you) and you.mode != 3
	var valid_foe: bool = is_instance_valid(foe) and foe.mode != 3
	var valid_ally: bool = is_instance_valid(ally) and ally.mode != 3
	_player_card.visible = cam != null and valid_you
	_foe_card.visible = cam != null and valid_foe
	_ally_card.visible = cam != null and valid_ally
	if cam == null:
		return
	var py: = _screen_point(you, cam) if valid_you else Vector2.INF
	var pf: = _screen_point(foe, cam) if valid_foe else Vector2.INF
	var pa: = _screen_point(ally, cam) if valid_ally else Vector2.INF
	_plate_targets.clear()
	var roles: Array = []
	if valid_you:
		roles.append("you")
		_aim_plate("you", _player_card, py, pf if valid_foe else py + Vector2(220, 0), delta)
	if valid_foe:
		roles.append("foe")
		_aim_plate("foe", _foe_card, pf, py if valid_you else pf + Vector2(-220, 0), delta)
	if valid_ally:
		roles.append("ally")
		_aim_plate("ally", _ally_card, pa, pf if valid_foe else pa + Vector2(220, 0), delta)
	_resolve_plate_targets(roles)
	for role: String in roles:
		var card: Control = _player_card if role == "you" else (_foe_card if role == "foe" else _ally_card)
		_advance_plate(card, _plate_targets[role], delta)



static func plate_center(me: Vector2, _opp: Vector2, h: = PLATE_H) -> Vector2:
	return me - Vector2(0, PLATE_ABOVE + h * 0.5)



func _clamp_plate(pos: Vector2, h: float) -> Vector2:
	var centre: = FighterCard.clamp_center(pos + Vector2(PLATE_W, h) * 0.5, size, h)
	return centre - Vector2(PLATE_W, h) * 0.5


func _base_plate_speed() -> float:
	return PLATE_SPEED * clampf(size.y / 720.0, 0.5, 2.0)



func _aim_plate(role: String, c: Control, anchor: Vector2, _opp: Vector2, _delta: float) -> void :
	var teleported: bool = c.last_anchor != Vector2.INF\
	and anchor.distance_to(c.last_anchor) > PLATE_TELEPORT
	c.last_anchor = anchor
	var target: = _clamp_plate(plate_center(anchor, anchor, c.size.y) - c.size * 0.5, c.size.y)

	var cam: = get_viewport().get_camera_3d()
	if cam:
		for fighter in [_player_card.body, _foe_card.body, _ally_card.body]:
			if not is_instance_valid(fighter):
				continue
			var head: Vector2 = cam.unproject_position(fighter.head_pos())
			var feet: Vector2 = cam.unproject_position(fighter.global_position)
			var sprite_rect: = Rect2(Vector2(minf(head.x, feet.x) - 22, minf(head.y, feet.y) - 8), Vector2(absf(feet.x - head.x) + 44, absf(feet.y - head.y) + 16))
			if Rect2(target, c.size).intersects(sprite_rect):
				target.x = sprite_rect.end.x + 8 if anchor.x >= sprite_rect.get_center().x else sprite_rect.position.x - c.size.x - 8
				target = _clamp_plate(target, c.size.y)
				if Rect2(target, c.size).intersects(sprite_rect):
					target.y = sprite_rect.position.y - c.size.y - 16
	target = _keep_clear(target, c.size.y)
	target = _clamp_plate(target, c.size.y)
	_plate_targets[role] = target
	if not c.get_meta("placed", false):
		c.position = target
		c.set_meta("placed", true)
		c.moving = false
		return
	if teleported:
		var dist: = c.position.distance_to(target)
		c.move_speed = maxf(_base_plate_speed(), dist / PLATE_CATCHUP_MAX)
		c.moving = true



func _resolve_plate_targets(roles: Array) -> void :

	for _pass in roles.size():
		for i in roles.size():
			for j in range(i + 1, roles.size()):
				var a: String = roles[i]
				var b: String = roles[j]
				var ra: = Rect2(_plate_targets[a], Vector2(PLATE_W, FighterCard.plate_height(a)))
				var rb: = Rect2(_plate_targets[b], Vector2(PLATE_W, FighterCard.plate_height(b)))
				if not ra.grow(4.0).intersects(rb.grow(4.0)) or absf(ra.position.y - rb.position.y) < 20.0:
					continue
				var upper: String = a if ra.position.y < rb.position.y else b
				var lower: String = b if upper == a else a
				var h: = FighterCard.plate_height(upper)
				var p: Vector2 = _plate_targets[upper]
				p.y = Vector2(_plate_targets[lower]).y - h - 10.0
				p = _clamp_plate(_keep_clear(p, h), h)
				if not Rect2(p, Vector2(PLATE_W, h)).grow(4.0).intersects(Rect2(_plate_targets[lower], Vector2(PLATE_W, FighterCard.plate_height(lower))).grow(4.0)):
					_plate_targets[upper] = p
	var ordered: = roles.duplicate()
	ordered.sort_custom( func(a, b): return Vector2(_plate_targets[a]).x < Vector2(_plate_targets[b]).x)

	for i in ordered.size():
		for j in range(i + 1, ordered.size()):
			var a: String = ordered[i]
			var b: String = ordered[j]
			var ra: = Rect2(_plate_targets[a], Vector2(PLATE_W, FighterCard.plate_height(a))).grow(4.0)
			var rb: = Rect2(_plate_targets[b], Vector2(PLATE_W, FighterCard.plate_height(b))).grow(4.0)
			if ra.intersects(rb):
				var p: Vector2 = _plate_targets[b]
				p.x = Vector2(_plate_targets[a]).x + PLATE_W + 10.0
				_plate_targets[b] = p
	for i in range(ordered.size() - 1, -1, -1):
		var a: String = ordered[i]
		_plate_targets[a] = _clamp_plate(_plate_targets[a], FighterCard.plate_height(a))
		for j in i:
			var b: String = ordered[j]
			var ra: = Rect2(_plate_targets[a], Vector2(PLATE_W, FighterCard.plate_height(a))).grow(4.0)
			var rb: = Rect2(_plate_targets[b], Vector2(PLATE_W, FighterCard.plate_height(b))).grow(4.0)
			if ra.intersects(rb):
				var p: Vector2 = _plate_targets[b]
				p.x = Vector2(_plate_targets[a]).x - PLATE_W - 10.0
				_plate_targets[b] = p



func _advance_plate(c: Control, target: Vector2, delta: float) -> void :
	if not c.moving:
		c.position = target
		return
	var d: Vector2 = target - c.position
	var dist: = d.length()
	var step: float = float(c.move_speed) * delta
	if dist <= step or dist < 0.001:
		c.position = target
		c.moving = false
	else:
		c.position += d / dist * step



func _keep_clear(pos: Vector2, h: float) -> Vector2:
	var r: = Rect2(pos, Vector2(PLATE_W, h))
	var blocks: Array = [Rect2(_player_panel.position, _player_panel.size)]
	if _foe_panel.visible:
		blocks.append(Rect2(_foe_panel.position, _foe_panel.size))
	blocks.append(log_rect())
	for b: Rect2 in blocks:
		if r.intersects(b.grow(3.0)):
			r.position.y = b.end.y + 4.0
			r.position.x = clampf(r.position.x, PLATE_CLAMP, maxf(PLATE_CLAMP, size.x - PLATE_W - PLATE_CLAMP))
	return r.position



func plate_target(which: String) -> Rect2:
	if not _plate_targets.has(which):
		return Rect2()
	var h: float = FighterCard.plate_height(which)
	return Rect2(_plate_targets[which], Vector2(PLATE_W, h))



func pip_state(i: int) -> String:
	return _player_panel.slot_state(i)


func _on_move_used(user: Node, mv: Dictionary) -> void :
	if user != Battle.partner:
		return
	var snapped: = false
	var id: = String(mv.get("id", ""))
	for b in _moves:
		if b.move_id() == id:
			b.flash = 1.0
			b.press_snap( not snapped)
			snapped = true


func _on_item_used(slot: int) -> void :
	if slot >= 0 and slot < _moves.size():
		_moves[slot].flash = 1.0





class TrainerPanel extends Control:
	const UI: = preload("res://scripts/ui/ui_draw.gd")
	var foe: = false
	var drawn_name: = ""

	static func player_name() -> String:
		return String(Game.state.player_name).to_upper()

	static func foe_name() -> String:
		return String(Battle.trainer_battle.get("name", "")).to_upper()

	func refresh() -> void :
		queue_redraw()


	func slot_state(i: int) -> String:
		if i < 0 or i >= Game.party.size():
			return "empty"
		if Game.party[i].egg:
			return "locked"
		if float(Game.party[i].hp) <= 0.0:
			return "fainted"
		if Battle.in_battle and Game.is_out(i):
			var c = Game.companions[i]
			if c == Battle.partner or c == Battle.ai_ally():
				return "active"
		if Battle.in_battle and not Battle.roster_ok(Game.party[i]):
			return "locked"
		return "available"


	static func foe_states(tb: Dictionary) -> Array:
		if tb.is_empty():
			return []
		var total: int = clampi(int(tb.get("total", 1)), 0, 6)
		var fainted: int = clampi(int(tb.get("fainted", 0)), 0, total)
		var out: Array = []
		for i in SLOT_COUNT:
			if i >= total:
				out.append("empty")
			elif i < fainted:
				out.append("fainted")
			elif i == fainted:
				out.append("active")
			else:
				out.append("available")
		return out

	func states() -> Array:
		if not foe:
			var out: Array = []
			for i in SLOT_COUNT:
				out.append(slot_state(i))
			return out
		return foe_states(Battle.trainer_battle)

	func _draw() -> void :
		var r: = Rect2(Vector2.ZERO, size)
		UI.rounded(self, Rect2(r.position + Vector2(0, 3), r.size), Color(0, 0, 0, 0.4), 7)
		UI.rounded(self, r, Color(UiKit.SLATE_900, 0.9), 7, 2.0, UiKit.SLATE_700)
		var bar: = Rect2(size.x - 6.0, 8.0, 6.0, size.y - 16.0) if foe else Rect2(0, 8.0, 6.0, size.y - 16.0)
		UI.rounded(self, bar, UiKit.accent_border() if not foe else FOE_BLUE, 3)
		var nm: = foe_name() if foe else player_name()
		drawn_name = nm
		var tx: = PANEL_PAD
		var tw: = size.x - PANEL_PAD * 2.0
		UI.text(self, Vector2(tx, 26.0), nm, 20, UI.COL_WHITE, 4, 
			HORIZONTAL_ALIGNMENT_RIGHT if foe else HORIZONTAL_ALIGNMENT_LEFT, tw, UiKit.title_font())
		var cap: = int(Battle.trainer_battle.get("roster", 0))
		if cap > 0 and not foe:
			var used: int = (Battle.trainer_battle.get("used", []) as Array).size()
			UI.text(self, Vector2(tx, 26.0), "MAX %d  %d/%d" % [cap, used, cap], 14, UiKit.AMBER, 4, 
				HORIZONTAL_ALIGNMENT_RIGHT, tw, UiKit.title_font())
		var row_w: = SLOT_COUNT * SLOT_S + (SLOT_COUNT - 1) * SLOT_GAP
		var sx: = size.x - PANEL_PAD - row_w if foe else PANEL_PAD
		var sy: = 38.0
		var sts: = states()
		for i in SLOT_COUNT:
			_slot(Vector2(sx + i * (SLOT_S + SLOT_GAP), sy), String(sts[i]) if i < sts.size() else "empty")

	func _slot(p: Vector2, st: String) -> void :
		var r: = Rect2(p, Vector2(SLOT_S, SLOT_S))
		if st == "empty":
			_dashed(r, Color(1, 1, 1, 0.3))
			return
		UI.rounded(self, r, Color(UiKit.SLATE_800, 0.95), 5, 2.0, UiKit.SLATE_700)
		UI.rounded(self, Rect2(p + Vector2(1, 1), Vector2(SLOT_S - 2, (SLOT_S - 2) * 0.5)), 
			Color(UiKit.SLATE_700, 0.55), 4)
		var c: = r.get_center()
		var dim: = st == "fainted" or st == "locked"
		var ball: = Color(0.78, 0.8, 0.85, 0.45 if st == "locked" else 1.0) if dim else Color.WHITE
		var top: = Color(0.62, 0.64, 0.68, 0.45 if st == "locked" else 1.0) if dim else UiKit.RED
		draw_circle(c, 6.0, ball)
		var pts: = PackedVector2Array()
		for i in 17:
			var a: = PI + PI * i / 16.0
			pts.append(c + Vector2(cos(a), sin(a)) * 6.0)
		draw_colored_polygon(pts, top)
		draw_line(c - Vector2(6, 0), c + Vector2(6, 0), Color(0.06, 0.09, 0.16), 1.6)
		draw_circle(c, 1.8, Color(0.06, 0.09, 0.16))
		if st == "active":
			UI.rounded(self, r.grow(2.0), Color.TRANSPARENT, 7, 2.0, Color(UiKit.AMBER, 0.95))
			draw_arc(c, 15.0, 0.0, TAU, 32, Color(UiKit.AMBER, 0.22), 5.0, true)
		elif st == "fainted":
			draw_line(c + Vector2(-4, -4), c + Vector2(4, 4), Color(1, 1, 1, 0.5), 1.5)
		elif st == "locked":
			draw_line(c + Vector2(-5, 0), c + Vector2(5, 0), Color(UiKit.AMBER, 0.8), 2.0)

	func _dashed(r: Rect2, col: Color) -> void :
		var d: = 4.0
		for edge: Array in [[r.position + Vector2(3, 1), Vector2(r.end.x - 3, r.position.y + 1)], 
				[Vector2(r.end.x - 1, r.position.y + 3), r.end - Vector2(1, 3)], 
				[r.end - Vector2(3, 1), Vector2(r.position.x + 3, r.end.y - 1)], 
				[Vector2(r.position.x + 1, r.end.y - 3), r.position + Vector2(1, 3)]]:
			draw_dashed_line(edge[0], edge[1], col, 2.0, d, d)




class PortraitChip extends Control:
	const UI: = preload("res://scripts/ui/ui_draw.gd")
	var foe: = false
	var path: = "":
		set(v):
			if v != path:
				path = v
				_tex = load(v) if v != "" else null
				queue_redraw()
	var _tex: Texture2D

	func _init() -> void :
		mouse_filter = Control.MOUSE_FILTER_IGNORE
		texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS

	func _draw() -> void :
		var r: = Rect2(Vector2.ZERO, size)
		UI.rounded(self, Rect2(r.position + Vector2(0, 3), r.size), Color(0, 0, 0, 0.4), 7)
		UI.rounded(self, r, Color(UiKit.SLATE_900, 0.9), 7, 2.0, UiKit.SLATE_700)
		if _tex != null:

			var w: = float(_tex.get_width())
			draw_texture_rect_region(_tex, r.grow(-3.0), Rect2(0, 0, w, w))
		UI.rounded(self, r, Color.TRANSPARENT, 7, 2.0, UiKit.SLATE_700)




class FighterCard extends Control:
	const UI: = preload("res://scripts/ui/ui_draw.gd")
	const PokemonSprites: = preload("res://scripts/pokemon_sprites.gd")
	const Dex: = preload("res://scripts/dex.gd")
	const Growth: = preload("res://scripts/stats/growth.gd")
	const Herd: = preload("res://scripts/world/herd.gd")

	var role: = "you"
	var foe: = false
	var body: Node
	var _species: = ""
	var _hp_ratio: = 1.0
	var _ghost: = 1.0
	var _ghost_hold: = 0.0
	var _chips: = Rect2()
	var drawn_name: = ""
	var tag_rect: = Rect2()
	var hp_bar_rect: = Rect2()
	var pp_bar_rect: = Rect2()
	var exp_bar_rect: = Rect2()
	var _exp_shown: = 0.0
	var _exp_mon: RefCounted
	var _exp_level: = 1
	var _exp_scripted: = false
	var _level_hold: = false
	var _level_flash: = 0.0
	var last_anchor: = Vector2.INF
	var moving: = false
	var move_speed: = PLATE_SPEED

	const HP_ROW_Y: = 26.0
	const HP_ROW_H: = 4.0
	const PP_ROW_Y: = 35.0
	const PP_ROW_H: = 2.0
	const EXP_ROW_Y: = 43.0
	const EXP_ROW_H: = 3.0
	const EXP_GAP: = 3.0
	const INNER: = 3.0
	const HP_WIDTH: = 84.0
	const PP_WIDTH: = HP_WIDTH

	func _ready() -> void :
		mouse_filter = Control.MOUSE_FILTER_IGNORE
		texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
		size = Vector2(PLATE_W, plate_height(role))

	static func plate_height(r: String) -> float:
		return PLATE_H_FOE if r == "foe" else PLATE_H


	static func foe_tag(trainer_battle: Dictionary) -> String:
		if trainer_battle.is_empty():
			return "WILD"
		return str(trainer_battle.get("name", "TRAINER")).to_upper() + "'S"


	static func ball_states(trainer_battle: Dictionary) -> Array:
		if trainer_battle.is_empty():
			return []
		var total: int = mini(int(trainer_battle.get("total", 1)), 6)
		var fainted: int = clampi(int(trainer_battle.get("fainted", 0)), 0, total)
		var out: Array = []
		for i in total:
			out.append(i >= fainted)
		return out


	static func clamp_center(c: Vector2, vp: Vector2, h: = PLATE_H) -> Vector2:
		return Vector2(clampf(c.x, PLATE_CLAMP + PLATE_W * 0.5, maxf(PLATE_CLAMP + PLATE_W * 0.5, vp.x - PLATE_CLAMP - PLATE_W * 0.5)), 
			clampf(c.y, PLATE_CLAMP + h * 0.5, maxf(PLATE_CLAMP + h * 0.5, vp.y - PLATE_CLAMP - h * 0.5)))

	func exp_visible() -> bool:
		return not foe and _exp_scripted and Battle._ending

	func _exp_ratio() -> float:
		if not is_instance_valid(body) or body.mon == null:
			return 0.0
		if _level_hold or _exp_level >= Growth.MAX_LEVEL:
			return 1.0
		var growth: = String(body.mon.growth)
		var lo: = float(Growth.exp_for_level(growth, _exp_level))
		var hi: = float(Growth.exp_for_level(growth, _exp_level + 1))
		return clampf((_exp_shown - lo) / maxf(hi - lo, 1.0), 0.0, 1.0)

	func exp_animating() -> bool:
		return is_instance_valid(body) and body.mon != null and _exp_shown < float(body.mon.xp)

	func _say(text: String, col: Color) -> void :
		var p: = get_parent()
		if p and p.has_method("popup"):
			p.popup(text, col)

	func begin_scripted(m: RefCounted, gain: int) -> void :
		_exp_scripted = true
		if _exp_mon != m or _exp_shown > float(m.xp):
			_exp_shown = float(m.xp) - float(gain)
		_exp_mon = m
		_exp_level = ExpBarMath.level_at(String(m.growth), int(_exp_shown))
		_level_hold = false
		_level_flash = 0.0

	func fill_to(target: float, skip_on_press: = true) -> void :
		if not is_instance_valid(body) or body.mon == null:
			return
		var growth: = String(body.mon.growth)
		while _exp_shown < target:
			if skip_on_press and Input.is_action_just_pressed("pk_ok"):
				break
			var step: = ExpBarMath.rate(growth, int(_exp_shown))
			if step <= 0.0:
				break
			_exp_shown = minf(_exp_shown + step * get_process_delta_time(), target)
			await get_tree().process_frame
		_exp_shown = target

	func announce_level(lv: int) -> void :
		_exp_level = lv
		_level_hold = true
		_level_flash = 1.0

	func resume_after_level() -> void :
		_level_hold = false

	func end_scripted() -> void :
		_exp_scripted = false

	func _on_level_up(m: RefCounted, lv: int) -> void :
		_say("%s: Level Up!" % String(m.display_name), UiKit.AMBER)
		Audio.jingle("music/level_up", true)

	func chips_rect() -> Rect2:
		return _chips

	func _process(delta: float) -> void :
		if not is_instance_valid(body):
			return
		if body.species != _species:
			_species = body.species
			_hp_ratio = float(body.hp) / maxf(body.max_hp, 1)
			_ghost = _hp_ratio
		var r: = float(body.hp) / maxf(body.max_hp, 1)
		if foe and Battle.safari != null:
			r = Battle.safari.closeness_ratio()
		if r < _hp_ratio:
			_ghost_hold = 0.45
		_hp_ratio = r
		if _ghost < _hp_ratio:
			_ghost = _hp_ratio
		elif _ghost_hold > 0.0:
			_ghost_hold -= delta
		else:
			_ghost = move_toward(_ghost, _hp_ratio, delta * 0.8)
		var m: RefCounted = body.mon if body.mon else null
		if _exp_scripted or Battle._ending:
			pass
		elif m != _exp_mon:
			_exp_mon = m
			_exp_shown = float(m.xp) if m else 0.0
			_exp_level = int(m.level) if m else 1
		elif m:

			_exp_shown = float(m.xp)
			_exp_level = int(m.level)
		_level_flash = maxf(_level_flash - delta * 1.5, 0.0)

	func _draw() -> void :
		if not is_instance_valid(body):
			return
		var nm: String = body.mon.display_name if body.mon and "display_name" in body.mon else String(body.species)
		drawn_name = nm.to_upper()
		var lv: = "· Lv. %d" % (_exp_level if _exp_mon == body.mon else int(body.level))
		var lv_w: = UI.text_width(lv, 12, UiKit.header_font())
		var name_col: Color = UiKit.WHITE if _level_flash <= 0.0 else Color(1, 0.95, 0.6)
		var name_width: = size.x - INNER * 2.0 - lv_w - 5.0
		var font_size: = 14
		while font_size > 10 and UI.text_width(drawn_name, font_size, UiKit.header_font()) > name_width:
			font_size -= 1
		var name_text: = drawn_name
		if UI.text_width(name_text, font_size, UiKit.header_font()) > name_width:
			while name_text.length() > 1 and UI.text_width(name_text + "…", font_size, UiKit.header_font()) > name_width:
				name_text = name_text.left(-1)
			name_text += "…"
		var name_w: = UI.text_width(name_text, font_size, UiKit.header_font())
		var text_x: = (size.x - name_w - 5.0 - lv_w) * 0.5
		UI.text(self, Vector2(text_x, 17), name_text, font_size, name_col, 2, HORIZONTAL_ALIGNMENT_LEFT, name_width, UiKit.header_font())
		tag_rect = Rect2()
		UI.text(self, Vector2(text_x + name_w + 5, 17), lv, 12, UiKit.WHITE, 2, 
			HORIZONTAL_ALIGNMENT_LEFT, -1.0, UiKit.header_font())
		var inner: = size.x - INNER * 2.0
		hp_bar_rect = Rect2((size.x - HP_WIDTH) * 0.5, HP_ROW_Y, HP_WIDTH, HP_ROW_H)
		UI.bar(self, hp_bar_rect, _hp_ratio, UI.hp_color(_hp_ratio), _ghost, Color(1, 1, 1, 0.75))
		if foe:
			UI.herd_pips(self, Vector2(8.0, HP_ROW_Y + HP_ROW_H * 0.5), Herd.pips(body))
		pp_bar_rect = Rect2()
		exp_bar_rect = Rect2()
		if not foe:

			var base: = maxf(body.pp_base, 1.0)
			pp_bar_rect = Rect2((size.x - PP_WIDTH) * 0.5, PP_ROW_Y, PP_WIDTH, PP_ROW_H)
			UI.bar(self, pp_bar_rect, maxf(body.stamina, 0.0) / base, UiKit.PP_BLUE, body.pp_max / base, Color(0.2, 0.3, 0.55))
			if body.combat.is_flying():
				UI.fly_tick(self, pp_bar_rect, body.combat.fly_pp / base)
			if exp_visible():
				exp_bar_rect = Rect2((size.x - HP_WIDTH) * 0.5, EXP_ROW_Y, HP_WIDTH, EXP_ROW_H)
				UI.bar(self, exp_bar_rect, _exp_ratio(), UiKit.AMBER, -1.0, Color(1, 1, 1, 0.75), false, UI.EXP_TRACK)
				_draw_level_sparkle(exp_bar_rect.end.x, EXP_ROW_Y + EXP_ROW_H * 0.5)

		_draw_chips(inner)

	func _draw_chips(inner: float) -> void :
		if foe and Battle.safari != null:
			var st: String = Battle.safari.state_text()
			UI.text(self, Vector2(2, HP_ROW_Y + HP_ROW_H + 14.0), "NEAR", 9, Color(1, 1, 1, 0.55), 2)
			if st != "":
				UI.text(self, Vector2(34, HP_ROW_Y + HP_ROW_H + 14.0), st, 10, Color(1.0, 0.85, 0.5) if st == "EATING" else Color(1.0, 0.45, 0.4), 2)
			_chips = Rect2()
			return
		var y: = (EXP_ROW_Y + EXP_ROW_H if exp_visible() else (PP_ROW_Y + PP_ROW_H if not foe else HP_ROW_Y + HP_ROW_H)) + 4.0
		var x: = 0.0
		var sw: float = UI.status_pill(self, Vector2(x, y), body.status, 9)
		if sw > 0.0:
			x += sw + 4.0

		if body.combat.wet:
			var ww: float = UI.status_pill(self, Vector2(x, y), "wet", 9)
			if ww > 0.0:
				x += ww + 4.0
		var w: float = UI.mod_chips(self, Vector2(x, y), body, 9, inner + 20.0)
		var total: = x + w - 0.0
		_chips = Rect2(0.0, y, total, 17.0) if total > 0.5 else Rect2()
		if body.stagger_t > 0.0:
			UI.text(self, Vector2(x + 2, y + 13.0), "STAGGERED", 9, Color(1, 0.55, 0.35), 2)
		elif body.evolving:
			UI.text(self, Vector2(x + 2, y + 13.0), "EVOLVING", 9, Color(1, 0.95, 0.6), 2)

	func _draw_level_sparkle(x: float, y: float) -> void :
		if _level_flash <= 0.0:
			return
		var c: = Color(1.0, 0.95, 0.6, _level_flash)
		var grow: = (1.0 - _level_flash) * 14.0
		for k in 6:
			var dir: = Vector2(cos(TAU * k / 6.0), sin(TAU * k / 6.0))
			draw_line(Vector2(x, y) + dir * (2.0 + grow * 0.4), Vector2(x, y) + dir * (5.0 + grow * 0.6), c, 1.5)

	func name_rect() -> Rect2:
		if drawn_name == "":
			return Rect2()
		var w: = minf(UI.text_width(drawn_name, 14, UiKit.header_font()), size.x - INNER * 2.0 - 40.0)
		return Rect2(INNER, 1.0, w, 19.0)






class LoadoutStrip extends Control:
	const UI: = preload("res://scripts/ui/ui_draw.gd")

	const CHIP_H: = 19.0

	var pulse: = 0.0

	func _ready() -> void :
		mouse_filter = Control.MOUSE_FILTER_IGNORE

	func partner():
		var p = Battle.partner
		return p if is_instance_valid(p) and p.mon != null else null


	func other_loadout() -> int:
		var p = partner()
		return 0 if p == null or int(p.mon.active_loadout) == 1 else 1

	func shown() -> bool:
		if Battle.safari != null or not Battle.in_battle:
			return false
		if not TrainerLevel.second_loadout_unlocked(Game.state.trainer_level()):
			return false
		return partner() != null


	func kick() -> void :
		pulse = 1.0
		queue_redraw()

	func _process(delta: float) -> void :
		if pulse > 0.0:
			pulse = maxf(pulse - delta * 4.5, 0.0)
		if shown():
			queue_redraw()

	func _draw() -> void :
		if shown():
			_draw_chip(0 if partner().mon.loadout(other_loadout()).is_empty() else 1)

	func _draw_chip(n: int) -> void :
		var label: = "LOADOUT %d" % (other_loadout() + 1)
		if n == 0:
			label += " · EMPTY"
		var keys: String = Controls.key_label("loadout_prev") + " / " + Controls.key_label("loadout_next")\
		if Controls.key_label("loadout_next") != "" else ""
		var txt: = "⇄  " + label + ("  ·  " + keys if keys != "" else "")
		var w: float = UI.text_width(txt, 9) + 18.0
		var r: = Rect2(0, 0, w, CHIP_H)
		UI.rounded(self, r, Color(0.031, 0.055, 0.078, 0.9), 99.0, 1.0, 
			Color(245 / 255.0, 158 / 255.0, 11 / 255.0, 0.45 + 0.55 * pulse))
		UI.text(self, Vector2(9, 13), txt, 9, Color("ffcf8a"), 2)


class MoveButton extends Control:
	const UI: = preload("res://scripts/ui/ui_draw.gd")
	const Dex: = preload("res://scripts/dex.gd")
	const ItemsData: = preload("res://scripts/items.gd")

	var index: = 0
	var flash: = 0.0
	var showing_item: = false

	var back: = false

	var squash_y: = 1.0


	const PRESS_SECS: = 0.14
	const READY_SECS: = 0.12
	const RING_SECS: = 0.25
	const SWEEP_SECS: = 0.26
	const DIS_GREY: = 0.9
	const DIS_DARKEN: = 0.58

	var _press_t: = -1.0
	var _ready_t: = -1.0
	var _ring_t: = -1.0
	var _sweep_t: = -1.0
	var _cooling: = false


	const TYPE_STYLE: = {
		"fire": {"a": "#dc2f12", "b": "#f59e0b", "pat": "flame", "dark": false}, 
		"grass": {"a": "#15803d", "b": "#4ade80", "pat": "leaf", "dark": false}, 
		"water": {"a": "#1d4ed8", "b": "#38bdf8", "pat": "wave", "dark": false}, 
		"electric": {"a": "#facc15", "b": "#fde68a", "pat": "bolt", "dark": true}, 
		"normal": {"a": "#78716c", "b": "#b8b2ac", "pat": "dot", "dark": false}, 
		"poison": {"a": "#7e22ce", "b": "#c084fc", "pat": "bubble", "dark": false}, 
		"flying": {"a": "#4f46e5", "b": "#a5b4fc", "pat": "feather", "dark": false}, 
		"ground": {"a": "#92400e", "b": "#d6b27a", "pat": "block", "dark": false}, 
		"rock": {"a": "#57534e", "b": "#a8a29e", "pat": "block", "dark": false}, 
		"bug": {"a": "#4d7c0f", "b": "#a3e635", "pat": "hex", "dark": false}, 
		"ghost": {"a": "#4c1d95", "b": "#a78bfa", "pat": "eye", "dark": false}, 
		"psychic": {"a": "#be185d", "b": "#f472b6", "pat": "ring", "dark": false}, 
		"fighting": {"a": "#991b1b", "b": "#ef4444", "pat": "cross", "dark": false}, 
		"dragon": {"a": "#3730a3", "b": "#818cf8", "pat": "diamond", "dark": false}, 
		"steel": {"a": "#475569", "b": "#94a3b8", "pat": "plus", "dark": false}, 
		"dark": {"a": "#1e1b2e", "b": "#4b3b5e", "pat": "void", "dark": false}, 
		"ice": {"a": "#0e7490", "b": "#a5f3fc", "pat": "snow", "dark": false}, 
		"none": {"a": "#334155", "b": "#64748b", "pat": "none", "dark": false}, 
	}

	static func type_style(t: String) -> Dictionary:
		var s: Dictionary = TYPE_STYLE.get(t, TYPE_STYLE["normal"])
		return {"a": Color(String(s.a)), "b": Color(String(s.b)), "pat": String(s.pat), "dark": bool(s.dark)}

	func move_id() -> String:
		if Battle.safari != null:
			return "safari_%d" % index if index < 3 else ""
		var p: Node = Battle.partner
		if back:
			if not is_instance_valid(p) or p.mon == null:
				return ""
			var o: Array = p.mon.loadout(1 - int(p.mon.active_loadout))
			return String(o[index]) if index < o.size() else ""
		if is_instance_valid(p) and index < p.moves.size():
			return String(p.moves[index])
		return ""

	func is_mimic_slot() -> bool:
		var p: Node = Battle.partner
		return not back and Battle.safari == null and is_instance_valid(p) and p.combat.is_mimic_slot(index)

	func mimic_badge_rect() -> Rect2:
		return Rect2(8, 8, 48, 18) if touch() else Rect2(4, size.y - 18, 43, 14)

	func _draw_mimic_badge(alpha: float) -> void :
		if not is_mimic_slot():
			return
		var r: = mimic_badge_rect()
		UI.rounded(self, r, Color(0.21, 0.14, 0.31, 0.96), 3, 1, Color("c4a0eb"))
		UI.text_center(self, Vector2(r.get_center().x, r.position.y + r.size.y - 3), "MIMIC", 10 if touch() else 8, Color(0.93, 0.86, 1.0, alpha), 0)

	func item_id() -> String:
		return String(Game.quick_slots[index]) if index < Game.quick_slots.size() else ""

	static func items_held() -> bool:
		return Controls.items_page_held()

	func _process(delta: float) -> void :
		flash = maxf(flash - delta * 3.0, 0.0)
		showing_item = items_held() and not back
		_press_t = _tick(_press_t, delta, PRESS_SECS)
		_ready_t = _tick(_ready_t, delta, READY_SECS)
		_ring_t = _tick(_ring_t, delta, RING_SECS)
		_sweep_t = _tick(_sweep_t, delta, SWEEP_SECS)

		var cooling: bool = float(cooldown_state()[0]) > 0.0
		if cooling != _cooling:
			if cooling:
				press_snap(false)
			elif Battle.in_battle and (is_instance_valid(Battle.partner) or Battle.safari != null) and move_id() != "":
				ready_pop()
			_cooling = cooling
		pivot_offset = size * 0.5
		var sc: = anim_scale()
		scale = Vector2(sc, sc * squash_y)

	func glyph() -> String:
		return Controls.key_label("move_%d" % (index + 1))

	func _move() -> Dictionary:
		var id: = move_id()
		if Battle.safari != null:
			return Battle.safari.slot(index) if id != "" else {}
		return Dex.move(id) if id != "" else {}

	func category() -> String:
		return String(_move().get("category", "status")) if move_id() != "" else ""

	func pp_cost() -> int:
		return int(round(Dex.pp_cost(_move()))) if move_id() != "" else 0

	func pp_text() -> String:
		var p: Node = Battle.partner
		if is_instance_valid(p) and int(p.pp_max) <= 0:
			return "0 PP"
		return "−%d PP" % pp_cost()

	func touch() -> bool:
		return Controls.is_touch()

	func _touch_held() -> bool:
		if not touch():
			return false
		var h: = get_parent()
		return h != null and h.has_method("touch_held") and bool(h.touch_held("move_%d" % (index + 1)))


	func alphas(fill_base: = 0.88, ring_base: = 0.95, label_base: = 1.0) -> Vector3:
		if not touch():
			return Vector3(fill_base, ring_base, label_base)
		var p: = _touch_held()
		return Vector3(TOUCH_A_PRESSED if p else TOUCH_A, 1.0 if p else 0.86, 1.0 if p else 0.95)


	func _name_fs() -> int:
		if not touch():
			return 14
		var nm: = _name()
		var maxw: = size.x - 16.0
		var fs: = 21
		while fs > 14 and nm != "" and UI.text_width(nm, fs, UiKit.title_font()) > maxw:
			fs -= 1
		return fs

	func _fit_name(nm: String) -> String:
		var fs: = _name_fs()
		var maxw: = size.x - (16.0 if touch() else 56.0)
		if UI.text_width(nm, fs, UiKit.title_font()) <= maxw:
			return nm
		var s: = nm
		while s.length() > 1 and UI.text_width(s + "…", fs, UiKit.title_font()) > maxw:
			s = s.substr(0, s.length() - 1)
		return s + "…"

	func text_fits() -> bool:
		return true



	func name_rect() -> Rect2:
		var nm: = _name()
		if nm == "":
			return Rect2()
		var cooling: bool = float(cooldown_state()[0]) > 0.0
		var fs: = (14 if touch() else 10) if cooling else _name_fs()
		var s: = _fit_name(nm)
		var w: = UI.text_width(s, fs, UiKit.title_font())
		if touch():
			var y: = 36.0 - fs if cooling else size.y * 0.5 - 18.0
			return Rect2(size.x * 0.5 - w * 0.5, y, w, fs)
		return Rect2(28.0, (2.0 if cooling else 4.0), w, float(fs))

	func pp_center() -> Vector2:
		if touch():
			return Vector2(size.x * 0.5, size.y - 14.0)
		return Vector2(size.x - 29.0 if is_mimic_slot() else 45.0, size.y - 6.0)

	func _name() -> String:
		var id: = move_id()
		if Battle.safari != null:
			return String(Battle.safari.slot(index).get("name", "")) if id != "" else ""
		if id in GRAB_IDS and _holding():
			return _moves().grip_action_name(Battle.partner)
		return String(Dex.move(id).get("name", id)) if id != "" else ""


	const GRAB_IDS: = ["bind", "wrap", "clamp"]
	func _moves() -> Node:
		return get_node("/root/Moves")

	func _holding() -> bool:
		return Battle.safari == null and is_instance_valid(Battle.partner) and _moves().grip_of(Battle.partner) != null


	func _hold_locked() -> bool:
		var id: = move_id()
		return id != "" and id not in GRAB_IDS and _holding()\
		and not _moves().usable_while_holding(Battle.partner, Dex.move_for(id, Battle.partner.species))


	static func _tick(t: float, delta: float, secs: float) -> float:
		if t < 0.0:
			return -1.0
		t += delta
		return -1.0 if t >= secs else t

	func cooldown_state() -> Array:
		if Battle.safari != null:
			return Battle.safari.cooldown_state(index)
		var p: Node = Battle.partner
		var id: = move_id()
		if not is_instance_valid(p) or id == "":
			return [0.0, -1.0]
		if id in GRAB_IDS and _holding():
			return [0.0, -1.0]
		var cd: = float(p.move_cd.get(id, 0.0))
		var use_gcd: = float(p.gcd_t) > cd
		if use_gcd:
			cd = float(p.gcd_t)
		if cd <= 0.0:
			return [0.0, -1.0]
		var total: float = (p.combat.gcd_duration if use_gcd else Dex.cooldown(Dex.move(id))) / maxf(p.recovery_factor(), 0.01)
		return [cd, clampf(cd / maxf(total, 0.01), 0.0, 1.0)]


	func progress() -> float:
		var st: = cooldown_state()
		if float(st[0]) <= 0.0:
			return 1.0
		return clampf(1.0 - float(st[1]), 0.0, 1.0)


	func progress_rect() -> Rect2:
		var st: = cooldown_state()
		if float(st[0]) <= 0.0:
			return Rect2()
		return Rect2(0.0, 0.0, size.x * progress(), size.y)


	func anim_scale() -> float:
		var s: = 1.0
		if _press_t >= 0.0:
			var t: = clampf(_press_t / PRESS_SECS, 0.0, 1.0)
			if t < 0.35:
				s *= 1.0 - 0.12 * _ease_out(t / 0.35)
			else:
				s *= 0.88 + 0.12 * _ease_out((t - 0.35) / 0.65)
		if _ready_t >= 0.0:
			var r: = clampf(_ready_t / READY_SECS, 0.0, 1.0)
			if r < 0.4:
				s *= 1.0 + 0.12 * _ease_out(r / 0.4)
			else:
				s *= 1.12 - 0.12 * _ease_out((r - 0.4) / 0.6)
		return s

	static func _ease_out(x: float) -> float:
		x = clampf(x, 0.0, 1.0)
		return 1.0 - (1.0 - x) * (1.0 - x)


	func _disabled() -> float:
		if _press_t >= 0.0:
			return _ease_out(clampf(_press_t / PRESS_SECS, 0.0, 1.0))
		return 1.0 if _cooling or _hold_locked() else 0.0

	func press_snap(with_sfx: = true) -> void :
		_press_t = 0.0
		_ready_t = -1.0
		_ring_t = -1.0
		_sweep_t = -1.0
		_cooling = true
		if with_sfx:
			var cues: = _cues()
			if cues != null:
				cues.move_press()

	func ready_pop() -> void :
		_press_t = -1.0
		_ready_t = 0.0
		_ring_t = 0.0
		_sweep_t = 0.0
		_cooling = false
		var cues: = _cues()
		if cues != null:
			cues.move_ready()

	func _cues() -> Node:
		if back:
			return null
		var a: = get_node_or_null("/root/Audio")
		return a.get_node_or_null("AudioCues") if a != null else null

	func _cooldown_layout() -> Dictionary:
		var st: = cooldown_state()
		if float(st[0]) <= 0.0:
			return {}
		return {"text": "%.1f" % float(st[0]), "x": size.x * (0.75 if is_mimic_slot() and not touch() else 0.5), 
			"y": size.y * 0.5 + 18.0 if touch() else 32.0, 
			"fs": 20 if touch() else 14}

	func cooldown_rect() -> Rect2:
		var e: = _cooldown_layout()
		if e.is_empty():
			return Rect2()
		var w: = UI.text_width(String(e.text), int(e.fs))
		return Rect2(float(e.x) - w * 0.5, float(e.y) - int(e.fs), w, float(e.fs))

	func _draw() -> void :
		var r: = Rect2(Vector2.ZERO, size)
		var rad: = 10.0 if touch() else 7.0
		var a: = alphas()
		UI.rounded(self, Rect2(r.position + Vector2(0, 3), r.size), Color(0, 0, 0, 0.45), rad)
		if showing_item:
			_draw_item(r, rad, a)
			return
		var id: = move_id()
		if id == "":
			UI.rounded(self, r, Color(0.08, 0.1, 0.14, 0.7), rad, 2.0, Color(UiKit.SLATE_700, 0.8))
			UI.text_center(self, Vector2(size.x * 0.5, size.y * 0.5 + 6.0), "—", 16, Color(1, 1, 1, 0.3), 0)
			return
		if Battle.safari != null:
			_draw_safari(r, rad, a)
			return
		var mv: = _move()
		var ty: = String(mv.get("type", "normal"))
		var tcol: = Dex.type_color(ty)
		var style: = type_style(ty)
		var p: Node = Battle.partner
		var afford: bool = p.pp_max >= pp_cost()
		var tired: bool = p.stamina < Dex.fatigue(mv)
		var selected: bool = p.selected_move == id and not back
		if touch() and _ready_t >= 0.0:
			a = Vector3.ONE
		var cst: = cooldown_state()
		var cooling: bool = float(cst[0]) > 0.0
		var g0: Color = style.a
		var g1: Color = style.b
		if not afford:
			g0 = Color(0.14, 0.15, 0.18)
			g1 = Color(0.23, 0.24, 0.28)

		var dis: = _disabled()
		var body0: = g0.lerp(_disabled_col(g0), dis)
		var body1: = g1.lerp(_disabled_col(g1), dis)

		if _sweep_t >= 0.0:
			var boost: = lerpf(1.8, 1.0, clampf(_sweep_t / SWEEP_SECS, 0.0, 1.0))
			body0 = _mul(body0, boost)
			body1 = _mul(body1, boost)

		UI.rounded(self, r, Color(body0, a.x), rad)
		var pts: = PackedVector2Array([r.position + Vector2(2, 2), Vector2(r.end.x - 2, r.position.y + 2), 
			r.end - Vector2(2, 2), Vector2(r.position.x + 2, r.end.y - 2)])
		draw_polygon(pts, PackedColorArray([Color(body0, a.x), Color(body0.lightened(0.08), a.x), 
			Color(body1, a.x), Color(body1, a.x)]))

		if cooling and afford:
			_draw_progress(progress(), g0, g1, rad, a.x)
		if afford:
			_draw_pattern(style.pat, r, style.dark)
		if p.combat.prepare_id == id and float(p.combat.prepare_t) > 0.0:
			var pf: = 1.0 - clampf(float(p.combat.prepare_t) / maxf(Dex.prepare_time(mv), 0.01), 0.0, 1.0)
			UI.rounded(self, r, Color(1, 1, 1, 0.18 * pf), rad)

		if not touch() and not back:
			_key_chip(Vector2(3, 3), glyph(), a.z * (0.45 if cooling else 1.0))

		_cat_chip(Vector2(0.0, size.y - (28.0 if touch() else 18.0) - 4.0), category(), a.z)

		var nm: = _fit_name(_name())
		var name_col: = Color(0.13, 0.17, 0.24, a.z) if style.dark else Color(1, 1, 1, a.z)
		if cooling:
			name_col = Color(0.95, 0.97, 1.0, a.z)
		if touch():
			var ny: = 36.0 if cooling else size.y * 0.5 + 8.0
			UI.text_center(self, Vector2(size.x * 0.5, ny), nm, 14 if cooling else 21, name_col, 3 if style.dark else 4)
		else:
			UI.text(self, Vector2(28, 12 if cooling else 18), nm, 10 if cooling else 14, name_col, 3 if style.dark else 4)

		_pp_chip(a.z, afford, tired)
		if float(cst[0]) > 0.0:
			var cl: = _cooldown_layout()
			UI.text_center(self, Vector2(cl.x, cl.y), String(cl.text), int(cl.fs), Color(1, 1, 1, a.z), 4)
		if flash > 0.0:
			UI.rounded(self, r, Color(1, 1, 1, flash * 0.45), rad)
		_draw_mimic_badge(a.z)

		if not afford:
			UI.rounded(self, r, Color.TRANSPARENT, rad, 2.0, Color(0.4, 0.42, 0.46, 0.7))
		if selected:
			UI.rounded(self, r.grow(-1.0), Color.TRANSPARENT, rad, 3.0, Color(1, 1, 1, 0.95))
			UI.rounded(self, r.grow(2.0), Color.TRANSPARENT, rad + 2.0, 2.0, UiKit.accent_border())
		else:
			UI.rounded(self, r, Color.TRANSPARENT, rad, 2.0, Color(0.06, 0.09, 0.16, 0.85))

		if _sweep_t >= 0.0:
			_draw_sweep()
		if _ring_t >= 0.0:
			_draw_ready_ring(rad)



	func _draw_safari(r: Rect2, rad: float, a: Vector3) -> void :
		var mv: = _move()
		var style: = type_style(String(mv.get("type", "normal")))
		var cst: = cooldown_state()
		var cooling: bool = float(cst[0]) > 0.0
		var g0: Color = style.a
		var g1: Color = style.b
		var empty: bool = bool(mv.get("empty", false))
		if empty:
			g0 = Color(0.14, 0.15, 0.18)
			g1 = Color(0.23, 0.24, 0.28)
		var dis: = _disabled()
		var body0: = g0.lerp(_disabled_col(g0), dis)
		var body1: = g1.lerp(_disabled_col(g1), dis)
		if _sweep_t >= 0.0:
			var boost: = lerpf(1.8, 1.0, clampf(_sweep_t / SWEEP_SECS, 0.0, 1.0))
			body0 = _mul(body0, boost)
			body1 = _mul(body1, boost)
		UI.rounded(self, r, Color(body0, a.x), rad)
		var pts: = PackedVector2Array([r.position + Vector2(2, 2), Vector2(r.end.x - 2, r.position.y + 2), 
			r.end - Vector2(2, 2), Vector2(r.position.x + 2, r.end.y - 2)])
		draw_polygon(pts, PackedColorArray([Color(body0, a.x), Color(body0.lightened(0.08), a.x), Color(body1, a.x), Color(body1, a.x)]))
		if cooling and not empty:
			_draw_progress(progress(), g0, g1, rad, a.x)
		if not empty:
			_draw_pattern(style.pat, r, style.dark)
		if not touch():
			_key_chip(Vector2(3, 3), glyph(), a.z * (0.45 if cooling else 1.0))
		var nm: = _fit_name(_name())
		var name_col: = Color(0.13, 0.17, 0.24, a.z) if style.dark else Color(1, 1, 1, a.z)
		if cooling:
			name_col = Color(0.95, 0.97, 1.0, a.z)
		if touch():
			UI.text_center(self, Vector2(size.x * 0.5, 36.0 if cooling else size.y * 0.5 + 8.0), nm, 14 if cooling else 21, name_col, 3 if style.dark else 4)
		else:
			UI.text(self, Vector2(28, 12 if cooling else 18), nm, 10 if cooling else 14, name_col, 3 if style.dark else 4)
		var chip: = String(mv.get("chip", ""))
		if chip != "":
			UI.text(self, Vector2(size.x - 8.0 - UI.text_width(chip, 10, UiKit.header_font()), size.y - 6.0), chip, 10, Color(1, 1, 1, a.z), 3, HORIZONTAL_ALIGNMENT_LEFT, -1.0, UiKit.header_font())
		if float(cst[0]) > 0.0:
			var cl: = _cooldown_layout()
			UI.text_center(self, Vector2(cl.x, cl.y), String(cl.text), int(cl.fs), Color(1, 1, 1, a.z), 4)
		if flash > 0.0:
			UI.rounded(self, r, Color(1, 1, 1, flash * 0.45), rad)
		UI.rounded(self, r, Color.TRANSPARENT, rad, 2.0, Color(0.06, 0.09, 0.16, 0.85))
		if _sweep_t >= 0.0:
			_draw_sweep()
		if _ring_t >= 0.0:
			_draw_ready_ring(rad)


	static func _disabled_col(c: Color) -> Color:
		var lum: = c.get_luminance()
		return c.lerp(Color(lum, lum, lum, c.a), DIS_GREY).darkened(DIS_DARKEN)

	static func _mul(c: Color, k: float) -> Color:
		return Color(clampf(c.r * k, 0.0, 1.0), clampf(c.g * k, 0.0, 1.0), clampf(c.b * k, 0.0, 1.0), c.a)


	func _draw_progress(pr: float, g0: Color, g1: Color, rad: float, alpha: float) -> void :
		var w: = clampf(size.x * pr, 0.0, size.x)
		if w <= 0.0:
			return
		var h: = size.y

		rad = minf(rad, minf(w, h) * 0.5)
		var top: = Color(g0.lightened(0.16), alpha)
		var bot: = Color(g1.lightened(0.12), alpha)
		var full: = w >= size.x - 0.5
		var pts: = PackedVector2Array()
		var cols: = PackedColorArray()
		for i in 7:
			var ang: = PI + PI * 0.5 * i / 6.0
			pts.append(Vector2(rad + cos(ang) * rad, rad + sin(ang) * rad))
			cols.append(top)
		if full:
			for i in 7:
				var ang: = 1.5 * PI + PI * 0.5 * i / 6.0
				pts.append(Vector2(w - rad + cos(ang) * rad, rad + sin(ang) * rad))
				cols.append(top)
		else:
			pts.append(Vector2(w, 0.0))
			cols.append(top)
			pts.append(Vector2(w, h))
			cols.append(bot)
		if full:
			for i in 7:
				var ang: = PI * 0.5 * i / 6.0
				pts.append(Vector2(w - rad + cos(ang) * rad, h - rad + sin(ang) * rad))
				cols.append(bot)
		for i in 7:
			var ang: = PI * 0.5 + PI * 0.5 * i / 6.0
			pts.append(Vector2(rad + cos(ang) * rad, h - rad + sin(ang) * rad))
			cols.append(bot)
		draw_polygon(pts, cols)
		if not full:
			draw_line(Vector2(w, 3.0), Vector2(w, h - 3.0), Color(1, 1, 1, 0.55 * alpha), 2.0)


	func _draw_sweep() -> void :
		var t: = clampf(_sweep_t / SWEEP_SECS, 0.0, 1.0)
		var bx: = lerpf(-60.0, size.x + 20.0, _ease_out(t))
		var bw: = 60.0
		var skew: = tan(deg_to_rad(18.0)) * size.y
		var xs: = [bx, bx + bw * 0.5, bx + bw]
		var pts: = PackedVector2Array()
		var cols: = PackedColorArray()
		for x in xs:
			pts.append(Vector2(clampf(float(x), 0.0, size.x), 0.0))
			cols.append(Color(1, 1, 1, 0.0 if x != xs[1] else 0.92))
		for k in [2, 1, 0]:
			pts.append(Vector2(clampf(float(xs[k]) + skew, 0.0, size.x), size.y))
			cols.append(Color(1, 1, 1, 0.0 if k != 1 else 0.92))
		draw_polygon(pts, cols)


	func _draw_ready_ring(rad: float) -> void :
		var t: = clampf(_ring_t / RING_SECS, 0.0, 1.0)
		var e: = _ease_out(t)
		var ex: = size.x * 0.35 * e
		var ey: = size.y * 0.6 * e
		var rr: = Rect2( - ex, - ey, size.x + ex * 2.0, size.y + ey * 2.0)
		UI.rounded(self, rr, Color.TRANSPARENT, rad + ey, 3.0, Color(UiKit.accent_border(), 1.0 - e))

	func _key_chip(p: Vector2, label: String, alpha: float) -> void :
		if label == "":
			return
		var fs: = 11
		var w: = maxf(15.0, UI.text_width(label, fs) + 6.0)
		UI.rounded(self, Rect2(p, Vector2(w, 15)), Color(UiKit.SLATE_800, alpha), 5, 2.0, Color(UiKit.accent_border(), alpha))
		UI.text(self, p + Vector2(3.0, 11.0), label, fs, Color(UiKit.accent_border(), alpha), 0)

	func _cat_chip(p: Vector2, cat: String, alpha: float) -> void :
		var lbl: = {"physical": "PHYS", "special": "SPEC"}.get(cat, "STAT") as String
		var fs: = 9 if touch() else 7
		var h: = 28.0 if touch() else 18.0
		var w: = UI.text_width(lbl, fs, UiKit.pixel_font()) + h * 0.5 + 12.0
		var x: = size.x - w - 3.0
		UI.rounded(self, Rect2(Vector2(x, p.y), Vector2(w, h)), Color(UiKit.SLATE_900, 0.8 * alpha), 5)
		_cat_icon(cat, Vector2(x + 4.0 + h * 0.25, p.y + h * 0.5), h * 0.2, alpha)
		var tc: = {"physical": Color(1.0, 0.65, 0.3), "special": Color(0.55, 0.7, 1.0)}.get(cat, Color(0.8, 0.82, 0.88)) as Color
		UI.text(self, Vector2(x + 8.0 + h * 0.5, p.y + h * 0.5 + fs * 0.5 - 1.0), lbl, fs, Color(tc, alpha), 0, HORIZONTAL_ALIGNMENT_LEFT, -1.0, UiKit.pixel_font())

	func _cat_icon(cat: String, c: Vector2, r: float, alpha: float) -> void :
		var col: = Color(1, 1, 1, alpha)
		match cat:
			"physical":
				var pts: = PackedVector2Array()
				for i in 16:
					var ang: = TAU * i / 16.0 - PI * 0.5
					pts.append(c + Vector2(cos(ang), sin(ang)) * (r if i % 2 == 0 else r * 0.48))
				draw_colored_polygon(pts, col)
			"special":
				draw_arc(c, r, 0, TAU, 20, col, 1.8, true)
				draw_circle(c, r * 0.32, col)
			_:
				for i in 3:
					draw_line(c + Vector2( - r, - r * 0.55 + i * r * 0.55), c + Vector2(r, - r * 0.55 + i * r * 0.55), col, 1.8)

	func _pp_chip(alpha: float, afford: bool, tired: bool) -> void :
		var s: = pp_text()
		var fs: = 9 if touch() else 7
		var w: = UI.text_width(s, fs, UiKit.pixel_font()) + 10.0
		var h: = fs + 8.0
		var x: = size.x * 0.5 - w * 0.5 if touch() else 28.0
		if is_mimic_slot() and not touch():
			x = size.x - w - 4.0
		var y: = size.y - h - 4.0 if touch() else size.y - h - 4.0
		UI.rounded(self, Rect2(x, y, w, h), Color(UiKit.SLATE_900, 0.82 * alpha), 3)
		var col: = Color(0.85, 0.9, 1.0)
		if not afford:
			col = Color(1, 0.4, 0.35)
		elif tired:
			col = Color(1, 0.7, 0.3)
		UI.text(self, Vector2(x + 5.0, y + h - 3.5), s, fs, Color(col, alpha), 0, HORIZONTAL_ALIGNMENT_LEFT, -1.0, UiKit.pixel_font())


	func _draw_pattern(pat: String, r: Rect2, dark: bool) -> void :
		if pat == "none":
			return
		var col: = Color(0.1, 0.12, 0.18, 0.22) if dark else Color(1, 1, 1, 0.28)
		var step: = 24.0 if touch() else 22.0
		var y: = r.position.y + 14.0
		var row: = 0
		while y < r.end.y - 8.0:
			var x: = r.position.x + 12.0 + (step * 0.5 if row % 2 == 1 else 0.0)
			while x < r.end.x - 8.0:
				_glyph(pat, Vector2(x, y), col, dark)
				x += step
			y += step * 0.66
			row += 1

	func _glyph(pat: String, c: Vector2, col: Color, dark: bool) -> void :
		var s: = 4.5
		match pat:
			"flame":
				draw_polyline(PackedVector2Array([c + Vector2(0, - s), c + Vector2(s, s), c + Vector2( - s, s), c + Vector2(0, - s)]), col, 1.4)
			"leaf":
				draw_line(c + Vector2( - s, s), c + Vector2(s, - s), col, 1.6)
				draw_line(c + Vector2( - s, s), c + Vector2(s, s), col, 1.6)
			"wave":
				draw_polyline(PackedVector2Array([c + Vector2( - s, 0), c + Vector2( - s * 0.4, - s * 0.6), c + Vector2(s * 0.2, 0), c + Vector2(s * 0.7, s * 0.6)]), col, 1.6)
			"bolt":
				draw_polyline(PackedVector2Array([c + Vector2( - s * 0.4, - s), c + Vector2( - s * 0.8, s * 0.1), c + Vector2(0, s * 0.1), c + Vector2(s * 0.5, s)]), col, 1.6)
			"dot":
				draw_circle(c, s * 0.42, col)
			"bubble":
				draw_arc(c, s * 0.7, 0, TAU, 12, col, 1.4, true)
				draw_circle(c + Vector2(s, - s), s * 0.35, col)
			"feather":
				draw_line(c + Vector2( - s, s), c + Vector2(s, - s), col, 1.5)
				draw_line(c + Vector2( - s * 0.2, s * 0.4), c + Vector2(s * 0.4, - s * 0.2), col, 1.2)
			"block":
				draw_rect(Rect2(c - Vector2(s, s) * 0.7, Vector2(s, s) * 1.4), col, false, 1.4)
			"hex":
				var pts: = PackedVector2Array()
				for i in 6:
					var ang: = TAU * i / 6.0
					pts.append(c + Vector2(cos(ang), sin(ang)) * s * 0.8)
				draw_polyline(pts + PackedVector2Array([pts[0]]), col, 1.4)
			"eye":
				draw_arc(c, s, 0.1, PI - 0.1, 10, col, 1.4, true)
				draw_circle(c, s * 0.3, col)
			"ring":
				draw_arc(c, s * 0.8, 0, TAU, 14, col, 1.4, true)
			"cross":
				draw_line(c + Vector2( - s, - s), c + Vector2(s, s), col, 1.5)
				draw_line(c + Vector2(s, - s), c + Vector2( - s, s), col, 1.5)
			"diamond":
				draw_polyline(PackedVector2Array([c + Vector2(0, - s), c + Vector2(s, 0), c + Vector2(0, s), c + Vector2( - s, 0), c + Vector2(0, - s)]), col, 1.4)
			"plus":
				draw_line(c + Vector2( - s, 0), c + Vector2(s, 0), col, 1.5)
				draw_line(c + Vector2(0, - s), c + Vector2(0, s), col, 1.5)
			"void":
				draw_circle(c + Vector2(0, 1), s * 0.7, Color(0, 0, 0, 0.18))
			"snow":
				for i in 3:
					var ang: = PI * i / 3.0
					draw_line(c - Vector2(cos(ang), sin(ang)) * s, c + Vector2(cos(ang), sin(ang)) * s, col, 1.3)

	func _draw_item(r: Rect2, rad: float, a: Vector3) -> void :
		UI.rounded(self, r, Color(UiKit.SLATE_900, a.x), rad, 2.0, Color(UiKit.AMBER, 0.85))
		if not touch():
			_key_chip(Vector2(3, 3), glyph(), a.z)
		var id: = item_id()
		if id == "":
			UI.text_center(self, Vector2(size.x * 0.5, size.y * 0.5 + 6.0), "—", 16, Color(1, 1, 1, 0.3), 0)
			return
		var n: int = Game.item_count(id)
		var dim: = n <= 0
		var icon_r: = minf(size.x, size.y) * (0.34 if touch() else 0.3)
		UI.item_icon(self, id, Rect2(Vector2(size.x * 0.5 - icon_r, size.y * 0.5 - icon_r - 4.0), Vector2(icon_r, icon_r) * 2.0), dim)
		var nm: = ItemsData.item_name(id)
		var fs: = 13 if touch() else 10
		while nm.length() > 1 and UI.text_width(nm + "…", fs) > size.x - 30.0:
			nm = nm.substr(0, nm.length() - 1)
		UI.text_center(self, Vector2(size.x * 0.5, size.y - 14.0), nm, fs, Color(1, 1, 1, 0.85 if not dim else 0.4), 3)
		UI.text_center(self, Vector2(size.x - 14.0, 12.0), "×%d" % n, 10, Color(1, 0.6, 0.6) if dim else Color.WHITE, 2)






class ActionPill extends Control:
	const UI: = preload("res://scripts/ui/ui_draw.gd")
	var touch_style: = false
	var ring: = Color.WHITE
	var dim: = false

	func action() -> String:
		return ""

	func label() -> String:
		return ""

	func glyph() -> String:
		return Controls.key_label(action())

	func _gui_input(e: InputEvent) -> void :
		if Controls.is_touch():
			return
		if e is InputEventMouseButton and e.pressed and e.button_index == MOUSE_BUTTON_LEFT:
			press()

	func press() -> void :
		var a: = action()
		if a == "":
			return
		Input.action_press(a)
		await get_tree().process_frame
		Input.action_release(a)

	func cooldown_state() -> Array:
		return [0.0, -1.0]

	func progress() -> float:
		var st: = cooldown_state()
		return 1.0 if float(st[0]) <= 0.0 else clampf(1.0 - float(st[1]), 0.0, 1.0)

	func progress_rect() -> Rect2:
		return Rect2(0, 0, size.x * progress(), size.y) if float(cooldown_state()[0]) > 0.0 else Rect2()

	func _draw() -> void :
		var r: = Rect2(Vector2.ZERO, size)
		var rad: = 7.0
		var touch: = Controls.is_touch() and touch_style
		var a: = TOUCH_A if touch else 0.94
		var ring_a: = 0.9 if not touch else 0.9
		UI.rounded(self, Rect2(r.position + Vector2(0, 3), r.size), Color(0, 0, 0, 0.45), rad)
		UI.rounded(self, r, Color(UiKit.SLATE_800, a), rad, 2.0, Color(ring, ring_a if not dim else 0.45))
		var st: = cooldown_state()
		var cooling: = float(st[0]) > 0.0
		if cooling:
			var fill: = progress_rect()
			if fill.has_area():
				UI.rounded(self, fill, Color(ring, a * 0.65), minf(rad, fill.size.x * 0.5))
			UI.text_center(self, Vector2(size.x * 0.5 if touch else size.x - 17.0, 
				size.y * 0.5 + 24.0 if touch else 16.0), "%.1f" % float(st[0]), 14, Color.WHITE, 3)
		if touch:
			var fs: = 15 if size.y >= 90.0 else 13
			UI.text_center(self, Vector2(size.x * 0.5, size.y * 0.5 + fs * 0.4 - (10.0 if cooling else 0.0)), label(), fs, 
				Color(1, 1, 1, 1.0 if not dim else 0.5), 3, UiKit.title_font())
			return
		var g: = glyph()
		if g != "":
			var fs2: = 11
			var gw: = maxf(15.0, UI.text_width(g, fs2) + 6.0)
			UI.rounded(self, Rect2(4, 3, gw, 15), Color(UiKit.SLATE_900, 0.9), 5, 2.0, Color(ring, 0.9))
			UI.text(self, Vector2(7, 14), g, fs2, Color(ring, 0.95), 0)
		UI.text(self, Vector2(4, size.y - 6.0), label(), 13, 
			Color(1, 1, 1, 1.0 if not dim else 0.45), 3, HORIZONTAL_ALIGNMENT_LEFT, -1.0, UiKit.title_font())


	func label_center() -> Vector2:
		return Vector2(size.x * 0.5, size.y * 0.5)


class ItemsButton extends ActionPill:
	func action() -> String:
		return ""

	func label() -> String:
		return "ITEMS"

	func glyph() -> String:
		return Controls.key_label("items_page")

	func _draw() -> void :
		if Controls.is_touch() and touch_style:
			var p: bool = Controls.items_page_held()
			var h: = get_parent()
			var held: bool = h != null and h.has_method("touch_held") and bool(h.touch_held("items_page"))
			var a: = TOUCH_A_PRESSED if (p or held) else TOUCH_A
			UI.round_button(self, size, Color(UiKit.SLATE_800, a), Color(UiKit.AMBER, 0.9))
			UI.item_icon(self, "potion", Rect2(size * 0.2, size * 0.6))
			return
		super._draw()


class PartyButton extends ActionPill:
	func action() -> String:
		return "party_ring"

	func label() -> String:
		return "POKéMON"

	func glyph() -> String:
		return Controls.key_label("party_ring")


	func cooldown_state() -> Array:
		var t: float = Battle.free_switch_t
		if t <= 0.0:
			return [0.0, -1.0]
		return [t, 1.0 - clampf(t / Battle.FREE_SWITCH_WINDOW, 0.0, 1.0)]

	func _process(_d: float) -> void :
		ring = Color(0.35, 0.85, 0.45, 0.95) if Battle.free_switch_t > 0.0 else Color.WHITE

	func _draw() -> void :
		var touch: = Controls.is_touch() and touch_style
		var r: = Rect2(Vector2.ZERO, size)
		var free: float = Battle.free_switch_t
		if touch:
			UI.round_button(self, size, Color(UiKit.SLATE_800, TOUCH_A), Color(Color(0.35, 0.85, 0.45) if free > 0.0 else ring, 0.9))
			UI.ball_icon(self, Rect2(size * 0.2, size * 0.6))
			if free > 0.0:
				UI.text_center(self, Vector2(size.x * 0.5, size.y * 0.5 + 24.0), "%.1f" % free, 14, Color.WHITE, 3)
			return
		super._draw()
		UI.ball_icon(self, Rect2(size.x - 24.0, 2, 22, 22))


class SwapButton extends ActionPill:
	func action() -> String:
		return "control_other"

	func label() -> String:
		return "SWAP"

	func glyph() -> String:
		return Controls.key_label("control_other")


class SprintButton extends ActionPill:
	func action() -> String:
		return "sprint"

	func label() -> String:
		return "DODGE"

	func glyph() -> String:
		return Controls.key_label("sprint")

	func _init() -> void :
		ring = Color(0.35, 0.85, 0.45, 0.95)

	func cooldown_state() -> Array:
		var p: Node = Battle.partner
		if not is_instance_valid(p) or p.combat.evade_cd_t <= 0.0:
			return [0.0, -1.0]
		var total: float = p.combat.EVADE_COOLDOWN / maxf(p.recovery_factor(), 0.01)
		return [float(p.combat.evade_cd_t), clampf(p.combat.evade_cd_t / maxf(total, 0.01), 0.0, 1.0)]


class JumpButton extends ActionPill:
	func action() -> String:
		return "jump"

	func glyph() -> String:
		return Controls.key_label("jump")


	func label_state() -> Array:
		var p = Battle.partner
		var c = p.combat if p != null and is_instance_valid(p) else null
		if c == null:
			return ["JUMP", false]
		var verb: String = c.jump_verb()
		if verb == "":
			return ["JUMP", false]
		return [verb.to_upper(), c.jump_ready()]

	func label() -> String:
		return String(label_state()[0])

	func _process(_d: float) -> void :
		dim = not bool(label_state()[1])

	func _draw() -> void :
		super._draw()





class PipsRow extends Control:
	func _gui_input(e: InputEvent) -> void :
		if Controls.is_touch():
			return
		if e is InputEventMouseButton and e.pressed and e.button_index == MOUSE_BUTTON_LEFT:
			press()

	func press() -> void :
		Input.action_press("party_ring")
		await get_tree().process_frame
		Input.action_release("party_ring")

	func _draw() -> void :
		pass

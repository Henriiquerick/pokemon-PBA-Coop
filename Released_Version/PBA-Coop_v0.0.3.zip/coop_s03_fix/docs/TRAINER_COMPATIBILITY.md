# Matriz de treinadores

340 defini??es no cat?logo; presen?a em dados n?o prova encontro acess?vel. Nenhuma recompensa cooperativa persistente homologada.

| ID | Refer?ncia em mapa/interior | Gatilho LAN | Evid?ncia | Ins?gnia definida |
|---|---|---|---|---|
| black_belt_aaron | n?o localizada; conferir cena/script | suspenso | pendente |  |
| black_belt_daisuke | maps/route_23 | suspenso | pendente |  |
| black_belt_hideki | n?o localizada; conferir cena/script | suspenso | pendente |  |
| black_belt_hitoshi | n?o localizada; conferir cena/script | suspenso | pendente |  |
| black_belt_koichi | n?o localizada; conferir cena/script | suspenso | pendente |  |
| black_belt_mike | n?o localizada; conferir cena/script | suspenso | pendente |  |
| blaine | n?o localizada; conferir cena/script | suspenso | pendente | volcano |
| brock | n?o localizada; conferir cena/script | permitido, experimental | duas m?quinas (v7, usu?rio) | boulder |
| bug_catcher_anthony | maps/viridian_forest | suspenso | pendente |  |
| bug_catcher_charlie | maps/viridian_forest | suspenso | pendente |  |
| bug_catcher_colton | maps/route_3 | suspenso | pendente |  |
| bug_catcher_doug | maps/viridian_forest | suspenso | pendente |  |
| bug_catcher_drew | maps/route_2 | permitido, experimental | local e usu?rio, vers?es anteriores |  |
| bug_catcher_greg | maps/route_3 | suspenso | pendente |  |
| bug_catcher_james | maps/route_3 | suspenso | pendente |  |
| bug_catcher_kent | maps/mt_moon_zones | suspenso | pendente |  |
| bug_catcher_rick | maps/viridian_forest | suspenso | pendente |  |
| bug_catcher_robby | maps/mt_moon_zones | suspenso | pendente |  |
| bug_catcher_sammy | maps/viridian_forest | suspenso | pendente |  |
| burglar_dusty | n?o localizada; conferir cena/script | suspenso | pendente |  |
| burglar_quinn | n?o localizada; conferir cena/script | suspenso | pendente |  |
| burglar_ramon | n?o localizada; conferir cena/script | suspenso | pendente |  |
| camper_liam | n?o localizada; conferir cena/script | permitido, experimental | pendente |  |
| cg_beauty_bridget | n?o localizada; conferir cena/script | suspenso | pendente |  |
| cg_beauty_lori | n?o localizada; conferir cena/script | suspenso | pendente |  |
| cg_beauty_tamia | n?o localizada; conferir cena/script | suspenso | pendente |  |
| cg_cooltrainer_mary | n?o localizada; conferir cena/script | suspenso | pendente |  |
| cg_lass_kay | n?o localizada; conferir cena/script | suspenso | pendente |  |
| cg_lass_lisa | n?o localizada; conferir cena/script | suspenso | pendente |  |
| cg_picnicker_tina | n?o localizada; conferir cena/script | suspenso | pendente |  |
| cgc_grunt | n?o localizada; conferir cena/script | suspenso | pendente |  |
| channeler_amanda | n?o localizada; conferir cena/script | suspenso | pendente |  |
| channeler_carly | maps/pokemon_tower_arenas | suspenso | pendente |  |
| channeler_hope | maps/pokemon_tower_arenas | suspenso | pendente |  |
| channeler_janae | maps/pokemon_tower_arenas | suspenso | pendente |  |
| channeler_jody | maps/pokemon_tower_arenas | suspenso | pendente |  |
| channeler_karina | maps/pokemon_tower_arenas | suspenso | pendente |  |
| channeler_laurel | maps/pokemon_tower_arenas | suspenso | pendente |  |
| channeler_patricia | maps/pokemon_tower_arenas | suspenso | pendente |  |
| channeler_paula | maps/pokemon_tower_arenas | suspenso | pendente |  |
| channeler_ruth | maps/pokemon_tower_arenas | suspenso | pendente |  |
| channeler_tammy | maps/pokemon_tower_arenas | suspenso | pendente |  |
| cooltrainer_alexa | n?o localizada; conferir cena/script | suspenso | pendente |  |
| cooltrainer_caroline | maps/route_23 | suspenso | pendente |  |
| cooltrainer_colby | n?o localizada; conferir cena/script | suspenso | pendente |  |
| cooltrainer_george | n?o localizada; conferir cena/script | suspenso | pendente |  |
| cooltrainer_naomi | maps/route_23 | suspenso | pendente |  |
| cooltrainer_ray_tyra | n?o localizada; conferir cena/script | suspenso | pendente |  |
| cooltrainer_rolando | maps/route_23 | suspenso | pendente |  |
| erika | n?o localizada; conferir cena/script | suspenso | pendente | rainbow |
| giovanni_gym | n?o localizada; conferir cena/script | suspenso | pendente | earth |
| green_vermilion | n?o localizada; conferir cena/script | suspenso | pendente |  |
| hiker_dudley | n?o localizada; conferir cena/script | permitido, experimental | pendente |  |
| hiker_marcos | maps/mt_moon_zones | suspenso | pendente |  |
| hiker_narrows | maps/route_4 | suspenso | pendente |  |
| juggler_gregory | n?o localizada; conferir cena/script | suspenso | pendente |  |
| juggler_kayden | n?o localizada; conferir cena/script | suspenso | pendente |  |
| juggler_kirk | n?o localizada; conferir cena/script | suspenso | pendente |  |
| juggler_nelson | n?o localizada; conferir cena/script | suspenso | pendente |  |
| koga | n?o localizada; conferir cena/script | suspenso | pendente | soul |
| koga_tower | n?o localizada; conferir cena/script | suspenso | pendente |  |
| lass_crissy | maps/route_4 | suspenso | pendente |  |
| lass_faye | maps/route_2 | permitido, experimental | pendente |  |
| lass_iris | maps/mt_moon_zones | suspenso | pendente |  |
| lass_janice | maps/route_3 | suspenso | pendente |  |
| lass_miriam | maps/mt_moon_zones | suspenso | pendente |  |
| lass_robin | maps/route_3 | suspenso | pendente |  |
| lass_sally | maps/route_3 | suspenso | pendente |  |
| misty | n?o localizada; conferir cena/script | suspenso | pendente | cascade |
| picnicker_diana | n?o localizada; conferir cena/script | suspenso | pendente |  |
| pokemaniac_dawson | n?o localizada; conferir cena/script | suspenso | pendente |  |
| psychic_johan | n?o localizada; conferir cena/script | suspenso | pendente |  |
| psychic_preston | n?o localizada; conferir cena/script | suspenso | pendente |  |
| psychic_tyron | n?o localizada; conferir cena/script | suspenso | pendente |  |
| red_vermilion | n?o localizada; conferir cena/script | suspenso | pendente |  |
| rh_b1_grunt1 | n?o localizada; conferir cena/script | suspenso | pendente |  |
| rh_b1_grunt2 | n?o localizada; conferir cena/script | suspenso | pendente |  |
| rh_b1_grunt3 | n?o localizada; conferir cena/script | suspenso | pendente |  |
| rh_b1_sci1 | n?o localizada; conferir cena/script | suspenso | pendente |  |
| rh_b2_ariana | n?o localizada; conferir cena/script | suspenso | pendente |  |
| rh_b2_grunt1 | n?o localizada; conferir cena/script | suspenso | pendente |  |
| rh_b2_grunt2 | n?o localizada; conferir cena/script | suspenso | pendente |  |
| rh_b2_sci1 | n?o localizada; conferir cena/script | suspenso | pendente |  |
| rh_b2_sci2 | n?o localizada; conferir cena/script | suspenso | pendente |  |
| rival_blue_cerulean | n?o localizada; conferir cena/script | suspenso | pendente |  |
| rival_blue_route22 | maps/route_22 | suspenso | pendente |  |
| rival_blue_tower | maps/pokemon_tower_arenas | suspenso | pendente |  |
| rock_tunnel_allen | maps/rock_tunnel_zones | suspenso | pendente |  |
| rock_tunnel_ariana | maps/rock_tunnel_zones | suspenso | pendente |  |
| rock_tunnel_ashton | maps/rock_tunnel_zones | suspenso | pendente |  |
| rock_tunnel_cooper | maps/rock_tunnel_zones | suspenso | pendente |  |
| rock_tunnel_dana | maps/rock_tunnel_zones | suspenso | pendente |  |
| rock_tunnel_dudley | maps/rock_tunnel_zones | suspenso | pendente |  |
| rock_tunnel_eric | maps/rock_tunnel_zones | suspenso | pendente |  |
| rock_tunnel_leah | maps/rock_tunnel_zones | suspenso | pendente |  |
| rock_tunnel_lenny | maps/rock_tunnel_zones | suspenso | pendente |  |
| rock_tunnel_lucas | maps/rock_tunnel_zones | suspenso | pendente |  |
| rock_tunnel_martha | maps/rock_tunnel_zones | suspenso | pendente |  |
| rock_tunnel_oliver | maps/rock_tunnel_zones | suspenso | pendente |  |
| rock_tunnel_sofia | maps/rock_tunnel_zones | suspenso | pendente |  |
| rock_tunnel_steve | maps/rock_tunnel_zones | suspenso | pendente |  |
| rock_tunnel_winston | maps/rock_tunnel_zones | suspenso | pendente |  |
| rocket_1 | maps/mt_moon_zones | suspenso | pendente |  |
| rocket_2 | maps/mt_moon_zones | suspenso | pendente |  |
| rocket_3 | maps/mt_moon_zones | suspenso | pendente |  |
| rocket_4 | maps/mt_moon_zones | suspenso | pendente |  |
| rocket_5 | n?o localizada; conferir cena/script | suspenso | pendente |  |
| rocket_grunt_tower_1 | maps/pokemon_tower_arenas | suspenso | pendente |  |
| rocket_grunt_tower_2 | maps/pokemon_tower_arenas | suspenso | pendente |  |
| rocket_grunt_tower_3 | maps/pokemon_tower_arenas | suspenso | pendente |  |
| rocket_pocket_1 | maps/cerulean_city | suspenso | pendente |  |
| rocket_pocket_2 | maps/cerulean_city | suspenso | pendente |  |
| rocket_pocket_boss | maps/cerulean_city | suspenso | pendente |  |
| rocket_proton | n?o localizada; conferir cena/script | suspenso | pendente |  |
| rocket_ship_1 | n?o localizada; conferir cena/script | suspenso | pendente |  |
| rocket_ship_2 | n?o localizada; conferir cena/script | suspenso | pendente |  |
| rocket_ship_3 | n?o localizada; conferir cena/script | suspenso | pendente |  |
| rocket_ship_4 | n?o localizada; conferir cena/script | suspenso | pendente |  |
| route10_carol | maps/route_10 | suspenso | pendente |  |
| route10_clark | maps/route_10 | suspenso | pendente |  |
| route10_heidi | maps/route_10 | suspenso | pendente |  |
| route10_herman | maps/route_10 | suspenso | pendente |  |
| route10_mark | maps/route_10 | suspenso | pendente |  |
| route10_trent | maps/route_10 | suspenso | pendente |  |
| route11_bernie | maps/route_11 | suspenso | pendente |  |
| route11_braxton | maps/route_11 | suspenso | pendente |  |
| route11_darian | maps/route_11 | suspenso | pendente |  |
| route11_dave | maps/route_11 | suspenso | pendente |  |
| route11_dillon | maps/route_11 | suspenso | pendente |  |
| route11_dirk | maps/route_11 | suspenso | pendente |  |
| route11_eddie | maps/route_11 | suspenso | pendente |  |
| route11_hugo | maps/route_11 | suspenso | pendente |  |
| route11_jasper | maps/route_11 | suspenso | pendente |  |
| route11_yasu | maps/route_11 | suspenso | pendente |  |
| route12_andrew | maps/route_12 | suspenso | pendente |  |
| route12_chip | maps/route_12 | suspenso | pendente |  |
| route12_elliot | maps/route_12 | suspenso | pendente |  |
| route12_gia_jes | maps/route_12 | suspenso | pendente |  |
| route12_hank | maps/route_12 | suspenso | pendente |  |
| route12_justin | maps/route_12 | suspenso | pendente |  |
| route12_luca | maps/route_12 | suspenso | pendente |  |
| route12_ned | maps/route_12 | suspenso | pendente |  |
| route13_alma | maps/route_13 | suspenso | pendente |  |
| route13_gwen | maps/route_13 | suspenso | pendente |  |
| route13_jared | maps/route_13 | suspenso | pendente |  |
| route13_lola | maps/route_13 | suspenso | pendente |  |
| route13_perry | maps/route_13 | suspenso | pendente |  |
| route13_robert | maps/route_13 | suspenso | pendente |  |
| route13_sebastian | maps/route_13 | suspenso | pendente |  |
| route13_sheila | maps/route_13 | suspenso | pendente |  |
| route13_susie | maps/route_13 | suspenso | pendente |  |
| route13_valerie | maps/route_13 | suspenso | pendente |  |
| route14_beck | maps/route_14 | suspenso | pendente |  |
| route14_benny | maps/route_14 | suspenso | pendente |  |
| route14_carter | maps/route_14 | suspenso | pendente |  |
| route14_donald | maps/route_14 | suspenso | pendente |  |
| route14_gerald | maps/route_14 | suspenso | pendente |  |
| route14_isaac | maps/route_14 | suspenso | pendente |  |
| route14_kiri_jan | maps/route_14 | suspenso | pendente |  |
| route14_lukas | maps/route_14 | suspenso | pendente |  |
| route14_malik | maps/route_14 | suspenso | pendente |  |
| route14_marlon | maps/route_14 | suspenso | pendente |  |
| route14_mitch | maps/route_14 | suspenso | pendente |  |
| route15_alex | maps/route_15 | suspenso | pendente |  |
| route15_becky | maps/route_15 | suspenso | pendente |  |
| route15_celia | maps/route_15 | suspenso | pendente |  |
| route15_chester | maps/route_15 | suspenso | pendente |  |
| route15_edwin | maps/route_15 | suspenso | pendente |  |
| route15_ernest | maps/route_15 | suspenso | pendente |  |
| route15_grace | maps/route_15 | suspenso | pendente |  |
| route15_kindra | maps/route_15 | suspenso | pendente |  |
| route15_olivia | maps/route_15 | suspenso | pendente |  |
| route15_ron_mya | maps/route_15 | suspenso | pendente |  |
| route15_yazmin | maps/route_15 | suspenso | pendente |  |
| route16_camron | maps/route_16 | suspenso | pendente |  |
| route16_hideo | maps/route_16 | suspenso | pendente |  |
| route16_koji | maps/route_16 | suspenso | pendente |  |
| route16_lao | maps/route_16 | suspenso | pendente |  |
| route16_lea_jed | maps/route_16 | suspenso | pendente |  |
| route16_luke | maps/route_16 | suspenso | pendente |  |
| route16_ruben | maps/route_16 | suspenso | pendente |  |
| route17_billy | maps/route_17 | suspenso | pendente |  |
| route17_corey | maps/route_17 | suspenso | pendente |  |
| route17_isaiah | maps/route_17 | suspenso | pendente |  |
| route17_jamal | maps/route_17 | suspenso | pendente |  |
| route17_jaxon | maps/route_17 | suspenso | pendente |  |
| route17_nikolas | maps/route_17 | suspenso | pendente |  |
| route17_raul | maps/route_17 | suspenso | pendente |  |
| route17_virgil | maps/route_17 | suspenso | pendente |  |
| route17_william | maps/route_17 | suspenso | pendente |  |
| route17_zeek | maps/route_17 | suspenso | pendente |  |
| route18_jacob | maps/route_18 | suspenso | pendente |  |
| route18_ramiro | maps/route_18 | suspenso | pendente |  |
| route18_wilton | maps/route_18 | suspenso | pendente |  |
| route19_alice | maps/route_19 | suspenso | pendente |  |
| route19_anya | maps/route_19 | suspenso | pendente |  |
| route19_axle | maps/route_19 | suspenso | pendente |  |
| route19_connie | maps/route_19 | suspenso | pendente |  |
| route19_david | maps/route_19 | suspenso | pendente |  |
| route19_douglas | maps/route_19 | suspenso | pendente |  |
| route19_lia | maps/route_19 | suspenso | pendente |  |
| route19_luc | maps/route_19 | suspenso | pendente |  |
| route19_matthew | maps/route_19 | suspenso | pendente |  |
| route19_reece | maps/route_19 | suspenso | pendente |  |
| route19_richard | maps/route_19 | suspenso | pendente |  |
| route19_tony | maps/route_19 | suspenso | pendente |  |
| route20_barry | maps/route_20 | suspenso | pendente |  |
| route20_darrin | maps/route_20 | suspenso | pendente |  |
| route20_dean | maps/route_20 | suspenso | pendente |  |
| route20_irene | maps/route_20 | suspenso | pendente |  |
| route20_melissa | maps/route_20 | suspenso | pendente |  |
| route20_missy | maps/route_20 | suspenso | pendente |  |
| route20_nora | maps/route_20 | suspenso | pendente |  |
| route20_roger | maps/route_20 | suspenso | pendente |  |
| route20_shirley | maps/route_20 | suspenso | pendente |  |
| route20_tiffany | maps/route_20 | suspenso | pendente |  |
| route21_claude | maps/route_21 | suspenso | pendente |  |
| route21_ian | maps/route_21 | suspenso | pendente |  |
| route21_jack | maps/route_21 | suspenso | pendente |  |
| route21_jerome | maps/route_21 | suspenso | pendente |  |
| route21_lil | maps/route_21 | suspenso | pendente |  |
| route21_nolan | maps/route_21 | suspenso | pendente |  |
| route21_roland | maps/route_21 | suspenso | pendente |  |
| route21_ronald | maps/route_21 | suspenso | pendente |  |
| route21_spencer | maps/route_21 | suspenso | pendente |  |
| route21_wade | maps/route_21 | suspenso | pendente |  |
| route24_ali | maps/route_24 | suspenso | pendente |  |
| route24_cale | maps/route_24 | suspenso | pendente |  |
| route24_ethan | maps/route_24 | suspenso | pendente |  |
| route24_reli | maps/route_24 | suspenso | pendente |  |
| route24_rocket | maps/route_24 | suspenso | pendente |  |
| route24_shane | maps/route_24 | suspenso | pendente |  |
| route24_timmy | maps/route_24 | suspenso | pendente |  |
| route25_chad | maps/route_25 | suspenso | pendente |  |
| route25_dan | maps/route_25 | suspenso | pendente |  |
| route25_flint | maps/route_25 | suspenso | pendente |  |
| route25_franklin | maps/route_25 | suspenso | pendente |  |
| route25_haley | maps/route_25 | suspenso | pendente |  |
| route25_joey | maps/route_25 | suspenso | pendente |  |
| route25_kelsey | maps/route_25 | suspenso | pendente |  |
| route25_nob | maps/route_25 | suspenso | pendente |  |
| route25_wayne | maps/route_25 | suspenso | pendente |  |
| route6_elijah | maps/route_6 | suspenso | pendente |  |
| route6_isabelle | maps/route_6 | suspenso | pendente |  |
| route6_jeff | maps/route_6 | suspenso | pendente |  |
| route6_keigo | maps/route_6 | suspenso | pendente |  |
| route6_nancy | maps/route_6 | suspenso | pendente |  |
| route6_ricky | maps/route_6 | suspenso | pendente |  |
| route8_aidan | maps/route_8 | suspenso | pendente |  |
| route8_andrea | maps/route_8 | suspenso | pendente |  |
| route8_eli_anne | maps/route_8 | suspenso | pendente |  |
| route8_glenn | maps/route_8 | suspenso | pendente |  |
| route8_jaren | maps/route_8 | suspenso | pendente |  |
| route8_julia | maps/route_8 | suspenso | pendente |  |
| route8_leslie | maps/route_8 | suspenso | pendente |  |
| route8_megan | maps/route_8 | suspenso | pendente |  |
| route8_paige | maps/route_8 | suspenso | pendente |  |
| route8_ricardo | maps/route_8 | suspenso | pendente |  |
| route8_rich | maps/route_8 | suspenso | pendente |  |
| route8_stan | maps/route_8 | suspenso | pendente |  |
| route9_alan | maps/route_9 | suspenso | pendente |  |
| route9_alicia | maps/route_9 | suspenso | pendente |  |
| route9_brent | maps/route_9 | suspenso | pendente |  |
| route9_brice | maps/route_9 | suspenso | pendente |  |
| route9_caitlin | maps/route_9 | suspenso | pendente |  |
| route9_chris | maps/route_9 | suspenso | pendente |  |
| route9_conner | maps/route_9 | suspenso | pendente |  |
| route9_drew | maps/route_9 | suspenso | pendente |  |
| route9_jeremy | maps/route_9 | suspenso | pendente |  |
| sabrina | n?o localizada; conferir cena/script | suspenso | pendente | marsh |
| silph_10f_r1 | n?o localizada; conferir cena/script | suspenso | pendente |  |
| silph_10f_r2 | n?o localizada; conferir cena/script | suspenso | pendente |  |
| silph_1f_r1 | n?o localizada; conferir cena/script | suspenso | pendente |  |
| silph_1f_r2 | n?o localizada; conferir cena/script | suspenso | pendente |  |
| silph_2f_r1 | n?o localizada; conferir cena/script | suspenso | pendente |  |
| silph_2f_r2 | n?o localizada; conferir cena/script | suspenso | pendente |  |
| silph_2f_r3 | n?o localizada; conferir cena/script | suspenso | pendente |  |
| silph_3f_e1 | n?o localizada; conferir cena/script | suspenso | pendente |  |
| silph_3f_r1 | n?o localizada; conferir cena/script | suspenso | pendente |  |
| silph_3f_r2 | n?o localizada; conferir cena/script | suspenso | pendente |  |
| silph_3f_r3 | n?o localizada; conferir cena/script | suspenso | pendente |  |
| silph_3f_r4 | n?o localizada; conferir cena/script | suspenso | pendente |  |
| silph_4f_r1 | n?o localizada; conferir cena/script | suspenso | pendente |  |
| silph_4f_r2 | n?o localizada; conferir cena/script | suspenso | pendente |  |
| silph_4f_r3 | n?o localizada; conferir cena/script | suspenso | pendente |  |
| silph_5f_e1 | n?o localizada; conferir cena/script | suspenso | pendente |  |
| silph_5f_r1 | n?o localizada; conferir cena/script | suspenso | pendente |  |
| silph_5f_r2 | n?o localizada; conferir cena/script | suspenso | pendente |  |
| silph_5f_r3 | n?o localizada; conferir cena/script | suspenso | pendente |  |
| silph_5f_r4 | n?o localizada; conferir cena/script | suspenso | pendente |  |
| silph_6f_r1 | n?o localizada; conferir cena/script | suspenso | pendente |  |
| silph_6f_r2 | n?o localizada; conferir cena/script | suspenso | pendente |  |
| silph_6f_r3 | n?o localizada; conferir cena/script | suspenso | pendente |  |
| silph_6f_r4 | n?o localizada; conferir cena/script | suspenso | pendente |  |
| silph_7f_r1 | n?o localizada; conferir cena/script | suspenso | pendente |  |
| silph_7f_r2 | n?o localizada; conferir cena/script | suspenso | pendente |  |
| silph_7f_r3 | n?o localizada; conferir cena/script | suspenso | pendente |  |
| silph_8f_r1 | n?o localizada; conferir cena/script | suspenso | pendente |  |
| silph_8f_r2 | n?o localizada; conferir cena/script | suspenso | pendente |  |
| silph_8f_r3 | n?o localizada; conferir cena/script | suspenso | pendente |  |
| silph_8f_r4 | n?o localizada; conferir cena/script | suspenso | pendente |  |
| silph_9f_e1 | n?o localizada; conferir cena/script | suspenso | pendente |  |
| silph_9f_r1 | n?o localizada; conferir cena/script | suspenso | pendente |  |
| silph_9f_r2 | n?o localizada; conferir cena/script | suspenso | pendente |  |
| silph_9f_r3 | n?o localizada; conferir cena/script | suspenso | pendente |  |
| silph_9f_r4 | n?o localizada; conferir cena/script | suspenso | pendente |  |
| ss_anne_ann | n?o localizada; conferir cena/script | suspenso | pendente |  |
| ss_anne_arthur | n?o localizada; conferir cena/script | suspenso | pendente |  |
| ss_anne_barny | n?o localizada; conferir cena/script | suspenso | pendente |  |
| ss_anne_blue | n?o localizada; conferir cena/script | suspenso | pendente |  |
| ss_anne_brooks | n?o localizada; conferir cena/script | suspenso | pendente |  |
| ss_anne_dale | n?o localizada; conferir cena/script | suspenso | pendente |  |
| ss_anne_dawn | n?o localizada; conferir cena/script | suspenso | pendente |  |
| ss_anne_duncan | n?o localizada; conferir cena/script | suspenso | pendente |  |
| ss_anne_dylan | n?o localizada; conferir cena/script | suspenso | pendente |  |
| ss_anne_edmond | n?o localizada; conferir cena/script | suspenso | pendente |  |
| ss_anne_huey | n?o localizada; conferir cena/script | suspenso | pendente |  |
| ss_anne_lamar | n?o localizada; conferir cena/script | suspenso | pendente |  |
| ss_anne_leonard | n?o localizada; conferir cena/script | suspenso | pendente |  |
| ss_anne_phillip | n?o localizada; conferir cena/script | suspenso | pendente |  |
| ss_anne_thomas | n?o localizada; conferir cena/script | suspenso | pendente |  |
| ss_anne_trevor | n?o localizada; conferir cena/script | suspenso | pendente |  |
| ss_anne_tyler | n?o localizada; conferir cena/script | suspenso | pendente |  |
| super_nerd_avery | n?o localizada; conferir cena/script | suspenso | pendente |  |
| super_nerd_jovan | maps/mt_moon_zones | suspenso | pendente |  |
| super_nerd_miguel | n?o localizada; conferir cena/script | suspenso | pendente |  |
| surge | n?o localizada; conferir cena/script | suspenso | pendente | thunder |
| swimmer_luis | n?o localizada; conferir cena/script | suspenso | pendente |  |
| tamer_edgar | n?o localizada; conferir cena/script | suspenso | pendente |  |
| tamer_phil | n?o localizada; conferir cena/script | suspenso | pendente |  |
| tamer_vincent | maps/route_23 | suspenso | pendente |  |
| test_youngster | n?o localizada; conferir cena/script | suspenso | pendente |  |
| vm_gym_baily | n?o localizada; conferir cena/script | suspenso | pendente |  |
| vm_gym_dwayne | n?o localizada; conferir cena/script | suspenso | pendente |  |
| vm_gym_tucker | n?o localizada; conferir cena/script | suspenso | pendente |  |
| youngster_ben | maps/route_3 | suspenso | pendente |  |
| youngster_calvin | maps/route_3 | suspenso | pendente |  |
| youngster_dane | maps/route_2 | permitido, experimental | pendente |  |
| youngster_josh | maps/mt_moon_zones | suspenso | pendente |  |
| youngster_ryan | maps/route_2 | permitido, experimental | local e usu?rio, vers?es anteriores |  |

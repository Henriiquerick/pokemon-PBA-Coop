"""Build verified append-only deltas and Windows entry points. No game/assets in ZIP."""
from pathlib import Path
import hashlib,json,struct,argparse,mmap
from instalar_campanha import PACK_HASH,ORIGINAL_HASH,EXE_HASH
ROOT=Path(__file__).resolve().parent
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def delta(base,target,out):
    with base.open('rb') as a,target.open('rb') as b:
        assert a.read(32)==b.read(32)
        original_dir=a.read(8);new_dir=b.read(8)
        while block:=a.read(4*1024*1024):assert block==b.read(len(block)),'Source is not append-only'
        with out.open('wb') as f:
            while block:=b.read(4*1024*1024):f.write(block)
    return struct.unpack('<Q',new_dir)[0]
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--runtime',required=True,type=Path);a=ap.parse_args();runtime=a.runtime.resolve();source=ROOT.parent
    assert sha(source/'PokemonBattleAdvanced.pck')==ORIGINAL_HASH
    assert sha(source/'PokemonBattleAdvanced.mod.pck')==PACK_HASH
    record=json.loads((runtime/'installation.json').read_text(encoding='utf8-sig'))
    assert sha(runtime/'PokemonBattleAdvanced.pck')==record['coop_pack_sha256']
    build={'version':'community-alpha-1','protocol':'pba-community-alpha-1','game':'0.6.2a','engine':'4.7.1.stable.official.a13da4feb','pack_sha256':record['coop_pack_sha256'],'base_sha256':PACK_HASH,'locale':'pt-BR parcial','moves_in_english':True,'schema':1,'new_features_two_pc_validation_pending':True,'physical_gamepad_tested':False}
    (ROOT/'BUILD.json').write_text(json.dumps(build,ensure_ascii=False,indent=2),encoding='utf8')
    base_dir=delta(source/'PokemonBattleAdvanced.pck',source/'PokemonBattleAdvanced.mod.pck',ROOT/'base.delta')
    final_dir=delta(source/'PokemonBattleAdvanced.mod.pck',runtime/'PokemonBattleAdvanced.pck',ROOT/'community.delta')
    batches={'Instalar.bat':'Instalar.ps1','Jogar-Coop.bat':'Jogar.ps1','Hospedar.bat':'Jogar.ps1 -Modo host','Entrar.bat':'Jogar.ps1 -Modo guest','Jogar-Sozinho.bat':'Jogar.ps1 -Modo offline','Restaurar.bat':'Restaurar.ps1','Coletar-Logs.bat':'Coletar-Logs.ps1'}
    for name,command in batches.items():
        script,*arguments=command.split()
        raw='@echo off\r\ncd /d "%~dp0"\r\n"%SystemRoot%\\System32\\WindowsPowerShell\\v1.0\\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "%~dp0'+script+'" '+ ' '.join(arguments)+' %*\r\npause\r\n'
        (ROOT/name).write_bytes(raw.encode('ascii'))
    for path in ROOT.glob('*.ps1'):
        text=path.read_text(encoding='utf8-sig')
        if path.name=='Instalar.ps1':text=text.replace('$profile.FullName','$profileDir.FullName').replace('$profile.Name','$profileDir.Name').replace('foreach($profile in','foreach($profileDir in')
        path.write_text(text,encoding='utf8-sig')
    names=['base.delta','community.delta',*batches,*[p.name for p in ROOT.glob('*.ps1')]]
    names+=['BUILD.json','LEIA-ME.txt','GUIA_COMUNIDADE.md','RELATORIO_COMUNIDADE.md']
    files={name:sha(ROOT/name) for name in sorted(set(names)) if (ROOT/name).is_file()}
    result={'version':'community-alpha-1','exe_sha256':EXE_HASH,'original_sha256':ORIGINAL_HASH,'base_sha256':PACK_HASH,'coop_pack_sha256':record['coop_pack_sha256'],'base_directory':base_dir,'community_directory':final_dir,'files':files}
    (ROOT/'distribuicao.json').write_text(json.dumps(result,indent=2),encoding='utf8')
    print(json.dumps({'pack_sha256':record['coop_pack_sha256'],'delta_bytes':(ROOT/'community.delta').stat().st_size,'files':len(files)}))

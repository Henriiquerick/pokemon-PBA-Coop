# Atualizacao S3 Fix

Estado atual: todos os companheiros visuais, marcador no minimapa, clima coordenado pelo host e XP/conclusao unica dos encontros integrados. O XP desta entrega cobre os dois participantes ativos; reservas, dinheiro, insignias e historia continuam na S4. GUIA_FIX.md e RELATORIO_FIX.md descrevem as evidencias atuais. Notas anteriores abaixo sao historicas.

# Atualizacao S3

S3 acrescenta perfil persistente individual, IDs, backup e recuperacao. Consulte COOP_SAVE_FORMAT.md e S03_TEST_RESULTS.md para o estado atual. As notas de S01/S02 abaixo descrevem o checkpoint anterior; a limitacao de falta de gravacao foi substituida pela S3. Recompensas cooperativas, insignias, XP compartilhada e trocas continuam nas etapas seguintes.

# Limitações e riscos conhecidos

- V9 e S01 não salvam progresso cooperativo: relançar importa novamente o save pessoal. Não atendem ainda campanha persistente.
- Convites de treinador limitados à Route 2 e ginásio de Pewter. Outros eventos ficam suspensos.
- Retorno entre cenas depende dos pontos específicos de Route 2/Pewter; não generalizar para outros interiores ou desbloqueios.
- Movimento remoto no mapa recebe posições diretamente. Batalha do guest depende de snapshots do host. Fluidez sob jitter ainda não homologada.
- Regressões anteriores envolveram invisibilidade, KO de adversário e derrota. V6–V8 tiveram validação do usuário, mas v9/S01 ainda precisam de dois PCs.
- Fechamento relatado no segundo PC não teve causa comprovada. Erros de shader/Discord e avisos de recursos no encerramento existem nos logs; não atribuir crash automaticamente a eles.
- Timeout atual de 45 s tolera carregamento, mas demora para detectar uma queda real. Precisa de medição em máquinas lentas.
- Autenticidade do peer LAN, limites de payload e validação completa de espécies/estatísticas ainda não são uma fronteira segura para internet pública. Usar a sessão LAN autorizada.
- Trocas nativas não foram integradas ao mod e não têm recuperação distribuída demonstrada.
- Capturas e loot locais funcionam pelo jogo original, mas o estado não persiste nesta entrega. Spawns compartilhados e anti-duplicação ainda não implementados.
- Métricas S01 opcionais acrescentam probes e gravações a cada dois segundos; comparar ligado/desligado. Não medem perda de todos os pacotes.

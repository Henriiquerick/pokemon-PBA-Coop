from pathlib import Path
import subprocess,os,argparse,json,hashlib,uuid,shutil
ROOT=Path(__file__).resolve().parent
if __name__=='__main__':
    ap=argparse.ArgumentParser(description='Recompila as fontes fornecidas usando GDRETools 2.7.4')
    ap.add_argument('--gdre',required=True,type=Path)
    args=ap.parse_args()
    env=os.environ.copy();data=ROOT/'build_userdata';data.mkdir(exist_ok=True);env['APPDATA']=str(data)
    names=[p.stem for p in sorted((ROOT/'src').glob('*.gd'))]
    output=ROOT/'build_compiled'/uuid.uuid4().hex
    output.mkdir(parents=True)
    cmd=[str(args.gdre.resolve()),'--headless','--bytecode=4.7.1','--output='+str(output)]
    cmd+=['--compile='+str(ROOT/'src'/(n+'.gd')) for n in names]
    (ROOT/'logs').mkdir(exist_ok=True)
    with (ROOT/'logs/compile.txt').open('w',encoding='utf8') as f:subprocess.run(cmd,stdout=f,stderr=f,env=env,check=True,timeout=60)
    log=(ROOT/'logs/compile.txt').read_text(encoding='utf8')
    if 'failed to compile' in log.lower() or 'Compile errors:' in log or not all((output/(n+'.gdc')).is_file() for n in names):
        raise SystemExit('Compilacao falhou. Payload anterior nao foi alterado; consulte logs/compile.txt.')
    for n in names:shutil.copy2(output/(n+'.gdc'),ROOT/'payload'/(n+'.gdc'))
    manifest={f.as_posix():hashlib.sha256((ROOT/f).read_bytes()).hexdigest() for f in [Path('payload')/(n+'.gdc') for n in names]}
    for f in list((ROOT/'src').glob('*.gd')) + [ROOT/'src/arena.tscn',ROOT/'src/pt_br.json']:
        manifest[f.relative_to(ROOT).as_posix()] = hashlib.sha256(f.read_bytes()).hexdigest()
    (ROOT/'payload/manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf8')
    print('Recompilado. Instale em um destino novo e valide antes de distribuir.')

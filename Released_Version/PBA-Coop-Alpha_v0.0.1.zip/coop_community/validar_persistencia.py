"""Restart actual game processes and exercise S3 persistence/recovery."""
from pathlib import Path
import argparse,hashlib,json,os,subprocess

HERE=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def main(runtime,logs):
    logs.mkdir(parents=True,exist_ok=False)
    user=logs/'userdata/Godot/app_userdata'/('Pok'+chr(233)+'mon Battle Advanced')
    user.mkdir(parents=True)
    fixture=json.loads((HERE/'fixtures/host.json').read_text(encoding='utf8'))
    fixture['game_version']='0.6.2a'
    fixture['state']['bag']['potion']=11
    boxed=dict(fixture['state']['party'][0])
    boxed['nickname']='S3 BOX'
    boxed['coop_uid']=''
    fixture['state']['box']=[boxed]
    source=user/'campaign_input.json'
    source.write_text(json.dumps(fixture),encoding='utf8')
    source_hash=sha(source)
    env=os.environ.copy();env['APPDATA']=str(logs/'userdata')
    results=[]
    def run(name,role='offline',extra=(),expected=0):
        cmd=[str(runtime/'PokemonBattleAdvanced.exe'),'--headless','--','--coop-campaign',
             '--coop-role='+role,'--coop-start=save','--coop-persist-smoke',*extra]
        p=subprocess.run(cmd,cwd=runtime,env=env,capture_output=True,timeout=90)
        text=(p.stdout+p.stderr).decode('utf8','replace')
        (logs/(name+'.log')).write_text(text,encoding='utf8')
        assert p.returncode==expected,(name,p.returncode,text[-2000:])
        assert 'SCRIPT ERROR' not in text,(name,text)
        rows=[json.loads(line.split('[campaign-lan] ',1)[1]) for line in text.splitlines() if '[campaign-lan] {' in line]
        row=next((r for r in rows if r['event']=='persist_smoke'),{})
        if expected==0:assert row.get('ok'),(name,rows)
        results.append({'name':name,'exit':p.returncode,'event':row})
        return row,text
    first,_=run('01_create',extra=['--coop-persist-mutate'])
    second,_=run('02_reopen_host','host')
    third,_=run('03_reopen_guest','guest')
    for key in ['player_id','session_id','uid','money','hp','pos']:
        assert first[key]==second[key]==third[key],key
    assert second['generation']>first['generation']
    profile=user/'coop_s3/profile.json';backup=Path(str(profile)+'.bak')
    good=profile.read_bytes();good_backup=backup.read_bytes()
    profile.write_text('{corrupted',encoding='utf8')
    recovered,text=run('04_recover_backup')
    assert 'recovered_backup' in text
    assert recovered['uid']==first['uid'] and recovered['money']==first['money']
    profile.write_text('{corrupted',encoding='utf8');backup.write_text('broken',encoding='utf8')
    run('05_both_corrupt',expected=9)
    assert profile.read_text(encoding='utf8')=='{corrupted'
    profile.write_bytes(good);backup.write_bytes(good_backup)
    unknown=json.loads(good);unknown['schema']=999
    profile.write_text(json.dumps(unknown),encoding='utf8')
    run('06_future_schema',expected=9)
    assert json.loads(profile.read_text(encoding='utf8'))['schema']==999
    profile.write_bytes(good)
    Path(str(profile)+'.tmp').write_text('incomplete interrupted write',encoding='utf8')
    final,_=run('07_ignore_incomplete_temp')
    assert final['uid']==first['uid'] and sha(source)==source_hash
    state=json.loads(json.loads(profile.read_text(encoding='utf8'))['payload'])['snapshot']['state']
    assert state['bag']['potion']==11 and state['box'][0]['nickname']=='S3 BOX'
    assert len(state['box'][0]['coop_uid'])==32 and state['box'][0]['coop_uid']!=state['party'][0]['coop_uid']
    assert state['flags']['coop_s3_test'] is True
    report={'passed':True,'cases':results,'source_unchanged':True,'physical_gamepad_tested':False}
    (logs/'result.json').write_text(json.dumps(report,indent=2),encoding='utf8')
    print(json.dumps(report),flush=True)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--runtime',required=True,type=Path);ap.add_argument('--logs',required=True,type=Path)
    a=ap.parse_args();main(a.runtime.resolve(),a.logs.resolve())

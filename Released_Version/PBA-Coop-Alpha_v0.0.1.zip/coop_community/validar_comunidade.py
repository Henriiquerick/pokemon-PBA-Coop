from pathlib import Path
import argparse,subprocess,os,time,json

def run(runtime,base,case,port,visible=False):
    base=base/case;base.mkdir(parents=True,exist_ok=False);ps=[];reports={};profiles={}
    try:
        for role in ['host','guest']:
            data=base/role;data.mkdir();env=os.environ.copy();env['APPDATA']=str(data)
            out=(base/(role+'.log')).open('w',encoding='utf8')
            cmd=[str(runtime/'PokemonBattleAdvanced.exe')]
            if not visible:cmd+=['--headless']
            cmd+=['--','--coop-campaign','--coop-role='+role,'--coop-port='+str(port),'--coop-autotest','--coop-persist-test','--coop-test='+case,'--coop-start='+(case if case in ['special','primeape'] else 'route2')]
            p=subprocess.Popen(cmd,cwd=runtime,env=env,stdout=out,stderr=out);ps.append((role,p,out));time.sleep(1)
        deadline=time.monotonic()+(240 if visible else 130)
        while any(p.poll() is None for _,p,_ in ps) and time.monotonic()<deadline:time.sleep(.25)
        for role,p,out in ps:
            assert p.poll() is not None,(case,role,'timeout')
            out.close();text=(base/(role+'.log')).read_text(encoding='utf8')
            assert p.returncode==0 and 'SCRIPT ERROR' not in text,(role,p.returncode,text[-3500:])
            reports[role]=[json.loads(s.split('[campaign-lan] ',1)[1]) for s in text.splitlines() if '[campaign-lan] {' in s]
            for event in ['connected','community_map_open' if case=='community' else 'special_settled']:assert any(r['event']==event for r in reports[role]),(role,event)
            path=next((base/role).rglob('profile.json'));profiles[role]=json.loads(json.loads(path.read_text(encoding='utf8'))['payload'])
        if case=='community':
            for role,rows in reports.items():
                t=next(r for r in rows if r['event']=='translation_test');assert t['move']=='Rock Tomb' and t['oak']=='Vovô! Já cansei de esperar!' and t['locale']=='pt_BR',t
                mark=next(r for r in rows if r['event']=='map_marker_test');assert mark['found'] and mark['partner']=='rt_2' and mark['read_only'],mark
                end=next(r for r in rows if r['event']=='community_test_done');assert end['controls'] and not end['battle'] and not end['watching'],end
            view=next(r for r in reports['guest'] if r['event']=='spectator_state_test');assert view['actors']>=2 and view['readonly'],view
            assert any(r['event']=='spectator_closed' and r['controls'] for r in reports['guest'])
        else:
            for role,doc in profiles.items():
                species='Primeape' if case=='primeape' else 'Raticate';uid='r22_primeape' if case=='primeape' else 'r1_raticate'
                state=doc['snapshot']['state'];assert len(state['party'])==2 and state['party'][1]['species']==species,state['party']
                assert state['bag']['master_ball']==1 and state['flags']['static_'+uid],state['bag']
                assert any(r['event']=='special_settled' and r['captures']==1 and r['saved'] for r in reports[role])
                assert any(r['event']=='returned_to_campaign' and r['controls'] and not r['battle'] for r in reports[role])
            assert profiles['host']['snapshot']['state']['party'][1]['coop_uid']!=profiles['guest']['snapshot']['state']['party'][1]['coop_uid']
            captured=[r for r in reports['host'] if r['event']=='special_captured'];assert {r['player'] for r in captured}=={0,1} and {r['target'] for r in captured}=={2,3},captured
            assert any(r['event']=='capture_quota_rejected' for r in reports['host'])
        result={'case':case,'passed':True,'real_processes':True,'physical_gamepad_tested':False}
        (base/'result.json').write_text(json.dumps(result,indent=2),encoding='utf8');print(json.dumps(result),flush=True);return result
    finally:
        for _,p,out in ps:
            if p.poll() is None:p.kill();p.wait()
            out.close()

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--runtime',type=Path,required=True);ap.add_argument('--logs',type=Path,required=True);ap.add_argument('--case',choices=['community','special','primeape'],required=True);ap.add_argument('--visible',action='store_true')
    a=ap.parse_args();run(a.runtime.resolve(),a.logs.resolve(),a.case,{'community':25221,'special':25222,'primeape':25223}[a.case],a.visible)

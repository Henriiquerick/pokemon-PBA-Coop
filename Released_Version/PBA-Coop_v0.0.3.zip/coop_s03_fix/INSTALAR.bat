@echo off
cd /d "%~dp0"
python instalar_campanha.py
pause

extends Node3D







const HEIGHT: = 8.0
const COLOR: = Color(1.0, 0.86, 0.45, 0.9)



const BORDER_WIDTH: = 0.6

const BORDER_DAMAGE: = 0.0

const BORDER_STUCK: = 1.0

const BORDER_LOCKOUT: = 2.0

const BORDER_PUSH: = 1.0
const BORDER_COLOR: = Color(0.55, 0.9, 1.0)

const BORDER_EDGE: = 0.5

const QUAD_LIFT: = 0.04

static var _tex: ImageTexture

var _decal: Decal

var _marker_node: MeshInstance3D
var _marker_mat: StandardMaterial3D

var _border_mesh: MeshInstance3D
var _border_mat: StandardMaterial3D



static func square_texture() -> ImageTexture:
	if _tex == null:
		_tex = ImageTexture.create_from_image(_square_image())
	return _tex


static func prepare() -> void :
	if _tex == null:
		var image: Image = await preload("res://scripts/async_assets.gd").cpu(_square_image)
		_tex = ImageTexture.create_from_image(image)


static func _square_image() -> Image:
	var n: = 256
	var img: = Image.create(n, n, false, Image.FORMAT_RGBA8)
	var line: = 0.022
	var inset: = 0.012
	for y in n:
		for x in n:
			var u: = float(x) / (n - 1)
			var v: = float(y) / (n - 1)
			var edge: = minf(minf(u, 1.0 - u), minf(v, 1.0 - v))
			var a: = 0.0
			if edge >= inset and edge < inset + line:
				a = 0.85

			var cu: = minf(u, 1.0 - u)
			var cv: = minf(v, 1.0 - v)
			if (cu < 0.14 and cv < inset + line * 2.6 and cv >= inset) or (cv < 0.14 and cu < inset + line * 2.6 and cu >= inset):
				a = 1.0

			if edge >= inset + line * 2.2 and edge < inset + line * 3.0:
				var along: = u if (minf(v, 1.0 - v) < minf(u, 1.0 - u)) else v
				a = maxf(a, 0.5 if fmod(along * 24.0, 1.0) < 0.5 else 0.0)

			if edge > inset:
				a = maxf(a, 0.06 + 0.08 * (1.0 - smoothstep(0.0, 0.25, edge)))
			img.set_pixel(x, y, Color(1, 1, 1, a))
	return img



static func uses_quad() -> bool:
	return RenderingServer.get_current_rendering_method() == "gl_compatibility"






func setup(center: Vector3, size, color: = COLOR, thunder: = 0.0) -> void :
	var sz: Vector2 = size if size is Vector2 else Vector2(size, size)
	global_position = center
	if uses_quad():
		_build_quad(sz, color)
	else:
		_build_decal(sz, color)
	if thunder > 0.0:
		_build_border(sz, thunder)
	var tw: = create_tween().set_parallel(true)
	tw.tween_property(_marker(), _fade_prop(), color.a, 0.4)
	tw.tween_property(self, "scale", Vector3.ONE, 0.4).from(Vector3(1.15, 1, 1.15)).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)



func _build_decal(sz: Vector2, color: Color) -> void :
	_decal = Decal.new()
	_decal.texture_albedo = square_texture()
	_decal.modulate = Color(color.r, color.g, color.b, 0.0)
	_decal.albedo_mix = 1.0
	_decal.normal_fade = 0.6
	_decal.upper_fade = 0.2
	_decal.lower_fade = 0.2
	_decal.size = Vector3(sz.x, HEIGHT, sz.y)
	add_child(_decal)







func _build_quad(sz: Vector2, color: Color) -> void :
	var pm: = PlaneMesh.new()
	pm.size = sz
	_marker_node = MeshInstance3D.new()
	_marker_node.name = "ArenaQuad"
	_marker_node.mesh = pm
	_marker_node.position = Vector3(0, QUAD_LIFT, 0)
	_marker_node.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	_marker_mat = StandardMaterial3D.new()
	_marker_mat.albedo_texture = square_texture()
	_marker_mat.albedo_color = Color(color.r, color.g, color.b, 0.0)
	_marker_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	_marker_mat.roughness = 1.0
	_marker_mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	_marker_mat.render_priority = -1
	_marker_node.material_override = _marker_mat
	add_child(_marker_node)




func _marker() -> Object:
	return _decal if _decal else _marker_mat


func _fade_prop() -> String:
	return "modulate:a" if _decal else "albedo_color:a"



func track(_a: Node3D, _b: Node3D) -> void :
	pass









const PLACE_STEP: = 1.0
const BATTLE_START_GAP: = 6.0
const GAP_MIN: = 4.0
const GAP_MAX: = 8.0
const FREE_BAR: = 0.98
const SIZE_FLOOR: = 8.0
const FOREST_SIZE: = 7.0
const SEARCH_RINGS: = 7
const BODY_CELLS: = 1
const TRAINER_STAND_OFF: = 0.3
const TRAINER_SHORT_FLOOR: = 4.0



static func _axis(v: Vector3, fallback: = Vector3.ZERO) -> Vector3:
	v.y = 0.0
	if v.length() < 0.05:
		v = fallback
		v.y = 0.0
	if v.length() < 0.05:
		v = Vector3(0, 0, -1)
	return Vector3(signf(v.x), 0, 0) if absf(v.x) > absf(v.z) else Vector3(0, 0, signf(v.z))



static func _flat(center: Vector3, size: Vector2, level: float, height_at: Callable) -> bool:
	var n: = maxi(int(ceil(maxf(size.x, size.y) / PLACE_STEP)), 2)
	var hx: = size.x * 0.5
	var hz: = size.y * 0.5
	for i in n + 1:
		for j in n + 1:
			var x: = center.x - hx + size.x * i / n
			var z: = center.z - hz + size.y * j / n
			if absf(float(height_at.call(x, z)) - level) > 0.01:
				return false
	return true




static func _blocked(blocked_at: Callable, height_at: Callable, level: float) -> Callable:
	if not blocked_at.is_valid():
		blocked_at = func(_x: float, _z: float) -> bool: return false
	var cache: = {}
	return func(x: float, z: float) -> bool:
		var key: = Vector2i(roundi(x * 100.0), roundi(z * 100.0))
		if cache.has(key):
			return cache[key]
		var b: = absf(float(height_at.call(x, z)) - level) > 0.01 or bool(blocked_at.call(x, z))
		cache[key] = b
		return b



static func _free_score(center: Vector3, size: Vector2, blocked: Callable) -> float:
	var nx: = maxi(int(round(size.x / PLACE_STEP)), 2)
	var nz: = maxi(int(round(size.y / PLACE_STEP)), 2)
	var free: = 0
	for i in nx:
		for j in nz:
			var x: = center.x - size.x * 0.5 + size.x * (i + 0.5) / nx
			var z: = center.z - size.y * 0.5 + size.y * (j + 0.5) / nz
			if not bool(blocked.call(x, z)):
				free += 1
	return float(free) / float(nx * nz)



static func _cell_clear(x: float, z: float, blocked: Callable) -> bool:
	for i in range( - BODY_CELLS, BODY_CELLS + 1):
		for j in range( - BODY_CELLS, BODY_CELLS + 1):
			if bool(blocked.call(x + i * PLACE_STEP, z + j * PLACE_STEP)):
				return false
	return true




static func _ok(pred: Callable, p: Vector2) -> bool:
	return not pred.is_valid() or bool(pred.call(p.x, p.y))



static func _snap(x: float, z: float, blocked: Callable, rings: = 4, ok: = Callable()) -> Vector2:
	for r in rings + 1:
		for i in range( - r, r + 1):
			for j in range( - r, r + 1):
				if maxi(absi(i), absi(j)) != r:
					continue
				var px: = x + i * PLACE_STEP
				var pz: = z + j * PLACE_STEP
				if _cell_clear(px, pz, blocked) and _ok(ok, Vector2(px, pz)):
					return Vector2(px, pz)
	return Vector2.INF



static func _line_clear(a: Vector2, b: Vector2, blocked: Callable) -> bool:
	var n: = maxi(int(ceil(a.distance_to(b) / (PLACE_STEP * 0.5))), 1)
	for i in n + 1:
		var p: = a.lerp(b, float(i) / n)
		if not _cell_clear(p.x, p.y, blocked):
			return false
	return true



static func _line_free(a: Vector2, b: Vector2, blocked: Callable) -> bool:
	var n: = maxi(int(ceil(a.distance_to(b) / (PLACE_STEP * 0.5))), 1)
	for i in n + 1:
		var p: = a.lerp(b, float(i) / n)
		if bool(blocked.call(p.x, p.y)):
			return false
	return true






static func _pair(center: Vector3, size: Vector2, axis: Vector3, start: Vector3, blocked: Callable, 
		wild_start: = Vector3.INF, wild_blocked: = Callable(), 
		lead_ok: = Callable(), wild_ok: = Callable()) -> Dictionary:
	var half: = BATTLE_START_GAP * 0.5


	var a: = _snap(center.x + axis.x * half, center.z + axis.z * half, blocked, 4, wild_ok)
	var b: = _snap(center.x - axis.x * half, center.z - axis.z * half, blocked, 4, lead_ok)
	if not a.is_finite() or not b.is_finite():
		return {}
	var rect: = Rect2(center.x - size.x * 0.5, center.z - size.y * 0.5, size.x, size.y)
	if not rect.has_point(a) or not rect.has_point(b):
		return {}
	var sp: = Vector2(start.x, start.z)
	var lead: = a if a.distance_to(sp) <= b.distance_to(sp) else b
	var wild: = b if lead == a else a


	if not _ok(lead_ok, lead):
		lead = _snap(lead.x, lead.y, blocked, 4, lead_ok)
	if not _ok(wild_ok, wild):
		wild = _snap(wild.x, wild.y, blocked, 4, wild_ok)
	if not lead.is_finite() or not wild.is_finite():
		return {}
	if not rect.has_point(lead) or not rect.has_point(wild):
		return {}
	var gap: = lead.distance_to(wild)
	if gap < GAP_MIN or gap > GAP_MAX or not _line_clear(lead, wild, blocked):
		return {}




	if wild_start.is_finite() and wild_blocked.is_valid():
		var wf: = Vector2(wild_start.x, wild_start.z)
		if not bool(wild_blocked.call(wf.x, wf.y)) and not _line_free(wf, wild, wild_blocked):
			return {}
	return {
		"lead_spot": Vector3(lead.x, center.y, lead.y), 
		"wild_spot": Vector3(wild.x, center.y, wild.y), 
	}



static var _offsets_cache: = {}
static func _offsets(rings: int) -> Array:
	if _offsets_cache.has(rings):
		return _offsets_cache[rings]
	var out: Array = []
	for i in range( - rings, rings + 1):
		for j in range( - rings, rings + 1):
			out.append(Vector2i(i, j))
	out.sort_custom( func(a: Vector2i, b: Vector2i) -> bool: return a.length_squared() < b.length_squared())
	_offsets_cache[rings] = out
	return out




static func _best_square(mid: Vector3, size: Vector2, start: Vector3, dir: Vector3, level: float, 
		height_at: Callable, blocked: Callable, bar: float, keep_out: bool, strict: = true, 
		wild_start: = Vector3.INF, wild_blocked: = Callable(), 
		lead_ok: = Callable(), wild_ok: = Callable()) -> Dictionary:
	var half: = size * 0.5
	var best: = {}
	var best_score: = -1.0
	var best_d: = INF
	for o in _offsets(SEARCH_RINGS):
		var c: = Vector3(mid.x + o.x * PLACE_STEP, mid.y, mid.z + o.y * PLACE_STEP)
		if keep_out and absf(start.x - c.x) < half.x and absf(start.z - c.z) < half.y:
			continue
		var score: = _free_score(c, size, blocked)
		if score < bar:
			continue
		var d: = float(o.length_squared())

		if best_score >= 0.0 and score <= best_score * 1.05 and d >= best_d:
			continue
		var pair: = _pair(c, size, dir, start, blocked, wild_start, wild_blocked, lead_ok, wild_ok)
		if pair.is_empty():
			var alt: = _axis(Vector3( - dir.z, 0.0, dir.x))
			pair = _pair(c, size, alt, start, blocked, wild_start, wild_blocked, lead_ok, wild_ok)
			if pair.is_empty():
				continue
			pair["dir"] = alt
		else:
			pair["dir"] = dir
		if strict and not _flat(c, size, level, height_at):
			continue
		best = {"center": c, "size": size, "score": score}
		best.merge(pair)
		best_score = score
		best_d = d
		if score >= 0.999:
			break
	return best



static func _cells(center: Vector3, size: Vector2, blocked: Callable) -> Array:
	var nx: = maxi(int(round(size.x / PLACE_STEP)), 2)
	var nz: = maxi(int(round(size.y / PLACE_STEP)), 2)
	var out: Array = []
	for i in nx:
		for j in nz:
			var x: = center.x - size.x * 0.5 + size.x * (i + 0.5) / nx
			var z: = center.z - size.y * 0.5 + size.y * (j + 0.5) / nz
			out.append({"pos": Vector2(x, z), "free": not bool(blocked.call(x, z))})
	return out



static func _result(c: Dictionary, level: float, blocked: Callable) -> Dictionary:
	var center: Vector3 = c.center
	var size: Vector2 = c.size
	return {
		"level": level, 
		"center": center, 
		"rect": Rect2(center.x - size.x * 0.5, center.z - size.y * 0.5, size.x, size.y), 
		"lead_spot": c.lead_spot, 
		"wild_spot": c.wild_spot, 
		"dir": c.dir, 
		"score": c.score, 
		"cells": _cells(center, size, blocked), 
	}






static func plan(start: Vector3, wild_pos: Vector3, size: Vector2, height_at: Callable, 
		fallback_dir: = Vector3.ZERO, blocked_at: = Callable(), 
		lead_ok: = Callable(), wild_ok: = Callable()) -> Dictionary:
	var level: = float(height_at.call(start.x, start.z))
	var dir: = _axis(wild_pos - start, fallback_dir)
	var blocked: = _blocked(blocked_at, height_at, level)


	var wild_blocked: = blocked_at
	if not wild_blocked.is_valid():
		wild_blocked = func(_x: float, _z: float) -> bool: return false
	var mid: = (start + wild_pos) * 0.5
	mid.y = level

	var sizes: Array = []
	var s: = size
	while s.x >= SIZE_FLOOR and s.y >= SIZE_FLOOR:
		sizes.append(s)
		s -= Vector2(PLACE_STEP * 2.0, PLACE_STEP * 2.0)
	for keep_out in [true, false]:
		for sz in sizes:
			var c: = _best_square(mid, sz, start, dir, level, height_at, blocked, FREE_BAR, keep_out, true, wild_pos, wild_blocked, lead_ok, wild_ok)
			if not c.is_empty():
				return _result(c, level, blocked)

	var fb: = Vector2(FOREST_SIZE, FOREST_SIZE)
	var best: = _best_square(mid, fb, start, dir, level, height_at, blocked, 0.0, true, false, wild_pos, wild_blocked, lead_ok, wild_ok)
	if best.is_empty():
		best = _best_square(mid, fb, start, dir, level, height_at, blocked, 0.0, false, false, wild_pos, wild_blocked, lead_ok, wild_ok)
	if not best.is_empty():
		return _result(best, level, blocked)

	best = {
		"center": Vector3(start.x, level, start.z), "size": fb, "score": 0.0, "dir": dir, 
		"lead_spot": Vector3(start.x, level, start.z), 
		"wild_spot": Vector3(start.x + dir.x * BATTLE_START_GAP, level, start.z + dir.z * BATTLE_START_GAP), 
	}
	return _result(best, level, blocked)












static func _trainer_pair(center: Vector3, size: Vector2, axis: Vector3, blocked: Callable) -> Dictionary:
	var long: float = size.x if absf(axis.x) > absf(axis.z) else size.y
	var half: = long * 0.5 + TRAINER_STAND_OFF
	var c2: = Vector2(center.x, center.z)
	var ax: = Vector2(axis.x, axis.z)


	var a_ok: = func(x: float, z: float) -> bool: return (Vector2(x, z) - c2).dot(ax) >= long * 0.5
	var b_ok: = func(x: float, z: float) -> bool: return (Vector2(x, z) - c2).dot(ax) <= - long * 0.5
	var a: = _snap(center.x + axis.x * half, center.z + axis.z * half, blocked, 4, a_ok)
	var b: = _snap(center.x - axis.x * half, center.z - axis.z * half, blocked, 4, b_ok)
	if not a.is_finite() or not b.is_finite():
		return {}
	if not _line_clear(a, c2, blocked) or not _line_clear(b, c2, blocked):
		return {}
	return {"player_spot": Vector3(b.x, center.y, b.y), "trainer_spot": Vector3(a.x, center.y, a.y)}






static func _trainer_sizes(size: Vector2) -> Array:
	var long0: = int(round(maxf(size.x, size.y)))
	var short0: = int(round(minf(size.x, size.y)))





	var long_floor: = mini(int(SIZE_FLOOR), long0)
	var short_floor: = mini(int(TRAINER_SHORT_FLOOR), short0)
	var out: Array = []
	for lo in range(long0, long_floor - 1, -1):
		for sh in range(mini(short0, lo), short_floor - 1, -1):
			out.append(Vector2(lo, sh))
	out.sort_custom( func(a: Vector2, b: Vector2) -> bool: return a.x * a.y > b.x * b.y)
	return out





static func _best_trainer(mid: Vector3, size: Vector2, start: Vector3, axis: Vector3, level: float, 
		height_at: Callable, blocked: Callable, bar: float, keep_out: bool, strict: bool) -> Dictionary:
	var half: = size * 0.5
	var best: = {}
	var best_score: = -1.0
	var best_d: = INF
	for o in _offsets(SEARCH_RINGS):
		var c: = Vector3(mid.x + o.x * PLACE_STEP, mid.y, mid.z + o.y * PLACE_STEP)
		if keep_out and absf(start.x - c.x) < half.x and absf(start.z - c.z) < half.y:
			continue
		var score: = _free_score(c, size, blocked)
		if score < bar:
			continue
		var d: = float(o.length_squared())
		if best_score >= 0.0 and score <= best_score * 1.05 and d >= best_d:
			continue
		var pair: = _trainer_pair(c, size, axis, blocked)
		if pair.is_empty():
			continue
		if strict and not _flat(c, size, level, height_at):
			continue
		best = {"center": c, "size": size, "score": score}
		best.merge(pair)
		best_score = score
		best_d = d
		if score >= 0.999:
			break
	return best


static func _trainer_result(c: Dictionary, axis: Vector3, level: float, blocked: Callable) -> Dictionary:
	var center: Vector3 = c.center
	var size: Vector2 = c.size
	return {
		"level": level, 
		"center": center, 
		"size": size, 
		"rect": Rect2(center.x - size.x * 0.5, center.z - size.y * 0.5, size.x, size.y), 
		"axis": axis, 
		"player_spot": c.player_spot, 
		"trainer_spot": c.trainer_spot, 
		"score": c.score, 
		"cells": _cells(center, size, blocked), 
	}







static func plan_trainer(start: Vector3, trainer_pos: Vector3, size: Vector2, height_at: Callable, 
		fallback_dir: = Vector3.ZERO, blocked_at: = Callable()) -> Dictionary:
	var level: = float(height_at.call(start.x, start.z))
	var blocked: = _blocked(blocked_at, height_at, level)
	var mid: = (start + trainer_pos) * 0.5
	mid.y = level
	var primary: = _axis(trainer_pos - start, fallback_dir)
	var sizes: = _trainer_sizes(size)
	var axes: = [primary, _axis(Vector3( - primary.z, 0.0, primary.x))]


	for keep_out in [true, false]:
		for sz in sizes:
			for axis in axes:
				var rs: Vector2 = sz if absf(axis.x) > absf(axis.z) else Vector2(sz.y, sz.x)
				var c: = _best_trainer(mid, rs, start, axis, level, height_at, blocked, FREE_BAR, keep_out, true)
				if not c.is_empty():
					return _trainer_result(c, axis, level, blocked)
	for axis in axes:
		var fb: = Vector2(FOREST_SIZE, FOREST_SIZE)
		var best: = _best_trainer(mid, fb, start, axis, level, height_at, blocked, 0.0, true, false)
		if best.is_empty():
			best = _best_trainer(mid, fb, start, axis, level, height_at, blocked, 0.0, false, false)
		if not best.is_empty():
			return _trainer_result(best, axis, level, blocked)


	var rs0: Vector2 = size if absf(primary.x) > absf(primary.z) else Vector2(size.y, size.x)
	var half0: float = maxf(rs0.x, rs0.y) * 0.5 + TRAINER_STAND_OFF
	var t0: = _snap(start.x + primary.x * half0, start.z + primary.z * half0, blocked, 4)
	if not t0.is_finite():
		t0 = Vector2(trainer_pos.x, trainer_pos.z)
	var c0: = {"center": Vector3(start.x, level, start.z), "size": rs0, "score": 0.0, 
		"player_spot": Vector3(start.x, level, start.z), 
		"trainer_spot": Vector3(t0.x, level, t0.y)}
	return _trainer_result(c0, primary, level, blocked)




static func debug_mesh(pl: Dictionary) -> MeshInstance3D:
	var im: = ImmediateMesh.new()
	im.surface_begin(Mesh.PRIMITIVE_TRIANGLES)
	for cell in pl.get("cells", []):
		var p: Vector2 = cell.pos
		var col: = Color(0.15, 0.95, 0.25, 0.55) if cell.free else Color(0.95, 0.1, 0.05, 0.8)
		_quad(im, Vector3(p.x, float(pl.level) + 0.05, p.y), 0.92, col)
	for key in ["lead_spot", "wild_spot"]:
		var s: Vector3 = pl[key]
		_quad(im, Vector3(s.x, s.y + 0.08, s.z), 1.6, Color(1.0, 0.9, 0.2, 0.85))
	im.surface_end()
	var mi: = MeshInstance3D.new()
	mi.mesh = im
	mi.top_level = true
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	var mat: = StandardMaterial3D.new()
	mat.vertex_color_use_as_albedo = true
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	mi.material_override = mat
	return mi



static func _quad(im: ImmediateMesh, c: Vector3, s: float, col: Color) -> void :
	var h: = s * 0.5
	im.surface_set_color(col)
	for v in [Vector3( - h, 0, - h), Vector3( - h, 0, h), Vector3(h, 0, h), 
			Vector3( - h, 0, - h), Vector3(h, 0, h), Vector3(h, 0, - h)]:
		im.surface_add_vertex(c + v)









static func border_gap(rect: Rect2, p: Vector2) -> float:
	return minf(minf(p.x - rect.position.x, rect.end.x - p.x), 
		minf(p.y - rect.position.y, rect.end.y - p.y))



static func on_border(rect: Rect2, p: Vector2, width: = BORDER_WIDTH) -> bool:
	if rect.size.x <= 0.0 or rect.size.y <= 0.0:
		return false
	var g: = border_gap(rect, p)
	return g <= width and g >= - width * BORDER_EDGE



static func border_inward(rect: Rect2, p: Vector2) -> Vector2:
	var w: = p.x - rect.position.x
	var e: = rect.end.x - p.x
	var n: = p.y - rect.position.y
	var s: = rect.end.y - p.y
	var m: float = minf(minf(w, e), minf(n, s))
	if m == w:
		return Vector2.RIGHT
	if m == e:
		return Vector2.LEFT
	if m == n:
		return Vector2(0, 1)
	return Vector2(0, -1)






static func thunder_touch(rect: Rect2, p: Vector2, width: float, max_hp: int, types: Array, 
		lock: float) -> Dictionary:
	if lock > 0.0 or not on_border(rect, p, width):
		return {}
	var electric: = types.has("electric")
	var damage: = 0 if electric else roundi(max_hp * BORDER_DAMAGE)
	var paralysis: = not electric and not types.has("ground")
	return {
		"damage": damage, 
		"paralysis": paralysis, 
		"push": border_inward(rect, p) * BORDER_PUSH, 
		"lock": BORDER_LOCKOUT, 
	}




static func knock_hits_border(rect: Rect2, from: Vector2, foe: Vector2, kb: float, 
		width: = BORDER_WIDTH, reach: = 1.2) -> bool:
	var d: = foe - from
	if d.length() < 0.05 or kb <= 0.0:
		return false
	return on_border(rect, foe + d.normalized() * kb, width + reach)




static func border_stop(rect: Rect2, from: Vector2, dir: Vector2, reach: float, 
		width: = BORDER_WIDTH) -> float:
	var step: = 0.25
	var d: = Vector2(dir.x, dir.y).normalized()
	var t: = step
	while t < reach:
		if on_border(rect, from + d * t, width):
			return t
		t += step
	return reach




func _build_border(sz: Vector2, width: float) -> void :
	var im: = ImmediateMesh.new()
	im.surface_begin(Mesh.PRIMITIVE_TRIANGLES)

	var out: = width * BORDER_EDGE
	_band(im, Rect2( - sz.x * 0.5 - out, - sz.y * 0.5 - out, sz.x + out * 2.0, sz.y + out * 2.0), 
		width + out, Color(0.3, 0.7, 1.0, 0.45))

	_band(im, Rect2( - sz.x * 0.5 - 0.09, - sz.y * 0.5 - 0.09, sz.x + 0.18, sz.y + 0.18), 
		0.18, Color(0.88, 0.98, 1.0, 1.0))


	var rng: = RandomNumberGenerator.new()
	rng.seed = 63
	var hx: = sz.x * 0.5
	var hz: = sz.y * 0.5
	var arc: = Color(0.75, 0.93, 1.0, 0.95)
	for side in 4:
		for n in 4:
			var t: = (n + 0.5) / 4.0
			var a: Vector3
			var b: Vector3
			if side == 0 or side == 1:
				var z: = - hz if side == 0 else hz
				a = Vector3(lerpf( - hx, hx, t), 0.02, z)
				b = a + Vector3(rng.randf_range(-0.35, 0.35), 0.0, 0.35 if side == 0 else -0.35)
			else:
				var x: = - hx if side == 2 else hx
				a = Vector3(x, 0.02, lerpf( - hz, hz, t))
				b = a + Vector3(0.35 if side == 2 else -0.35, 0.0, rng.randf_range(-0.35, 0.35))
			_bolt(im, a, b, arc)
	im.surface_end()
	_border_mesh = MeshInstance3D.new()
	_border_mesh.name = "ThunderBorder"
	_border_mesh.mesh = im
	_border_mesh.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	_border_mat = StandardMaterial3D.new()
	_border_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	_border_mat.vertex_color_use_as_albedo = true
	_border_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	_border_mat.emission_enabled = true
	_border_mat.emission = BORDER_COLOR
	_border_mat.emission_energy_multiplier = 1.6
	_border_mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	_border_mat.render_priority = 1
	_border_mesh.material_override = _border_mat
	_border_mesh.position = Vector3(0, QUAD_LIFT + 0.01, 0)
	add_child(_border_mesh)
	_pulse()



func _band(im: ImmediateMesh, r: Rect2, w: float, col: Color) -> void :
	var y: = 0.0
	var x0: = r.position.x
	var x1: = r.end.x
	var z0: = r.position.y
	var z1: = r.end.y
	_quad_col(im, Vector3(x0, y, z0), Vector3(x1, y, z0 + w), col)
	_quad_col(im, Vector3(x0, y, z1 - w), Vector3(x1, y, z1), col)
	_quad_col(im, Vector3(x0, y, z0), Vector3(x0 + w, y, z1), col)
	_quad_col(im, Vector3(x1 - w, y, z0), Vector3(x1, y, z1), col)



func _quad_col(im: ImmediateMesh, a: Vector3, b: Vector3, col: Color) -> void :
	im.surface_set_color(col)
	for v in [Vector3(a.x, a.y, a.z), Vector3(a.x, a.y, b.z), Vector3(b.x, a.y, b.z), 
			Vector3(a.x, a.y, a.z), Vector3(b.x, a.y, b.z), Vector3(b.x, a.y, a.z)]:
		im.surface_add_vertex(v)



func _bolt(im: ImmediateMesh, a: Vector3, b: Vector3, col: Color) -> void :
	var n: = 3
	var pts: Array = [a]
	var side: = (b - a).normalized().cross(Vector3.UP) * 0.05
	for i in range(1, n):
		var t: = float(i) / n
		var jog: = side * (1.0 if i % 2 == 1 else -1.0) * 3.0
		pts.append(a.lerp(b, t) + Vector3(jog.x, 0.0, jog.z))
	pts.append(b)
	for i in pts.size() - 1:
		var p0: Vector3 = pts[i]
		var p1: Vector3 = pts[i + 1]
		im.surface_set_color(col)
		for v in [p0 - side, p0 + side, p1 + side, p0 - side, p1 + side, p1 - side]:
			im.surface_add_vertex(v)



func _pulse() -> void :
	if _border_mat == null or not is_inside_tree():
		return
	var tw: = create_tween().set_loops()
	tw.tween_property(_border_mat, "emission_energy_multiplier", 2.3, 0.9)
	tw.tween_property(_border_mat, "emission_energy_multiplier", 1.3, 0.9)




func thunder_flash(_at: = Vector3.INF) -> void :
	if _border_mat == null:
		return
	set_meta("thunder_flashes", int(get_meta("thunder_flashes", 0)) + 1)
	if not is_inside_tree():
		return


	var tw: = create_tween().set_parallel(true)
	tw.tween_property(_border_mat, "albedo_color", Color(1.45, 1.6, 1.8, 1.0), 0.05)
	tw.tween_property(_border_mat, "emission_energy_multiplier", 3.2, 0.06)
	tw.chain().tween_property(_border_mat, "albedo_color", Color.WHITE, 0.3)
	tw.tween_property(_border_mat, "emission_energy_multiplier", 1.6, 0.3)


func close() -> void :
	var tw: = create_tween()
	tw.tween_property(_marker(), _fade_prop(), 0.0, 0.35)
	tw.tween_callback(queue_free)

"""Build a separate campaign LAN installation from verified PBA 0.6.2a."""
from pathlib import Path
import argparse,hashlib,json,mmap,shutil,os,datetime
from packtools import patch,read_index,resource,sha256
HERE=Path(__file__).resolve().parent
PACK_HASH='0fefbd8092f041d74f628e99eae8eb80bd3f141c0a644a24cf6c7f00e92d81f7'
ORIGINAL_HASH='ad34adbe2e8ea337517d012eb7f8158ce9bc70f74ae38819ae4045273ffbbcb0'
EXE_HASH='3942b4c9d26655d0184ebe739d5d063f1893b5dd668ab4a0fa01166a2b852254'

def changes():
    paths={'scripts/front/front_end.gdc':'front_end','scripts/trainer.gdc':'trainer',
           'scripts/battle.gdc':'battle','scripts/combat/combatant.gdc':'combatant','scripts/encounters.gdc':'encounters',
           'scripts/state/save_game.gdc':'save_game','coop/campaign.gdc':'campaign','coop/arena.gdc':'arena','coop/persistence.gdc':'persistence','scripts/stats/mon.gdc':'mon','scripts/ui/minimap.gdc':'minimap','scripts/world/weather.gdc':'weather'}
    out={path:(HERE/'payload'/(name+'.gdc')).read_bytes() for path,name in paths.items()}
    out.update({'coop/persistence.gd.remap':b'[remap]\npath="res://coop/persistence.gdc"\n', 'coop/campaign.gd.remap':b'[remap]\npath="res://coop/campaign.gdc"\n',
                'coop/arena.gd.remap':b'[remap]\npath="res://coop/arena.gdc"\n',
                'coop/arena.tscn':(HERE/'src/arena.tscn').read_bytes()})
    return out

def find_source():
    for d in [HERE,HERE.parent]:
        if (d/'PokemonBattleAdvanced.exe').is_file() and any((d/f).is_file() for f in ['PokemonBattleAdvanced.mod.pck','PokemonBattleAdvanced.pck']):return d
    raise ValueError('Jogo nao encontrado. Use --origem "PASTA_DO_JOGO_ORIGINAL".')

def migration_files(root):
    """Take immutable snapshots while respecting the S3 launcher's profile lock."""
    if root is None or not (root/'userdata').is_dir():return {}
    import msvcrt
    result={}
    for profile in (root/'userdata').iterdir():
        if not profile.is_dir() or profile.name=='solo':continue
        directory=profile/'Godot/app_userdata/Pokémon Battle Advanced/coop_s3'
        if not directory.is_dir():continue
        lock=None
        try:
            lockpath=profile/'profile.lock'
            if lockpath.exists():
                lock=lockpath.open('r+b');lock.seek(0)
                try:msvcrt.locking(lock.fileno(),msvcrt.LK_NBLCK,1)
                except OSError:raise ValueError('Feche a instalacao anterior antes de migrar o perfil '+profile.name)
            candidates={name:(directory/name).read_bytes() for name in ['profile.json','profile.json.bak'] if (directory/name).is_file()}
            good=False
            for raw in candidates.values():
                try:
                    doc=json.loads(raw);payload=doc.get('payload','')
                    if int(doc.get('schema',0))>1:raise ValueError('Perfil de versao futura; migracao interrompida.')
                    if doc.get('schema')==1 and hashlib.sha256(payload.encode('utf8')).hexdigest()==doc.get('sha256'):
                        data=json.loads(payload)
                        good=good or isinstance(data.get('snapshot',{}).get('state'),dict)
                except (json.JSONDecodeError,UnicodeError,TypeError,AttributeError):pass
            if candidates and not good:raise ValueError('Perfil anterior invalido: '+profile.name+'. Preserve os arquivos para recuperacao.')
            for name,raw in candidates.items():result[Path('userdata')/profile.name/'Godot/app_userdata/Pokémon Battle Advanced/coop_s3'/name]=raw
        finally:
            if lock is not None:lock.close()
    return result

def install(source,target,previous=None):
    source,target=source.resolve(),target.resolve()
    pack=source/'PokemonBattleAdvanced.mod.pck'
    if not pack.is_file():pack=source/'PokemonBattleAdvanced.pck'
    exe=source/'PokemonBattleAdvanced.exe'
    if not exe.is_file() or not pack.is_file():raise ValueError('Origem precisa do EXE e PCK da build original.')
    input_hash=sha256(pack)
    if input_hash not in [PACK_HASH,ORIGINAL_HASH] or sha256(exe)!=EXE_HASH:
        raise ValueError('Build desconhecida ou ja modificada. Use a pasta original 0.6.2a, nunca um PCK LAN.')
    if target.exists():raise ValueError('Destino ja existe. Escolha --destino "PASTA_NOVA" para preservar arquivos e saves.')
    manifest=json.loads((HERE/'payload/manifest.json').read_text(encoding='utf8'))
    for name,digest in manifest.items():
        if sha256(HERE/name)!=digest:raise ValueError('Payload corrompido: '+name)
    for dll in ['discord_game_sdk.dll','libdiscord_game_sdk_binding.dll','libwebrtc_native.windows.template_release.x86_64.dll']:
        if not (source/dll).is_file():raise ValueError('Falta arquivo da exportacao original: '+dll)
    migrated=migration_files(previous if previous is not None else source/'PBA-Coop-S03')
    target.mkdir(parents=True)
    # The normal game saves remain untouched; take a local backup before installing.
    personal=Path(os.environ.get('APPDATA',''))/'Godot/app_userdata/Pokémon Battle Advanced'
    if os.environ.get('APPDATA') and personal.is_dir():
        found=[f for f in personal.glob('save*.json') if f.is_file()]
        found += [personal/n for n in ['key_bindings.cfg','settings.cfg'] if (personal/n).is_file()]
        if found:
            d=target/'save_backups'/('preinstall-'+datetime.datetime.now().strftime('%Y%m%d-%H%M%S'))
            d.mkdir(parents=True)
            for f in found:shutil.copy2(f,d/f.name)
    backup=target/'PokemonBattleAdvanced.before-coop.pck'
    if input_hash==ORIGINAL_HASH:
        with pack.open('rb') as f,mmap.mmap(f.fileno(),0,access=mmap.ACCESS_READ) as m:
            base,index=read_index(m)
            shops=json.loads(resource(m,base,index,'data/shops.json'))
        shops['viridian'].append('thunder_stone')
        patch(pack,backup,{'data/shops.json':(json.dumps(shops,ensure_ascii=False,indent=2)+'\n').encode('utf8')})
    else:shutil.copy2(pack,backup)
    if sha256(backup)!=PACK_HASH:raise ValueError('Base com Thunder Stone nao confere.')
    patch(backup,target/'PokemonBattleAdvanced.pck',changes())
    modified=changes()
    with backup.open('rb') as a,(target/'PokemonBattleAdvanced.pck').open('rb') as b:
        with mmap.mmap(a.fileno(),0,access=mmap.ACCESS_READ) as x,mmap.mmap(b.fileno(),0,access=mmap.ACCESS_READ) as y:
            bx,ix=read_index(x);by,iy=read_index(y)
            for path in ix:
                if path not in modified and resource(x,bx,ix,path)!=resource(y,by,iy,path):
                    raise ValueError('Recurso original alterado: '+path)
            assert json.loads(resource(y,by,iy,'data/species.json'))['Haunter']['evolution']=={'method':'trade','into':'Gengar'}
            assert 'thunder_stone' in json.loads(resource(y,by,iy,'data/shops.json'))['viridian']
    for name in ['PokemonBattleAdvanced.exe','discord_game_sdk.dll','libdiscord_game_sdk_binding.dll','libwebrtc_native.windows.template_release.x86_64.dll']:
        shutil.copy2(source/name,target/name)
    for folder,names in [('addons/discord-rpc-gd/bin/windows',['discord_game_sdk.dll','libdiscord_game_sdk_binding.dll']),('addons/webrtc_native/lib',['libwebrtc_native.windows.template_release.x86_64.dll'])]:
        d=target/folder;d.mkdir(parents=True)
        for name in names:shutil.copy2(source/name,d/name)
    for name in ['iniciar_campanha.py','restaurar.py','packtools.py']:
        shutil.copy2(HERE/name,target/name)
    (target/'COOPERATIVO.bat').write_text('@echo off\ncd /d "%~dp0"\npython iniciar_campanha.py menu\n',encoding='ascii')
    for role in ['host','guest','solo']:
        (target/(role+'.bat')).write_bytes(('@echo off\r\ncd /d "%~dp0"\r\npython iniciar_campanha.py '+role+' %*\r\nif errorlevel 1 pause\r\n').encode('ascii'))
    record={'version':'campaign-lan-v13-s03fix','source':str(source),'input_pack_sha256':input_hash,'source_pack_sha256':PACK_HASH,
            'exe_sha256':EXE_HASH,'coop_pack_sha256':sha256(target/'PokemonBattleAdvanced.pck'),
            'changes':list(changes()),'preserved_resources':len(ix)-len(set(ix).intersection(changes()))}
    for relative,raw in migrated.items():
        dest=target/relative;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw)
    record['migrated_files']=[str(p) for p in migrated]
    (target/'installation.json').write_text(json.dumps(record,indent=2),encoding='utf8')
    for name in ['GUIA_FIX.md','RELATORIO_FIX.md']:
        if (HERE/name).is_file():shutil.copy2(HERE/name,target/name)
    if (HERE/'docs').is_dir():shutil.copytree(HERE/'docs',target/'docs')
    print('Instalado:',target)
    print('Campanha host: python iniciar_campanha.py host')
    print('Campanha convidado: python iniciar_campanha.py guest IP_RADMIN')
    print('Solo: python iniciar_campanha.py solo')
    return record

if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--origem',type=Path);ap.add_argument('--destino',type=Path);ap.add_argument('--migrar-de',type=Path)
    args=ap.parse_args()
    try:
        source=args.origem if args.origem else find_source()
        install(source,args.destino if args.destino else source/'PBA-Coop-S03-Fix',args.migrar_de)
    except (OSError,ValueError,KeyError) as error:raise SystemExit('Instalacao interrompida: '+str(error))

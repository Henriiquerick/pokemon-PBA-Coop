class_name PkPartyRing
extends Control




signal picked(slot: int)
signal held(slot: int)
signal closed

const PokemonSprites: = preload("res://scripts/pokemon_sprites.gd")
const UI: = preload("res://scripts/ui/ui_draw.gd")
const PpWarning: = preload("res://scripts/ui/pp_warning.gd")
const HOLD_SECS: = 0.4
const RADIUS: = 165.0
const SLOT_R: = 44.0
const ICON_PX: = 72

var is_open: = false
var mode: = "overworld"
var highlight: = 0


var target: = 0
var show_target: = false


var pick_mode: = false

var _legend: PkHintBar
var _legend_sig: = -1

var _hold_slot: = -1
var _hold_t: = 0.0
var _t: = 0.0






func hold_supports() -> bool:
	if not Battle.in_battle:
		return false
	if pick_mode:
		return Battle.pick_sup_ok and Battle._pick_sup < 0
	return Battle.trainer_battle.is_empty() and not Battle.challenge and not Battle.is_spar()


func _init() -> void :
	mouse_filter = Control.MOUSE_FILTER_STOP
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	visible = false
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	UiKit.connect_version(queue_redraw)
	_legend = PkHintBar.new()
	_legend.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_legend)


func open(m: String, pick_target: = false) -> void :
	if Battle.is_spar():
		return
	var lan = get_node_or_null("/root/LanCampaign")
	if Battle.challenge and not BattleTower.is_rental(BattleTower.current) and not (lan != null and lan.coop_battle_active()):
		return
	mode = m
	show_target = pick_target
	target = 0
	is_open = true
	visible = true
	highlight = 0
	_hold_slot = -1
	queue_redraw()
	_refresh_legend()



func open_pick() -> void :
	open("battle")
	pick_mode = true
	_refresh_legend()
	for i in 6:
		if Battle.pick_eligible(i):
			highlight = i
			break



func _refresh_legend() -> void :

	var send: Array = [["1-6", "Send out"]]
	var support: Array = [["Hold 1-6", "Supporter"], ["Shift+1-6", "Supporter"]]
	if Controls.is_touch():
		send = [["Tap", "Send out"]]
		support = [["Hold", "Supporter"]]
	elif Controls.is_pad():
		send = [[["pk_ok"], "Send out"]]
		support = [["Hold " + Controls.key_label("pk_ok"), "Supporter"]]
	var hints: Array = send
	if pick_mode:

		if Battle.pick_sup_ok and Battle._pick_sup < 0:
			hints = []
			for h in support:
				hints.append([h[0], "1st: supporter (optional)"])
			hints.append_array([[send[0][0], "then: send out"]])
		elif Battle._pick_sup >= 0:
			hints = [[send[0][0], "Send out your lead"]]
	elif mode == "battle" and Battle.trainer_battle.is_empty():
		hints = send + support
	_legend.set_hints(hints)
	_legend.reset_size()
	_legend.position = Vector2((size.x - _legend.size.x) * 0.5, size.y - 104.0)
	_legend_sig = Battle._pick_sup


func close() -> void :
	if not is_open:
		return
	is_open = false
	pick_mode = false
	visible = false
	_hold_slot = -1
	closed.emit()


func _process(delta: float) -> void :
	if not is_open:
		return
	_t += delta
	if pick_mode and _legend_sig != Battle._pick_sup:
		_refresh_legend()
	if Input.is_action_just_pressed("pk_back") and not pick_mode:
		close()
		return
	if Controls.is_pad():


		var stick: = Input.get_vector("move_left", "move_right", "move_up", "move_down")
		for pad in Input.get_connected_joypads():
			var rs: = Vector2(Input.get_joy_axis(pad, JOY_AXIS_RIGHT_X), Input.get_joy_axis(pad, JOY_AXIS_RIGHT_Y))
			if rs.length() > stick.length():
				stick = rs
		if stick.length() > 0.5:
			highlight = _slot_from_dir(stick)
		if Input.is_action_just_released("party_ring"):
			_press(highlight)
			_release()
			return
	else:
		if Input.is_action_just_pressed("pk_left") or Input.is_action_just_pressed("pk_up"):
			highlight = _step(-1)
		if Input.is_action_just_pressed("pk_right") or Input.is_action_just_pressed("pk_down"):
			highlight = _step(1)
	if Input.is_action_just_pressed("pk_ok"):
		_press(highlight)
	if Input.is_action_just_released("pk_ok"):
		_release()
	if _hold_slot >= 0:
		_hold_t += delta
		if _hold_t >= HOLD_SECS:
			var s: = _hold_slot
			_hold_slot = -1
			if hold_supports():
				held.emit(s)
			else:
				picked.emit(s)
	queue_redraw()



func _slot_from_dir(v: Vector2) -> int:
	var ang: = atan2(v.y, v.x)
	var best: = 0
	var best_d: = 999.0
	for i in 6:
		var a: = - PI * 0.5 + TAU * float(i) / 6.0
		var d: = absf(angle_difference(a, ang))
		if d < best_d - 1e-06:
			best_d = d
			best = i
	return best



func _step(dir: int) -> int:
	var h: = highlight
	for _i in 6:
		h = (h + dir + 6) % 6
		if not pick_mode or Battle.pick_eligible(h):
			return h
	return highlight


func _press(slot: int) -> void :
	if pick_mode and not Battle.pick_eligible(slot):
		return
	_hold_slot = slot
	_hold_t = 0.0


func _release() -> void :
	if _hold_slot >= 0:
		var s: = _hold_slot
		_hold_slot = -1
		picked.emit(s)






func slot_at(gp: Vector2) -> int:
	return _slot_at(gp)



func press_slot(i: int) -> void :
	if i < 0:
		return
	highlight = i
	_press(i)



func release_slot() -> void :
	_release()






func target_rect() -> Rect2:
	var s: = Vector2(190, 46)
	return Rect2(size * 0.5 - s * 0.5, s)


func target_at(p: Vector2) -> bool:
	return target_rect().has_point(p)


func toggle_target() -> void :
	target = 1 - target
	queue_redraw()



func _target_label() -> String:
	if target == 1:
		var a = Battle.ai_ally()
		var n: = "ALLY"
		if is_instance_valid(a) and a.mon != null:
			n = String(a.mon.display_name)
		return "ALLY: " + n
	var p = Battle.partner
	var y: = "YOUR FIGHTER"
	if is_instance_valid(p) and p.mon != null:
		y = String(p.mon.display_name)
	return "YOU: " + y




func _gui_input(e: InputEvent) -> void :
	if not is_open:
		return

	if Controls.is_touch():
		return
	if e is InputEventMouseButton and e.button_index == MOUSE_BUTTON_LEFT:
		if e.pressed:
			if show_target and target_at(e.position):
				toggle_target()
				return
			var slot: = _slot_at(e.position)
			if slot >= 0:
				highlight = slot
				_press(slot)
		else:
			_release()
	elif e is InputEventMouseMotion and _hold_slot < 0:
		var slot: = _slot_at(e.position)
		if slot >= 0:
			highlight = slot


func _slot_at(p: Vector2) -> int:
	for i in 6:
		if p.distance_to(_slot_center(i)) <= SLOT_R:
			return i
	return -1


func _slot_center(i: int) -> Vector2:
	var a: = - PI * 0.5 + TAU * float(i) / 6.0
	return size * 0.5 + Vector2(cos(a), sin(a)) * RADIUS



func _pp_ratio(i: int, mon) -> float:
	if Battle.in_battle and Game.is_out(i):
		var c = Game.companions[i]
		if is_instance_valid(c) and Battle.allies.has(c):
			return PpWarning.pp_ratio(float(c.pp_max), float(c.pp_base))
	return PpWarning.pp_ratio(float(mon.pp), float(mon.pp_base))




func _draw() -> void :
	if not is_open:
		return
	draw_rect(Rect2(Vector2.ZERO, size), Color(0, 0, 0, 0.35))
	draw_arc(size * 0.5, RADIUS, 0.0, TAU, 64, Color(UiKit.INK, 0.45), 6.0, true)
	for i in 6:
		_draw_slot(i, _slot_center(i))
	if show_target:
		_draw_target()
	if pick_mode:
		_draw_pick_header()
	var cap: = int(Battle.trainer_battle.get("roster", 0))
	if Battle.in_battle and cap > 0:
		var used: int = (Battle.trainer_battle.get("used", []) as Array).size()
		var msg: = "GYM RULE: MAX %d POKÉMON  (%d/%d chosen)" % [cap, used, cap]
		var pc: = size * 0.5 + Vector2(0, - RADIUS - 62.0)
		UI.rounded(self, Rect2(pc + Vector2(-190, -17), Vector2(380, 32)), Color(UiKit.INK, 0.85), 10, 2.0, UiKit.AMBER)
		UI.text_center(self, pc + Vector2(0, 5), msg, 16, UiKit.AMBER, 0)
		if used >= cap:
			UI.text_center(self, pc + Vector2(0, 30), "Only your chosen fighters may switch in", 12, UiKit.PAPER, 2)



func _draw_pick_header() -> void :
	var c: = size * 0.5
	var title: = "CHOOSE A POKÉMON"
	if Battle._pick_sup >= 0:
		title = "NOW YOUR LEAD"
	UI.text_center(self, c + Vector2(0, -8), title, 19, UiKit.PAPER, 3)
	var w: = 190.0
	var r: = Rect2(c + Vector2( - w * 0.5, 14), Vector2(w, 12))
	var f: = clampf(Battle.pick_left / Battle.PICK_SECS, 0.0, 1.0)
	UI.rounded(self, r, Color(UiKit.INK, 0.8), 6)
	UI.rounded(self, Rect2(r.position, Vector2(w * f, r.size.y)), UiKit.AMBER if f > 0.3 else Color("e0503c"), 6)
	UI.text_center(self, c + Vector2(0, 44), "%d" % ceili(Battle.pick_left), 16, UiKit.PAPER, 2)



func _draw_target() -> void :
	var r: = target_rect()
	UI.rounded(self, Rect2(r.position + Vector2(0, 3), r.size), Color(0, 0, 0, 0.35), 12)
	UI.rounded(self, r, Color(UiKit.INK, 0.8), 12, 2.0, UiKit.AMBER)
	draw_string(UiKit.body_font(), Vector2(r.position.x, r.position.y - 6.0), "REPLACE", 
		HORIZONTAL_ALIGNMENT_CENTER, r.size.x, 12, Color(UiKit.PAPER, 0.7))
	UI.text_center(self, r.get_center() + Vector2(0, 5), _target_label(), 15, UiKit.PAPER, 3)


func _draw_slot(i: int, c: Vector2) -> void :
	var has_mon: = i < Game.party.size()
	var mon = Game.party[i] if has_mon else null
	var fainted: bool = has_mon and mon.hp <= 0
	if i == highlight:
		draw_arc(c, SLOT_R + 8.0, 0.0, TAU, 48, UiKit.accent(), 4.0, true)
	draw_circle(c, SLOT_R, Color(UiKit.INK, 0.72))
	if not has_mon:
		return
	var ratio: = clampf(float(mon.hp) / maxf(float(mon.max_hp), 1.0), 0.0, 1.0)
	UiKit.draw_ring(self, c, SLOT_R, 5.0, ratio, UiKit.hp_color(ratio), Color(UiKit.INK, 0.55))

	UiKit.draw_ring(self, c, SLOT_R - 8.0, 3.5, _pp_ratio(i, mon), UiKit.PP_BLUE, Color(UiKit.INK, 0.45))
	var tint: = PokemonSprites.tint(mon.species, mon.shiny)
	var barred: bool = Battle.in_battle and not Battle.roster_ok(mon)
	if fainted or barred or (pick_mode and not Battle.pick_eligible(i)):
		tint = Color(0.4, 0.4, 0.4)
	var d: = SLOT_R * 0.72
	draw_texture_rect(PokemonSprites.disc_icon(mon.art_species, ICON_PX, 0.85, mon.shiny), 
		Rect2(c - Vector2(d, d), Vector2(d, d) * 2.0), false, tint)
	var f: = UiKit.body_font()
	draw_string(f, c + Vector2( - SLOT_R - 10.0, SLOT_R + 20), String(mon.display_name), 
		HORIZONTAL_ALIGNMENT_CENTER, SLOT_R * 2.0 + 20.0, 14, UiKit.PAPER)
	if pick_mode and Battle._pick_sup == i:
		var t: = Rect2(c + Vector2(-34.0, SLOT_R + 26.0), Vector2(68, 17))
		UI.rounded(self, t, UiKit.AMBER, 8, 2.0, Color(UiKit.INK, 0.9))
		UI.text_center(self, t.get_center() + Vector2(0, 4), "SUPPORTER", 11, UiKit.INK, 0)
	if mon.default_wild or mon.default_assist:
		var dt: = Rect2(c + Vector2(SLOT_R - 36.0, - SLOT_R - 8.0), Vector2(46, 15))
		UI.rounded(self, dt, UiKit.AMBER, 7, 2.0, Color(UiKit.INK, 0.9))
		UI.text_center(self, dt.get_center() + Vector2(0, 4), "WILD" if mon.default_wild else "ASSIST", 10, UiKit.INK, 0)

	var k: = Rect2(c + Vector2( - SLOT_R - 4.0, - SLOT_R - 4.0), Vector2(24, 24))
	var live: = not pick_mode or Battle.pick_eligible(i)
	UI.rounded(self, Rect2(k.position + Vector2(0, 2), k.size), Color(0, 0, 0, 0.4), 6)
	UI.rounded(self, k, Color(UiKit.PAPER, 0.95 if live else 0.45), 6, 2.0, Color(UiKit.INK, 0.9))
	UI.text_center(self, k.get_center() + Vector2(0, 5), str(i + 1), 15, UiKit.INK)

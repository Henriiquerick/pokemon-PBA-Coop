﻿$ErrorActionPreference='Stop'
$record=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'installation.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$backup=Join-Path $PSScriptRoot 'PokemonBattleAdvanced.before-coop.pck'
$target=Join-Path $PSScriptRoot 'PokemonBattleAdvanced.pck'
$hash=(Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash.ToLowerInvariant()
if($hash -notin @($record.coop_pack_sha256,$record.source_pack_sha256)) { throw 'PCK atual desconhecido; nada foi alterado.' }
if((Get-FileHash -LiteralPath $backup -Algorithm SHA256).Hash.ToLowerInvariant() -ne $record.source_pack_sha256) { throw 'Backup invalido; nada foi alterado.' }
[IO.File]::Copy($backup,$target,$true)
Write-Host 'PCK anterior restaurado. Saves preservados. Use o EXE diretamente.'

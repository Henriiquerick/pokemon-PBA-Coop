﻿param([string]$Origem='', [string]$Destino='', [string]$MigrarDe='')
$ErrorActionPreference='Stop'
function Hash-Arquivo([string]$Path) { (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant() }
function Hash-Texto([string]$Value) {
    $sha=[Security.Cryptography.SHA256]::Create()
    try { -join ($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($Value)) | ForEach-Object { $_.ToString('x2') }) } finally { $sha.Dispose() }
}
function Aplicar-Cauda([string]$Path,[string]$Tail,[UInt64]$Directory) {
    $out=[IO.File]::Open($Path,[IO.FileMode]::Open,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
    try {
        [void]$out.Seek(0,[IO.SeekOrigin]::End)
        $deltaStream=[IO.File]::OpenRead($Tail)
        try { $deltaStream.CopyTo($out) } finally { $deltaStream.Dispose() }
        [void]$out.Seek(32,[IO.SeekOrigin]::Begin)
        $bytes=[BitConverter]::GetBytes($Directory);$out.Write($bytes,0,8);$out.Flush($true)
    } finally { $out.Dispose() }
}
try {
    $meta=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'distribuicao.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    foreach($record in $meta.files.PSObject.Properties) {
        if((Hash-Arquivo (Join-Path $PSScriptRoot $record.Name)) -ne $record.Value) { throw "Arquivo do patch corrompido: $($record.Name)" }
    }
    if(!$Origem) {
        foreach($candidate in @($PSScriptRoot,(Split-Path $PSScriptRoot),(Split-Path (Split-Path $PSScriptRoot)))) {
            if(Test-Path -LiteralPath (Join-Path $candidate 'PokemonBattleAdvanced.exe')) { $Origem=$candidate;break }
        }
    }
    if(!$Origem) {
        Add-Type -AssemblyName System.Windows.Forms
        $picker=New-Object Windows.Forms.FolderBrowserDialog
        $picker.Description='Selecione a pasta ORIGINAL do Pokemon Battle Advanced 0.6.2a (EXE e PCK).'
        if($picker.ShowDialog() -ne [Windows.Forms.DialogResult]::OK) { return }
        $Origem=$picker.SelectedPath
    }
    $Origem=(Resolve-Path -LiteralPath $Origem).Path
    $exe=Join-Path $Origem 'PokemonBattleAdvanced.exe'
    $pack=Join-Path $Origem 'PokemonBattleAdvanced.mod.pck'
    if(!(Test-Path -LiteralPath $pack)) { $pack=Join-Path $Origem 'PokemonBattleAdvanced.pck' }
    if((Hash-Arquivo $exe) -ne $meta.exe_sha256) { throw 'EXE desconhecido. Use a exportacao original 0.6.2a.' }
    $inputHash=Hash-Arquivo $pack
    if($inputHash -notin @($meta.original_sha256,$meta.base_sha256)) { throw 'PCK desconhecido ou ja modificado. Selecione a pasta original, nao uma instalacao LAN.' }
    foreach($name in @('discord_game_sdk.dll','libdiscord_game_sdk_binding.dll','libwebrtc_native.windows.template_release.x86_64.dll')) {
        if(!(Test-Path -LiteralPath (Join-Path $Origem $name))) { throw "Falta arquivo da exportacao original: $name" }
    }
    if(!$Destino) { $Destino=Join-Path $Origem 'PBA-Coop-Comunidade-Alpha1' }
    $Destino=[IO.Path]::GetFullPath($Destino)
    if(Test-Path -LiteralPath $Destino) { throw 'Destino ja existe. Use uma pasta nova para preservar o jogo e os saves.' }
    if(!$MigrarDe) {
        foreach($previous in @('PBA-Coop-Battle-Fix','PBA-Coop-S03-Fix','PBA-Coop-S03')) {
            $candidate=Join-Path $Origem $previous
            if(Test-Path -LiteralPath (Join-Path $candidate 'userdata')) { $MigrarDe=$candidate;break }
        }
    }
    $snapshots=@();$locks=@()
    try {
        if($MigrarDe -and (Test-Path -LiteralPath (Join-Path $MigrarDe 'userdata'))) {
            $migrationRoot=(Resolve-Path -LiteralPath $MigrarDe).Path
            foreach($profileDir in Get-ChildItem -LiteralPath (Join-Path $migrationRoot 'userdata') -Directory) {
                if($profileDir.Name -eq 'solo') { continue }
                $lockPath=Join-Path $profileDir.FullName 'profile.lock'
                if(Test-Path -LiteralPath $lockPath) {
                    $lock=[IO.File]::Open($lockPath,[IO.FileMode]::Open,[IO.FileAccess]::ReadWrite,[IO.FileShare]::ReadWrite)
                    $locks += $lock
                    try { $lock.Lock(0,1) } catch { throw "Feche o jogo anterior antes de migrar o perfil $($profileDir.Name)." }
                }
                $user=Join-Path $profileDir.FullName ('Godot\app_userdata\Pok'+[char]233+'mon Battle Advanced')
                $directory=Join-Path $user 'coop_s3'
                if(!(Test-Path -LiteralPath $directory)) { continue }
                $valid=$false;$candidates=@()
                foreach($name in @('profile.json','profile.json.bak','trade_pending.json')) {
                    $file=Join-Path $directory $name
                    if(!(Test-Path -LiteralPath $file)) { continue }
                    $raw=[IO.File]::ReadAllBytes($file)
                    $doc=$null
                    try { $doc=[Text.Encoding]::UTF8.GetString($raw) | ConvertFrom-Json } catch { }
                    $checksum=$null -ne $doc -and $doc.payload -is [string] -and (Hash-Texto $doc.payload) -eq $doc.sha256
                    if($name -eq 'trade_pending.json') { if(!$checksum) { throw 'Journal de troca invalido; arquivos preservados.' } }
                    elseif($doc.schema -eq 1 -and $checksum) { $valid=$true }
                    elseif($doc.schema -gt 1) { throw 'Save de versao futura. Atualize o mod.' }
                    $candidates += @{relative=$file.Substring($migrationRoot.Length+1);raw=$raw}
                }
                if($candidates.Count -and !$valid) { throw 'Perfil anterior invalido; arquivos preservados.' }
                $snapshots += $candidates
                foreach($name in @('key_bindings.cfg','settings.cfg')) {
                    $file=Join-Path $user $name
                    if(Test-Path -LiteralPath $file) { $snapshots += @{relative=$file.Substring($migrationRoot.Length+1);raw=[IO.File]::ReadAllBytes($file)} }
                }
            }
        }
        [void][IO.Directory]::CreateDirectory($Destino)
        $backup=Join-Path $Destino 'PokemonBattleAdvanced.before-coop.pck'
        [IO.File]::Copy($pack,$backup,$false)
        if($inputHash -eq $meta.original_sha256) { Aplicar-Cauda $backup (Join-Path $PSScriptRoot 'base.delta') ([UInt64]$meta.base_directory) }
        if((Hash-Arquivo $backup) -ne $meta.base_sha256) { throw 'Falha ao verificar o backup com Thunder Stone.' }
        $output=Join-Path $Destino 'PokemonBattleAdvanced.pck'
        [IO.File]::Copy($backup,$output,$false)
        Aplicar-Cauda $output (Join-Path $PSScriptRoot 'community.delta') ([UInt64]$meta.community_directory)
        if((Hash-Arquivo $output) -ne $meta.coop_pack_sha256) { throw 'Falha de integridade no PCK final.' }
        foreach($name in @('PokemonBattleAdvanced.exe','discord_game_sdk.dll','libdiscord_game_sdk_binding.dll','libwebrtc_native.windows.template_release.x86_64.dll')) { [IO.File]::Copy((Join-Path $Origem $name),(Join-Path $Destino $name),$false) }
        foreach($folder in @('addons\discord-rpc-gd\bin\windows','addons\webrtc_native\lib')) { [void][IO.Directory]::CreateDirectory((Join-Path $Destino $folder)) }
        foreach($name in @('discord_game_sdk.dll','libdiscord_game_sdk_binding.dll')) { [IO.File]::Copy((Join-Path $Origem $name),(Join-Path $Destino ('addons\discord-rpc-gd\bin\windows\'+$name)),$false) }
        [IO.File]::Copy((Join-Path $Origem 'libwebrtc_native.windows.template_release.x86_64.dll'),(Join-Path $Destino 'addons\webrtc_native\lib\libwebrtc_native.windows.template_release.x86_64.dll'),$false)
        foreach($name in @('Jogar.ps1','Restaurar.ps1','Coletar-Logs.ps1','Jogar-Coop.bat','Hospedar.bat','Entrar.bat','Jogar-Sozinho.bat','Restaurar.bat','Coletar-Logs.bat','LEIA-ME.txt','GUIA_COMUNIDADE.md','RELATORIO_COMUNIDADE.md','BUILD.json')) {
            $file=Join-Path $PSScriptRoot $name
            if(Test-Path -LiteralPath $file) { [IO.File]::Copy($file,(Join-Path $Destino $name),$false) }
        }
        foreach($record in $snapshots) {
            $file=Join-Path $Destino $record.relative
            [void][IO.Directory]::CreateDirectory((Split-Path $file))
            [IO.File]::WriteAllBytes($file,$record.raw)
        }
        $installation=@{version=$meta.version;coop_pack_sha256=$meta.coop_pack_sha256;source_pack_sha256=$meta.base_sha256;exe_sha256=$meta.exe_sha256;source=$Origem;migrated_files=@($snapshots | ForEach-Object {$_.relative})}
        $installation | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $Destino 'installation.json') -Encoding UTF8
        Write-Host "Instalado: $Destino"
        Write-Host 'Abra Jogar-Coop.bat. A pasta anterior e os saves originais foram preservados.'
    } finally { foreach($lock in $locks) { $lock.Dispose() } }
} catch { Write-Error ("Instalacao interrompida: "+$_.Exception.Message);exit 1 }

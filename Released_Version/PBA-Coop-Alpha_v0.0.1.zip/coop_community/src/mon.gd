extends RefCounted













const Cooking: = preload("res://scripts/world/cooking.gd")
const Items: = preload("res://scripts/items.gd")
const Dex: = preload("res://scripts/dex.gd")
const StatCalc: = preload("res://scripts/stats/stat_calc.gd")
const Growth: = preload("res://scripts/stats/growth.gd")
const SELF_PATH: = "res://scripts/stats/mon.gd"
const DEFAULT_SPRITE: = "res://assets/sprites/critter_green.png"

const FRIEND_START: = 70

var species: = ""
var nickname: = ""
var level: = 1
var nature: = "hardy"
var ivs: = {}
var evs: = {}
var ev_respec_used: = false

var stats: = {}
var hp: = 0

var held: = ""
var meal_buff: Dictionary = {}



var status: = ""

const PERSIST_STATUS: = ["burn", "poison", "paralysis", "sleep", "freeze"]

var pp: = 0.0

var owner: = ""

var coop_uid: String = ""
var ot_id: = ""
var ball: = "poke_ball"

var gender: = ""


var shiny: = false


var ability_slot: = 0

var ability_override: = ""

var moves: Array = []


var moves2: Array = []


var xp: = 0

var evo_cancelled_level: = 0



var evo_pending: = false


var met_level: = 0
var met_zone: = ""

var default_wild: = false
var default_assist: = false

var battle_role: = "auto"

var cd_save: = {}
var active_loadout: = 0


var friend: = FRIEND_START



var egg: = false
var egg_steps: = 0


var art_species: String:
	get:
		return "Egg" if egg else species
var display_name: String:
	get:
		if egg:
			return "EGG"
		return nickname if nickname != "" else species
var max_hp: int:
	get:
		return int(stats.get("hp", 1))
var pp_base: float:
	get:
		return float(_sp().get("pp", 100))
var sprite: String:
	get:
		return _sp().get("sprite", DEFAULT_SPRITE)
var types: Array:
	get:
		return _sp().get("types", ["normal"])
var growth: String:
	get:
		return _sp().get("growth", "medium_fast")

var ability: String:
	get:
		if ability_override != "":
			return ability_override
		var abil: Array = _sp().get("abilities", [])
		if abil.is_empty():
			return ""
		return String(abil[clampi(ability_slot, 0, abil.size() - 1)])

var ability_name: String:
	get:
		var a: = ability
		return "" if a == "" else String(Dex.ability(a).get("name", a))
var ability_desc: String:
	get:
		var a: = ability
		return "" if a == "" else String(Dex.ability(a).get("desc", ""))

var exp_this_level: int:
	get:
		return Growth.exp_for_level(growth, level)
var exp_next_level: int:
	get:
		return Growth.exp_for_level(growth, mini(level + 1, Growth.MAX_LEVEL))



static func create(sp_name: String, lv: int, rng: RandomNumberGenerator = null, shiny: = false) -> RefCounted:
	var m = load(SELF_PATH).new()
	m.species = sp_name
	m.level = lv
	m.shiny = shiny
	m.ivs = StatCalc.random_ivs(rng)
	m.evs = StatCalc.zero_evs()
	m.nature = StatCalc.random_nature(rng)
	m.gender = _roll_gender(sp_name, rng)
	m.ability_slot = _roll_ability_slot(sp_name, rng)
	m.moves = Dex.moves_at(sp_name, lv)
	m.xp = Growth.exp_for_level(m.growth, lv)
	m.recalc()
	m.heal_full()
	return m




func make_good_specimen() -> void :
	nature = StatCalc.perfect_nature(_sp().get("base", {}))
	ivs = StatCalc.good_ivs()
	recalc()


func _sp() -> Dictionary:
	return Dex.species(species)



static func _roll_gender(sp_name: String, rng: RandomNumberGenerator = null) -> String:
	var ratio: = float(Dex.species(sp_name).get("gender_ratio", 0.5))
	if ratio < 0.0:
		return ""
	var roll: = (rng.randf() if rng else randf())
	return "female" if roll < ratio else "male"



static func _roll_ability_slot(sp_name: String, rng: RandomNumberGenerator = null) -> int:
	if Dex.species(sp_name).get("abilities", []).size() < 2:
		return 0
	var roll: = (rng.randf() if rng else randf())
	return 1 if roll < 0.5 else 0



func recalc() -> void :
	var old_max: = int(stats.get("hp", 0))
	var base: Dictionary = _sp().get("base", {})
	for s in StatCalc.STATS:
		stats[s] = StatCalc.stat(s, int(base.get(s, 50)), int(ivs.get(s, 0)), int(evs.get(s, 0)), level, nature)
	if old_max > 0:
		hp = clampi(hp + (max_hp - old_max), 0, max_hp)


func heal_full() -> void :
	if egg:
		return
	hp = max_hp
	pp = pp_base
	status = ""





func set_friend(v: int) -> void :
	friend = clampi(v, 0, 255)



static func mood(v: int) -> String:
	if v < 70:
		return "Wary"
	if v < 150:
		return "Content"
	if v < 220:
		return "Happy"
	return "Devoted"


func is_fainted() -> bool:
	return hp <= 0 and not egg




func ev_total() -> int:
	var t: = 0
	for s in evs:
		t += int(evs[s])
	return t



func ev_yield() -> Dictionary:
	return _sp().get("ev_yield", {})



func catch_rate() -> int:
	return int(_sp().get("catch_rate", 190))



func add_evs(gain: Dictionary) -> Dictionary:
	var got: = {}
	for s in gain:
		var room: = mini(StatCalc.EV_MAX_STAT - int(evs.get(s, 0)), StatCalc.EV_MAX_TOTAL - ev_total())
		var add: = clampi(int(gain[s]), 0, maxi(room, 0))
		if add > 0:
			evs[s] = int(evs.get(s, 0)) + add
			got[s] = add
	if not got.is_empty():
		recalc()
	return got




func respec_evs(new_evs: Dictionary) -> bool:
	if ev_respec_used:
		return false
	var total: = 0
	for s in StatCalc.STATS:
		var v: = int(new_evs.get(s, 0))
		if v < 0 or v > StatCalc.EV_MAX_STAT:
			return false
		total += v
	if total != ev_total():
		return false
	for s in StatCalc.STATS:
		evs[s] = int(new_evs.get(s, 0))
	ev_respec_used = true
	recalc()
	return true





func exp_yield(winner_level: int, trainer: = false) -> int:
	return Growth.exp_gain(int(_sp().get("base_exp", 50)), level, winner_level, trainer)



static func create_egg(sp_name: String, steps: int, rng: RandomNumberGenerator = null) -> RefCounted:
	var m = create(sp_name, 5, rng)
	m.egg = true
	m.egg_steps = steps
	m.hp = 0
	return m



func hatch() -> void :
	egg = false
	egg_steps = 0
	heal_full()






func add_exp(amount: int) -> Array:
	var events: Array = []
	if level >= Growth.MAX_LEVEL or amount <= 0 or egg:
		return events
	xp += amount
	while level < Growth.MAX_LEVEL and xp >= Growth.exp_for_level(growth, level + 1):
		level += 1
		recalc()
		events.append({"type": "level", "level": level})
		if evolution_target() != "":
			evo_pending = true
		for e in _sp().get("learnset", []):
			if int(e[0]) == level and not moves.has(e[1]):
				var ok: bool = moves.size() < 4
				if ok:
					moves.append(e[1])
				events.append({"type": "move", "move": e[1], "learned": ok})
	if level >= Growth.MAX_LEVEL:
		xp = Growth.exp_for_level(growth, Growth.MAX_LEVEL)
	return events




func evolution_target() -> String:
	for evo in Dex.evolutions(species):
		if String(evo.get("method", "level")) != "level":
			continue
		if level < int(evo.get("level", 999)) or level <= evo_cancelled_level:
			continue
		return String(evo.get("into", ""))
	return ""







func evolve(into: String) -> Array:
	species = into
	evo_cancelled_level = 0
	evo_pending = false

	for id in _sp().get("forgets", []):
		moves.erase(id)
		moves2.erase(id)
	var candidates: Array = []
	for e in _sp().get("learnset", []):
		if int(e[0]) == level:
			candidates.append(e[1])
	for id in _sp().get("evo_moves", []):
		candidates.append(id)
	var missed: Array = []
	for id in candidates:
		if moves.has(id) or missed.has(id):
			continue
		if moves.size() < 4:
			moves.append(id)
		else:
			missed.append(id)
	recalc()
	return missed




func forgotten_moves() -> Array:
	var result: Array = []
	var seen: Array = (_sp().get("forgets", []) as Array).duplicate()
	var chain: Array = [species]
	chain.append_array(Dex.evolution_line_before(species))
	for sp_name in chain:
		for entry in Dex.species(String(sp_name)).get("learnset", []):
			if int(entry[0]) <= level and not moves.has(entry[1]) and not seen.has(entry[1]):
				result.append(entry.duplicate())
				seen.append(entry[1])
	return result





func loadout(i: int) -> Array:
	return moves2 if i == 1 else moves


func active_moves() -> Array:
	return loadout(active_loadout)


func all_moves() -> Array:
	return moves + moves2


func knows(id: String) -> bool:
	return all_moves().has(id)


func free_slot(two: bool) -> Dictionary:
	for i in (2 if two else 1):
		var arr: = loadout(i)
		if arr.size() < 4:
			return {"loadout": i, "slot": arr.size()}
	return {}




func replace_move(k: int, id: String) -> void :
	if k >= 0 and k < moves.size():
		moves[k] = id
	elif k >= 4 and k - 4 < moves2.size():
		moves2[k - 4] = id






func ensure_ot_id(trainer_id: String, trainer_name: String) -> void :
	if ot_id != "":
		return
	if met_zone == "trade":
		ot_id = "npc:legacy"
	elif owner != "" and owner != "player" and owner != trainer_name:
		ot_id = "legacy:" + owner
	else:
		ot_id = trainer_id


func to_dict() -> Dictionary:
	return {"coop_uid": coop_uid, "species": species, "nickname": nickname, "level": level, "nature": nature, 
		"ivs": ivs.duplicate(), "evs": evs.duplicate(), "ev_respec_used": ev_respec_used, "hp": hp, "pp": pp, "status": status, "held": held, "meal_buff": meal_buff.duplicate(true), "owner": owner, "ball": ball, "gender": gender, "ability_slot": ability_slot, "moves": moves.duplicate(), "xp": xp, "evo_cancelled_level": evo_cancelled_level, 
		"moves2": moves2.duplicate(), "active_loadout": active_loadout, "ot_id": ot_id, 
		"evo_pending": evo_pending, "met_level": met_level, "met_zone": met_zone, "friend": friend, 
		"default_wild": default_wild, "default_assist": default_assist, "battle_role": battle_role, 
		"egg": egg, "egg_steps": egg_steps, "shiny": shiny}


static func from_dict(d: Dictionary) -> RefCounted:
	var m = load(SELF_PATH).new()
	m.species = d.get("species", "")
	m.nickname = d.get("nickname", "")
	m.level = int(d.get("level", 1))
	m.nature = d.get("nature", "hardy")
	m.ivs = d.get("ivs", StatCalc.random_ivs())
	m.evs = d.get("evs", StatCalc.zero_evs())
	m.ev_respec_used = bool(d.get("ev_respec_used", false))
	m.shiny = bool(d.get("shiny", false))
	m.meal_buff = Cooking.clean_buff(d.get("meal_buff", {}))
	m.held = String(d.get("held", ""))
	if not Items.all_ids().has(m.held):
		m.held = ""
	m.owner = d.get("owner", "")
	m.ot_id = String(d.get("ot_id", ""))
	m.coop_uid = String(d.get("coop_uid", ""))
	m.ball = d.get("ball", "poke_ball")


	if d.has("gender"):
		m.gender = str(d.get("gender", ""))
		if m.gender != "male" and m.gender != "female":
			m.gender = ""
	else:
		var gr: = RandomNumberGenerator.new()
		gr.seed = hash("%s|%s|%s" % [m.species, m.nature, m.ivs])
		m.gender = _roll_gender(m.species, gr)

	if d.has("ability_slot"):
		m.ability_slot = clampi(int(d.get("ability_slot", 0)), 0, 1)
	else:
		var ar: = RandomNumberGenerator.new()
		ar.seed = hash("%s|%s|%s|ability" % [m.species, m.nature, m.ivs])
		m.ability_slot = _roll_ability_slot(m.species, ar)
	m.moves = d.get("moves", Dex.moves_at(m.species, m.level))

	m.moves2 = d.get("moves2", [])
	m.active_loadout = clampi(int(d.get("active_loadout", 0)), 0, 1)
	if m.loadout(m.active_loadout).is_empty():
		m.active_loadout = 0
	m.xp = int(d.get("xp", Growth.exp_for_level(m.growth, m.level)))
	m.evo_cancelled_level = int(d.get("evo_cancelled_level", 0))
	m.evo_pending = bool(d.get("evo_pending", false))
	m.met_level = int(d.get("met_level", 0))
	m.met_zone = String(d.get("met_zone", ""))
	m.default_wild = bool(d.get("default_wild", false))
	m.default_assist = bool(d.get("default_assist", false)) and not m.default_wild
	m.battle_role = String(d.get("battle_role", "auto"))

	m.friend = clampi(int(d.get("friend", FRIEND_START)), 0, 255)

	m.status = String(d.get("status", ""))
	if not PERSIST_STATUS.has(m.status):
		m.status = ""
	m.egg = bool(d.get("egg", false))
	m.egg_steps = maxi(int(d.get("egg_steps", 0)), 0)
	m.recalc()
	m.hp = 0 if m.egg else int(d.get("hp", m.max_hp))
	m.pp = float(d.get("pp", m.pp_base))
	return m



func meal_blocks(s: String, minutes: float) -> bool:
	if not Cooking.active(meal_buff, minutes):
		return false
	var shield: Dictionary = meal_buff.get("immunity", {})
	if String(shield.get("status", "")) != s or int(shield.get("charges", 0)) == 0:
		return false
	if int(shield.charges) > 0:
		shield.charges = 0
	return true

"""Export a closed co-op profile to a NEW native-format JSON; never overwrite a save."""
from pathlib import Path
import argparse,json,hashlib,re,msvcrt
ROOT=Path(__file__).resolve().parent
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--perfil',default='coop');ap.add_argument('--saida',required=True,type=Path)
    a=ap.parse_args()
    if not re.fullmatch(r'[A-Za-z0-9_-]{1,40}',a.perfil):raise SystemExit('Perfil invalido.')
    base=ROOT/'userdata'/a.perfil
    lock=None
    try:
        if (base/'profile.lock').exists():
            lock=(base/'profile.lock').open('r+b');lock.seek(0)
            try:msvcrt.locking(lock.fileno(),msvcrt.LK_NBLCK,1)
            except OSError:raise SystemExit('Feche este perfil antes de exportar.')
        directory=base/'Godot/app_userdata'/('Pok'+chr(233)+'mon Battle Advanced')/'coop_s3'
        if (directory/'trade_pending.json').exists():raise SystemExit('Resolva a troca pendente antes de exportar.')
        doc=json.loads((directory/'profile.json').read_text(encoding='utf8'))
        if doc.get('schema')!=1 or hashlib.sha256(doc['payload'].encode('utf8')).hexdigest()!=doc.get('sha256'):raise SystemExit('Perfil invalido; original preservado.')
        data=json.loads(doc['payload'])['snapshot']
        if not isinstance(data.get('state',{}).get('party'),list):raise SystemExit('Snapshot invalido.')
        data['game_version']='0.6.2a'
        dest=a.saida.resolve();dest.parent.mkdir(parents=True,exist_ok=True)
        with dest.open('x',encoding='utf8') as f:json.dump(data,f,ensure_ascii=False,indent=2)
        print('Copia nativa exportada:',dest)
    finally:
        if lock:lock.close()

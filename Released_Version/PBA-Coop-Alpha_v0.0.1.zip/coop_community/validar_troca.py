"""Two real LAN processes, native Cable Club session/UI and durable own profiles."""
from pathlib import Path
import argparse,json,os,subprocess,time

def profile(base,role):
    p=next((base/role).rglob('profile.json'))
    return json.loads(json.loads(p.read_text(encoding='utf8'))['payload'])

def run(runtime,base,case,port):
    base.mkdir(parents=True,exist_ok=True);processes=[]
    try:
        for role in ['host','guest']:
            data=base/role;data.mkdir(exist_ok=True)
            env=os.environ.copy();env['APPDATA']=str(data.resolve())
            out=(base/(case+'_'+role+'.log')).open('w',encoding='utf8')
            cmd=[str(runtime/'PokemonBattleAdvanced.exe'),'--headless','--','--coop-campaign','--coop-role='+role,'--coop-port='+str(port),'--coop-start=route2','--coop-autotest','--coop-persist-test','--coop-test='+case]
            p=subprocess.Popen(cmd,cwd=runtime,env=env,stdout=out,stderr=out);processes.append((role,p,out));time.sleep(1)
        deadline=time.monotonic()+65
        while any(p.poll() is None for _,p,_ in processes) and time.monotonic()<deadline:
            if case=='trade_drop' and processes[1][1].poll() is not None:
                time.sleep(2);break
            time.sleep(.25)
        for role,p,out in processes:
            if case=='trade_drop' and role=='host' and p.poll() is None:p.terminate();p.wait()
            assert p.poll() is not None,(case,role,'timeout')
            out.close()
            text=(base/(case+'_'+role+'.log')).read_text(encoding='utf8')
            assert 'SCRIPT ERROR' not in text,(case,role,text[-3000:])
            if case!='trade_drop' or role=='guest':assert p.returncode==0,(case,role,p.returncode)
            if case=='trade_cancel':assert 'trade_test_cancelled' in text
            elif case!='trade_drop':assert 'trade_complete' in text,(case,role,text[-2000:])
        return {r:profile(base,r) for r in ['host','guest']}
    finally:
        for _,p,out in processes:
            if p.poll() is None:p.kill();p.wait()
            out.close()

def check(d):
    for role,expected in [('host','Machamp'),('guest','Gengar')]:
        state=d[role]['snapshot']['state']
        assert len(state['party'])==2 and state['party'][1]['species']==expected,(role,state['party'])
        assert len(state['flags'].get('coop_trade_receipts',{}))==1
    assert d['host']['player_id']!=d['guest']['player_id']
    assert d['host']['snapshot']['state']['party'][1]['coop_uid']!=d['guest']['snapshot']['state']['party'][1]['coop_uid']

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--runtime',required=True,type=Path);ap.add_argument('--logs',required=True,type=Path)
    a=ap.parse_args();runtime=a.runtime.resolve();base=a.logs.resolve()
    normal=run(runtime,base/'normal','trade',25181);check(normal)
    cancelled=run(runtime,base/'cancel','trade_cancel',25182)
    for role,expected in [('host','Haunter'),('guest','Machoke')]:
        state=cancelled[role]['snapshot']['state'];assert state['party'][1]['species']==expected and not state['flags'].get('coop_trade_receipts',{})
    run(runtime,base/'recover','trade_drop',25183)
    recovered=run(runtime,base/'recover','trade_recover',25184);check(recovered)
    result={'passed':True,'native_session_ui_apply':True,'normal_trade':True,'cancel_preserved_both':True,'crash_after_decision_recovered':True,'trade_evolutions':['Gengar','Machamp']}
    (base/'result.json').write_text(json.dumps(result,indent=2),encoding='utf8');print(json.dumps(result))

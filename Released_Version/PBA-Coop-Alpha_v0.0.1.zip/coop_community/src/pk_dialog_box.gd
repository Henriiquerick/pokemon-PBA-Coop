class_name PkDialogBox
extends PkWindow







const Controls: = preload("res://scripts/controls.gd")

signal line_done
signal finished
signal answered(yes: bool)
signal chose(id: String)

var auto_advance: = 0.0
const FACE_SIZE: = Vector2(170, 200)
const FACE_TUCK: = 34.0

var _label: Label
var _lines: PackedStringArray = []
var _i: = 0
var _chars: = 0.0
var _blip: = 0
var _complete: = false
var _asking: = false
var _open_frame: = -1
var _done_t: = 0.0
var _t: = 0.0
var _choice_win: PkWindow
var _choice: PkMenuList
var _yesno: = false
var _face: TextureRect


func _init() -> void :
	super ()
	custom_minimum_size = Vector2(0, 150)
	_label = Label.new()
	_label.add_theme_font_override("font", UiKit.body_font())
	_label.add_theme_font_size_override("font_size", UiKit.SIZE_BODY - 2)
	_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_label.vertical_alignment = VERTICAL_ALIGNMENT_TOP
	_label.visible_characters_behavior = TextServer.VC_CHARS_AFTER_SHAPING
	_label.size_flags_vertical = Control.SIZE_EXPAND_FILL
	var layout: = VBoxContainer.new()
	layout.add_child(_label)
	var footer: = Control.new()
	footer.custom_minimum_size.y = 28
	footer.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layout.add_child(footer)
	add_child(layout)
	_choice_win = PkWindow.new()
	_choice_win.top_level = true
	_choice_win.visible = false
	add_child(_choice_win)
	_choice = PkMenuList.new()
	_choice.active = false
	_choice.chosen.connect(_pick)
	_choice.cancelled.connect(_cancel)
	_choice_win.add_child(_choice)
	_face = TextureRect.new()
	_face.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_face.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
	_face.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	_face.stretch_mode = TextureRect.STRETCH_SCALE
	_face.size = FACE_SIZE
	_face.visible = false
	visible = false
	UiKit.setup_input()



func say(speaker: String, lines: Array, face: = "") -> void :
	_open(speaker, lines)
	_set_face(face)
	await finished


func _set_face(path: String) -> void :
	var tex: Texture2D = load(path) if path != "" and ResourceLoader.exists(path) else null
	_face.visible = tex != null
	if tex == null:
		_face.texture = null
		return
	var at: = AtlasTexture.new()
	at.atlas = tex
	var w: = float(tex.get_width())
	at.region = Rect2(0, 0, w, minf(float(tex.get_height()), w * FACE_SIZE.y / FACE_SIZE.x))
	_face.texture = at

	var host: = get_parent()
	if host != null and _face.get_parent() != host:
		if _face.get_parent() != null:
			_face.get_parent().remove_child(_face)
		host.add_child(_face)

	if host != null and _face.get_index() > get_index():
		host.move_child(_face, get_index())
	_place_face()


func _place_face() -> void :

	_face.global_position = global_position + Vector2(28, FACE_TUCK - FACE_SIZE.y)


func ask_yes_no(speaker: String, question: String) -> bool:
	_open(speaker, [question])
	_choice.set_items([{"id": "yes", "label": "YES"}, {"id": "no", "label": "NO"}])
	_yesno = true
	_asking = true
	_show_choice_if_done()
	var yes: bool = await answered
	return yes




func ask_choice(speaker: String, question: String, items: Array) -> String:
	_open(speaker, [question])
	_choice.set_items(items)
	_yesno = false
	_asking = true
	_show_choice_if_done()
	var id: String = await chose
	return id


func current_line() -> int:
	return _i



func is_choice_open() -> bool:
	return _choice_win.visible




func choice_tap(gp: Vector2) -> bool:
	if not _choice_win.visible:
		return false
	var i: = _choice.index_at(gp)
	if i < 0:
		return false
	_choice.index = i
	_choice.confirm()
	return true


func line_complete() -> bool:
	return _complete


func _open(speaker: String, lines: Array) -> void :
	lines = Array(preload("res://coop/pt_br.gd").lines(lines))
	_lines = PackedStringArray(lines) if not lines.is_empty() else PackedStringArray(["..."])
	_i = 0
	_asking = false
	_choice_win.visible = false
	_choice.active = false
	title = speaker
	_face.visible = false
	visible = true
	_open_frame = Engine.get_process_frames()
	_show_line()


func _show_line() -> void :
	_label.text = _lines[_i]
	_label.visible_characters = 0
	_chars = 0.0
	_blip = 0
	_complete = false
	_done_t = 0.0
	if Settings.text_instant():
		_finish_line()




func _show_choice_if_done() -> void :
	if _complete and not _choice_win.visible:
		_show_choice()


func _finish_line() -> void :
	_label.visible_characters = -1
	_complete = true
	_done_t = 0.0
	line_done.emit()
	if _asking:
		_show_choice()


func _show_choice() -> void :
	_choice_win.reset_size()
	var w: = _choice_win.get_combined_minimum_size()
	_choice_win.global_position = global_position + Vector2(size.x - w.x - 12, - w.y - 10)
	_choice.index = 0
	_choice_win.visible = true
	_choice.active = true
	UiKit.pop_in(_choice_win)


func _pick(id: String) -> void :
	_choice.active = false
	close()
	if _yesno:
		answered.emit(id == "yes")
	else:
		chose.emit(id)


func _cancel() -> void :
	if _yesno:
		_pick("no")
	else:
		_choice.active = false
		close()
		chose.emit("")


func advance() -> void :
	if not visible:
		return
	if not _complete:
		_finish_line()
		return
	if _asking:
		return
	_i += 1
	Audio.play_exact("sfx/ui/cursor", -14.0, 1.0, "UI")
	if _i >= _lines.size():
		close()
		finished.emit()
	else:
		_show_line()


func close() -> void :
	visible = false
	_face.visible = false
	_choice_win.visible = false
	_asking = false




func skip() -> void :
	if not visible:
		return
	if _asking:
		_cancel()
	else:
		close()
		finished.emit()


func _process(delta: float) -> void :
	_t += delta
	if not visible:
		if _face.visible:
			_face.visible = false
		return
	if _face.visible:
		_place_face()
	if not _complete:
		_chars += delta * Settings.text_cps()
		_label.visible_characters = int(_chars)
		if _label.visible_characters - _blip >= 4:
			_blip = _label.visible_characters
			Audio.play_exact("sfx/ui/text_blip", -20.0, 1.0, "UI")
		if _label.visible_characters >= _label.get_total_character_count():
			_finish_line()
	else:
		var auto: = auto_advance if auto_advance > 0.0 else (0.4 if Debug.auto_dialog else 0.0)
		if auto > 0.0:
			_done_t += delta
			if _done_t >= auto:
				if _asking and _choice_win.visible:
					_choice.index = 0
					_choice.confirm()
				elif not _asking:
					advance()
	queue_redraw()


func _unhandled_input(e: InputEvent) -> void :
	if not visible or _choice_win.visible or Engine.get_process_frames() == _open_frame:
		return
	if e.is_action_pressed("interact") or e.is_action_pressed("pk_ok") or e.is_action_pressed("pk_back"):
		advance()
		get_viewport().set_input_as_handled()





func continue_hint() -> String:
	if not visible or not _complete:
		return ""
	var glyph: = Controls.key_label("pk_ok" if Battle.in_battle else "interact")
	return glyph if glyph != "" else "TAP"


func _draw() -> void :
	super ()
	var hint: = continue_hint()
	if hint == "":
		return
	var font: = UiKit.header_font()
	var width: = maxf(38.0, font.get_string_size(hint, HORIZONTAL_ALIGNMENT_LEFT, -1, 15).x + 20)
	var rect: = Rect2(size.x - width - 18, size.y - 40, width, 26)
	var style: = UiKit.pill(UiKit.SLATE_800, UiKit.accent_border(), 6)
	style.set_border_width_all(2)
	draw_style_box(style, rect)
	draw_string(font, rect.position + Vector2(0, 19), hint, 
		HORIZONTAL_ALIGNMENT_CENTER, width, 15, UiKit.accent())

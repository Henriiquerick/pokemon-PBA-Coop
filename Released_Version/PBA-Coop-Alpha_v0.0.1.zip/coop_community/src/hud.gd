extends CanvasLayer

signal dialog_closed
signal choice_made(yes: bool)


const SafariGame: = preload("res://scripts/safari_game.gd")
const SummaryPanel: = preload("res://scripts/ui/summary_panel.gd")
const BagPanel: = preload("res://scripts/ui/bag_panel.gd")
const PokedexPanel: = preload("res://scripts/ui/pokedex_panel.gd")
const PartyPanel: = preload("res://scripts/ui/party_panel.gd")
const ShopPanel: = preload("res://scripts/ui/shop_panel.gd")
const PcPanel: = preload("res://scripts/ui/pc_panel.gd")
const CableClubPanel: = preload("res://scripts/ui/cable_club/cable_club_panel.gd")
const BattleIntro: = preload("res://scripts/ui/battle_intro.gd")
const BattleHud: = preload("res://scripts/ui/battle_hud.gd")
const BattleLog: = preload("res://scripts/ui/battle_log.gd")
const ResultsLog: = preload("res://scripts/ui/battle_results_log.gd")
const MealChip: = preload("res://scripts/ui/meal_chip.gd")
const LevelCard: = preload("res://scripts/ui/level_card.gd")
const ObserveCard: = preload("res://scripts/ui/observe_card.gd")
const BreederLevel: = preload("res://scripts/stats/breeder_level.gd")
const PartyOrbs: = preload("res://scripts/ui/party_orbs.gd")
const PartyRing: = preload("res://scripts/ui/kit/pk_party_ring.gd")
const PauseMenu: = preload("res://scripts/ui/pause_menu.gd")
const HintBar: = preload("res://scripts/ui/kit/pk_hint_bar.gd")
const MountRig: = preload("res://scripts/mount_rig.gd")
const ZonePill: = preload("res://scripts/ui/zone_pill.gd")

const Controls: = preload("res://scripts/controls.gd")

var _status: Label
var _ball: Label
var _msg: Label
var _msg_t: = 0.0
var _dlg: PkDialogBox
var _summary: PanelContainer
var intro: Control
var battle_hud: Control
var battle_log: Control
var results_log: Control
var level_card: Control
var observe_card: Control
var party_orbs: Control
var party_ring: Control
var pause_menu: Control

var touch_controls: CanvasLayer
var _saving: Label

var _loc_panel: Control

var _minimap: Minimap
var _loc_label: Label

var _meal_layout: = Vector3.INF
var meal_chip: Control
var _clock: Label
var _loc_zone: = ""
var _safari_txt: = ""
var _streamer: Node
var _zone_ready: = false
var _in_battle: = false
var _in_picnic: = false
var _notice: PanelContainer

var _hint: Control
const LOC_TOP: = 16.0
const LOC_RIGHT: = 14.0
const MINIMAP_D: = 170.0

const ORB_GAP: = 10.0
const HINT_INSET: = PkHintBar.INSET


var _prompt: Control
var _prompt_target: Node3D
var _prompt_verb: = "�"
var _prompt_ride: = ""
var _prompt_pilot: = false

var _saving_tw: Tween

var _riding: = false

var _piloting: = false

var _menu_hint: = false
var _prompt_inspect: = ""
var _prompt_shown: = false
var _prompt_tw: Tween
const PROMPT_LIFT: = 14.0


var _ow_hud_hidden: = false
var _night_hidden: = false
var _ow_hidden: = {}


func _ready() -> void :
	add_to_group("hud")
	battle_hud = BattleHud.new()
	add_child(battle_hud)
	battle_log = BattleLog.new()
	add_child(battle_log)
	results_log = ResultsLog.new()



	results_log.z_index = 60
	add_child(results_log)
	level_card = LevelCard.new()
	add_child(level_card)
	observe_card = ObserveCard.new()
	add_child(observe_card)
	intro = BattleIntro.new()
	add_child(intro)
	_status = _label(22)
	_status.position = Vector2(16, 36)
	_ball = _label(20)
	_ball.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_RIGHT)
	_ball.offset_left = -360
	_ball.offset_top = -44
	_ball.offset_right = -16
	_ball.offset_bottom = -12
	_ball.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	_msg = _label(28)
	_msg.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE)
	_msg.offset_top = -90
	_msg.offset_bottom = -30
	_msg.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_build_party_orbs()
	_build_minimap()
	_build_location()
	meal_chip = MealChip.new()
	_clock.get_parent().add_child(meal_chip)
	_build_hint()
	party_ring = PartyRing.new()
	party_ring.name = "party_ring"
	add_child(party_ring)
	party_ring.picked.connect(_on_party_ring_picked)
	party_ring.held.connect(_on_party_ring_held)
	_build_dialog()
	pause_menu = PauseMenu.new()
	add_child(pause_menu)


	touch_controls = get_node_or_null("/root/Touch")


	if Game.daily_build:
		party_orbs.suppressed = true
		party_ring.visible = false


func _label(font_size: int) -> Label:
	var l: = Label.new()
	var s: = LabelSettings.new()
	s.font_size = font_size
	s.outline_size = 8
	s.outline_color = Color(0, 0, 0, 0.85)
	l.label_settings = s
	add_child(l)
	return l


func _build_party_orbs() -> void :

	party_orbs = PartyOrbs.new()
	party_orbs.anchor_left = 1.0
	party_orbs.anchor_right = 1.0
	add_child(party_orbs)
	_refresh_orbs()




func _build_minimap() -> void :
	_minimap = Minimap.new()
	_minimap.anchor_left = 1.0
	_minimap.anchor_right = 1.0
	_minimap.visibility_changed.connect(_refresh_location)
	add_child(_minimap)
	_place_minimap()





func _place_minimap() -> void :
	var d: = MINIMAP_D
	_minimap.set_diameter(d)
	_minimap.offset_right = - LOC_RIGHT
	_minimap.offset_left = - LOC_RIGHT - d
	_minimap.offset_top = LOC_TOP
	_minimap.offset_bottom = LOC_TOP + d



func _build_location() -> void :
	_loc_panel = ZonePill.new()
	_loc_panel.name = "location_pill"
	_loc_panel.visible = false

	_loc_panel.anchor_left = 1.0
	_loc_panel.anchor_right = 1.0
	add_child(_loc_panel)

	_loc_label = _loc_panel.name_label
	_clock = _loc_panel.clock_label
	var clock: = get_node_or_null("/root/Clock")
	if clock != null:
		clock.minute_changed.connect(_on_clock_changed)
		clock.period_changed.connect(_on_clock_changed)
	Controls.on_device_changed(_on_device_changed)



func _on_clock_changed(_name: = "") -> void :
	_refresh_location()



func _refresh_clock() -> void :
	if _clock == null:
		return
	var clock: = get_node_or_null("/root/Clock")
	if clock == null:
		return
	var k: = Controls.ui_scale() if Controls.is_touch() else 1.0
	_clock.add_theme_font_size_override("font_size", maxi(7, int(9.0 * k)))
	_clock.text = Clock.format(Clock.minutes)



func _build_hint() -> void :
	_hint = HintBar.new()
	_hint.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_hint.anchor_left = 0.0
	_hint.anchor_right = 0.0
	_hint.anchor_top = 1.0
	_hint.anchor_bottom = 1.0
	_hint.visible = false
	add_child(_hint)
	_refresh_hint()


func _exit_tree() -> void :
	Controls.off_device_changed(_on_device_changed)


func _on_device_changed(_device: String) -> void :
	_refresh_location()
	_refresh_hint()
	_refresh_orbs()
	_refresh_dialog()








func set_overworld_hud_visible(on: bool) -> void :
	if on == not _ow_hud_hidden:
		return
	_ow_hud_hidden = not on
	if _minimap != null:
		_minimap.suppressed = not on
	if not on:
		if party_orbs != null:
			party_orbs.suppressed = true
		for c in [party_ring, _hint, _loc_panel, _prompt, _msg]:
			if c == null:
				continue
			_ow_hidden[c] = c.visible
			c.visible = false
		return
	if party_orbs != null:


		party_orbs.suppressed = false
		party_orbs.visible = not Battle.in_battle
	for c in _ow_hidden.keys():
		if is_instance_valid(c):
			c.visible = bool(_ow_hidden[c])
	_ow_hidden.clear()
	_refresh_location()
	_refresh_hint()




func _refresh_orbs() -> void :
	if party_orbs == null:
		return


	var top: = PartyOrbs.TOP
	if _minimap != null and _minimap.visible:
		top = maxf(top, _minimap.offset_bottom + ORB_GAP)
	if _loc_panel != null and _loc_panel.visible:
		top = maxf(top, _loc_panel.offset_bottom + ORB_GAP)
	var bottom: = 0.0
	if Controls.is_touch():
		var t: = get_node_or_null("/root/Touch")
		if t != null and t.has_method("menu_rect"):

			bottom = t.menu_rect().position.y - 8.0
	party_orbs.set_top(top, bottom)
	var sz: Vector2 = party_orbs.panel_size()
	party_orbs.offset_right = -14.0
	party_orbs.offset_left = -14.0 - sz.x
	party_orbs.offset_top = top
	party_orbs.offset_bottom = top + sz.y




func _hud_corners_process() -> void :
	var picnicking: = get_tree().get_first_node_in_group("picnic") != null
	if picnicking != _in_picnic:
		_in_picnic = picnicking
		_refresh_hint()
	if not _zone_ready:
		var s: = get_tree().get_first_node_in_group("zone_streamer")
		if s != null:
			_zone_ready = true
			_streamer = s
			s.zone_changed.connect(_on_zone_changed)
			var id: = String(s.active)
			if id != "":
				_on_zone_changed(id, s.active_name())
		else:
			var indoor_name: = _interior_location()
			if indoor_name != _loc_zone:
				_loc_zone = indoor_name
				_refresh_location()
	if Battle.in_battle != _in_battle:
		_in_battle = Battle.in_battle
		_refresh_location()
		_refresh_hint()




func _interior_location() -> String:
	var scene: = get_tree().current_scene
	if scene == null:
		return ""
	var player: = Game.get_player()
	if player != null and scene.has_method("room_at"):
		var room_name: String = scene.room_at(player.global_position)
		if room_name != "":
			var room: = scene.get_node_or_null(NodePath(room_name))
			if room != null:
				return String(room.get_meta("location_name", ""))
	return String(scene.get_meta("location_name", ""))


func _on_zone_changed(_zone_id: String, zone_name: String) -> void :
	_loc_zone = zone_name
	_refresh_location()



func _refresh_location() -> void :
	if _loc_panel == null:
		return
	var map_up: = _minimap != null and _minimap.visible
	if _minimap != null:
		_place_minimap()
	var show: = _loc_zone != "" and not Battle.in_battle and not _ow_hud_hidden
	_loc_panel.visible = show
	if not show:
		_refresh_orbs()
		return
	_loc_label.text = _loc_zone.to_upper()
	_refresh_clock()
	var k: = Controls.ui_scale() if Controls.is_touch() else 1.0
	_loc_label.add_theme_font_size_override("font_size", int(22.0 * k))


	var right: = LOC_RIGHT
	if map_up:
		right = - _minimap.offset_left + ORB_GAP
	var m: = _loc_panel.get_combined_minimum_size()
	_loc_panel.offset_right = - right
	_loc_panel.offset_left = - right - m.x
	_loc_panel.offset_top = LOC_TOP
	_loc_panel.offset_bottom = LOC_TOP + m.y
	_refresh_orbs()



func _refresh_hint() -> void :
	if _hint == null:
		return
	var show: = not Controls.is_touch() and not Battle.in_battle and not Debug.recording and not _ow_hud_hidden\
	and get_tree().get_first_node_in_group("picnic") == null
	_hint.visible = show
	if not show:
		return
	var run: = Controls.key_label("run")
	if Controls.is_pad():
		run = "Hold " + run
	if Game.daily_build:
		_hint.set_hints([["pk_pause", "Options"], [run, "Run"]])
	elif Game.menu_open and not Battle.in_battle:

		_hint.set_hints([[["pk_up", "pk_down"], "Move"], ["pk_ok", "Confirm"], ["pk_back", "Back"]])
	elif _piloting:
		var hints: Array = [["pk_pause", "Menu"], ["pilot", "Back to trainer"]]
		var pl: = Game.get_player()
		if pl != null and pl.pilot != null and MountRig.can_ride(String(pl.pilot.species)):
			hints.append(["ride", "Ride"])
		_hint.set_hints(hints)
	elif _riding:

		_hint.set_hints([["pk_pause", "Menu"], ["ride", "Stop Riding"]])
	else:
		_hint.set_hints([["pk_pause", "Menu"], [run, "Run"], ["party_ring", "Pokémon", "ball"]])
	var m: Vector2 = _hint.get_combined_minimum_size()
	_hint.offset_left = HINT_INSET
	_hint.offset_right = HINT_INSET + m.x
	_hint.offset_bottom = - HINT_INSET
	_hint.offset_top = - HINT_INSET - m.y


func _build_dialog() -> void :


	_dlg = PkDialogBox.new()
	_dlg.set_anchors_and_offsets_preset(Control.PRESET_CENTER_BOTTOM)
	_dlg.offset_left = -400
	_dlg.offset_right = 400
	_dlg.offset_top = -175
	_dlg.offset_bottom = -24
	add_child(_dlg)
	_dlg.finished.connect( func(): dialog_closed.emit())
	_refresh_dialog()







func _refresh_dialog() -> void :
	if _dlg == null:
		return
	var left: = -400.0
	var right: = 400.0
	if Controls.is_touch():
		var t: = get_node_or_null("/root/Touch")
		if t != null and t.has_method("b_rect"):
			const GAP: = 16.0
			const MARGIN: = 24.0
			var vw: = get_viewport().get_visible_rect().size.x
			var max_right: float = t.b_rect().position.x - GAP
			if vw * 0.5 + right > max_right:
				var w: = minf(800.0, maxf(200.0, max_right - MARGIN))
				right = max_right - vw * 0.5
				left = maxf(MARGIN - vw * 0.5, right - w)
				right = left + w
	_dlg.offset_left = left
	_dlg.offset_right = right
	_dlg.offset_top = -175.0
	_dlg.offset_bottom = -24.0


func open_dialog(speaker: String, lines: PackedStringArray, face: = "") -> void :
	_dlg.say(speaker, Array(Dialogue.fill_lines(lines)), face)


func is_dialog_open() -> bool:
	return _dlg.visible



func is_choice_open() -> bool:
	return _dlg != null and _dlg.is_choice_open()



func choice_tap(gp: Vector2) -> bool:
	return _dlg != null and _dlg.choice_tap(gp)



func dialog_rect() -> Rect2:
	if _dlg == null or not _dlg.visible:
		return Rect2()
	return _dlg.get_global_rect()



func ask_yes_no(speaker: String, question: String) -> bool:
	return await _dlg.ask_yes_no(speaker, Dialogue.fill_text(question))




func ask_choice(speaker: String, question: String, items: Array) -> String:
	return await _dlg.ask_choice(speaker, Dialogue.fill_text(question), items)




func _summary_process() -> void :
	if _summary == null:
		_summary = SummaryPanel.new()
		add_child(_summary)
	var p = Game.get_player()
	if _summary.visible:
		if _summary.respec_open():
			pass
		elif _act("pk_back"):
			if _summary.back():
				pass
			else:
				_summary.visible = false
				Audio.ui("sfx/ui/menu_close")
				Game.menu_open = false
				if p:
					p.controls_enabled = true
		else:
			if _act("pk_prev"):
				_summary.step(-1)
			elif _act("pk_next"):
				_summary.step(1)
	elif Debug.summary and not Game.is_busy() and not Game.party.is_empty():
		Debug.summary = false
		open_summary()




func open_summary(start: = 0, read_only: = false) -> bool:
	if Game.party.is_empty() or (Game.is_busy() and not read_only):
		return false
	if start >= 0 and start < Game.party.size() and Game.party[start].egg:
		return false
	if _summary == null:
		_summary = SummaryPanel.new()
		add_child(_summary)
	_summary.open(start, read_only)
	Audio.ui("sfx/ui/menu_open")
	Game.menu_open = true
	var p = Game.get_player()
	if p:
		p.controls_enabled = false
	return true




func summary_panel() -> PanelContainer:
	if _summary == null:
		_summary = SummaryPanel.new()
		add_child(_summary)
	return _summary



func summary_visible() -> bool:
	return _summary != null and _summary.visible


var _bag: Control
var _bag_armed: = -1
var _pokedex: Control
var _party: Control
var _party_picking: = false
var _shop: Control
var _pc: Control
var _club: Control



func _act(action: StringName) -> bool:
	return Input.is_action_just_pressed(action)


func _bag_process() -> void :
	if _bag == null:
		_bag = BagPanel.new()
		add_child(_bag)
		_bag.give_done.connect(_on_bag_give_done)
	var p = Game.get_player()
	if _party_picking:
		return

	if _bag.visible and not _bag.modal() and Engine.get_process_frames() != _bag_armed:
		var close: = false
		if _act("pk_back"):
			close = not _bag.back()
		if Debug.bag_use != "":
			var id: String = Debug.bag_use
			Debug.bag_use = ""
			var r: Dictionary = Progression.use_item(id, 0)
			print("[bag] use %s -> %s" % [id, r.text])
			_bag.refresh()
		if _act("pk_ok"):
			_bag.confirm()
		for k in 4:
			if _act("move_%d" % (k + 1)):
				_bag.assign_slot(k)
		if _act("pk_alt"):
			_bag.toss()
		if close:
			_bag.visible = false
			Audio.ui("sfx/ui/menu_close")
			Game.menu_open = false
			if p:
				p.controls_enabled = true
		if _act("pk_left"):
			_bag.step_pocket(-1)
		if _act("pk_right"):
			_bag.step_pocket(1)
		if _act("pk_up"):
			_bag.step_item(-1)
		if _act("pk_down"):
			_bag.step_item(1)
	elif Debug.bag and not Game.is_busy() and Game._evolving.is_empty():
		Debug.bag = false
		open_bag()



func open_shop(shop_id: String) -> void :
	if _shop == null:
		_shop = ShopPanel.new()
		add_child(_shop)


	if _dlg.visible:
		_dlg.close()
	_shop.open(shop_id)



func open_party() -> bool:
	if Game.is_busy() or Game.party.is_empty() or not Game._evolving.is_empty():
		return false
	_ensure_party().open()
	return true



func open_bag_give(i: int) -> bool:
	if not open_bag():
		return false
	_bag.open_give(i)
	return true


func _on_bag_give_done(result: Dictionary) -> void :
	_bag_armed = Engine.get_process_frames()
	_ensure_party().open()
	_party._show_actions()
	if String(result.get("text", "")) != "":
		_party._note.text = String(result.text)



func open_party_pick(item_id: String, held: = false) -> bool:
	if not _ensure_party().open_pick(item_id, held):
		return false
	_party_picking = true
	if _bag:
		_bag.visible = false
	return true



func _on_party_pick_done(result: Dictionary) -> void :
	_party_picking = false
	if bool(result.get("close_menu", false)):
		close_menus()
		return
	if _bag:
		_bag.visible = true
		_bag.on_use_result(result)
	Game.menu_open = true
	var p: = Game.get_player()
	if p:
		p.controls_enabled = false




func close_menus() -> void :
	_party_picking = false
	if _bag:
		_bag.visible = false
	if _party and _party.visible:
		_party.close()
	Game.menu_open = false
	var p: = Game.get_player()
	if p and not Game.cutscene:
		p.controls_enabled = true



func _ensure_party() -> Control:
	if _party == null:
		_party = PartyPanel.new()
		add_child(_party)
		_party.pick_done.connect(_on_party_pick_done)
	return _party



func open_pc() -> bool:
	if _pc == null:
		_pc = PcPanel.new()
		add_child(_pc)
	_pc.open()
	return true



func open_cable_club() -> void :
	if _club == null:
		_club = CableClubPanel.new()
		add_child(_club)
	await _club.open()



func open_bag() -> bool:
	if Game.is_busy() or not Game._evolving.is_empty():
		return false
	if _bag == null:
		_bag = BagPanel.new()
		add_child(_bag)
		_bag.give_done.connect(_on_bag_give_done)
	_bag.open()
	_bag_armed = Engine.get_process_frames()
	Audio.ui("sfx/ui/menu_open")
	Game.menu_open = true
	var p = Game.get_player()
	if p:
		p.controls_enabled = false
	return true



func open_pokedex() -> bool:
	if Game.is_busy() or not Game._evolving.is_empty():
		return false
	if _pokedex == null:
		_pokedex = PokedexPanel.new()
		add_child(_pokedex)
	_pokedex.open()
	return true



func sub_panel(id: String) -> Control:
	match id:
		"pokedex": return _pokedex
		"pokemon": return _party
		"bag": return _bag
		"club": return _club
	return null



func show_saving() -> void :
	show_toast("● Saving…", 1.0)




func show_toast(text: String, secs: = 1.8) -> void :
	if _saving == null:
		_saving = Label.new()
		_saving.theme = UiKit.theme()
		_saving.theme_type_variation = "SmallLabel"
		_saving.add_theme_color_override("font_color", UiKit.PAPER)
		_saving.add_theme_color_override("font_outline_color", UiKit.INK)
		_saving.add_theme_constant_override("outline_size", 6)
		_saving.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_RIGHT)
		_saving.offset_left = -170
		_saving.offset_right = 0

		_saving.offset_bottom = -8.0
		_saving.offset_top = _saving.offset_bottom - 32.0
		add_child(_saving)
	_saving.move_to_front()
	_saving.text = text
	_saving.modulate.a = 1.0
	if _saving_tw != null and _saving_tw.is_valid():
		_saving_tw.kill()
	_saving_tw = _saving.create_tween()
	_saving_tw.tween_interval(secs)
	_saving_tw.tween_property(_saving, "modulate:a", 0.0, 0.4)




func show_notice(title: String, detail: String, species: String, seconds: = 2.6) -> void :
	if _notice == null:
		_notice = preload("res://scripts/ui/notice_card.gd").new()
		add_child(_notice)
	_notice.show_notice(title, detail, species, seconds)




func show_interact_prompt(target: Node3D) -> void :
	if target == null or not is_instance_valid(target):
		return
	_prompt_target = target
	if _prompt == null:
		_prompt = HintBar.new()
		_prompt.mouse_filter = Control.MOUSE_FILTER_IGNORE
		add_child(_prompt)
		_prompt.visible = false
	var verb: = String(target.prompt_verb()) if target.has_method("prompt_verb") else ""



	var ride: = ""
	if target.is_in_group("companion") and MountRig.can_ride(String(target.species)):
		ride = "1"
	var pilot: = target.is_in_group("companion")

	var inspect: String = "1"\
	if (target.is_in_group("wild") or target.is_in_group("cornered") or target.is_in_group("wounded") or target.is_in_group("friend")) and BreederLevel.inspect_visible(Game.state.breeder_level()) and verb != "" else ""
	if verb != _prompt_verb or inspect != _prompt_inspect or ride != _prompt_ride or pilot != _prompt_pilot:
		_prompt_verb = verb
		_prompt_inspect = inspect
		_prompt_ride = ride
		_prompt_pilot = pilot
		var hints: Array = [["interact", verb]]
		if ride != "":
			hints.append(["ride", "Ride"])
		if pilot:
			hints.append(["pilot", "Control"])
		if inspect != "":
			hints.append(["inspect", "Inspect"])
		_prompt.set_hints(hints)
		_prompt.size = _prompt.get_combined_minimum_size()
		_prompt.pivot_offset = _prompt.size * 0.5
	if not _prompt_shown:
		_prompt_shown = true
		_prompt.visible = true
		_prompt.scale = Vector2(0.9, 0.9)
		_prompt.modulate.a = 0.0
		if _prompt_tw:
			_prompt_tw.kill()
		_prompt_tw = create_tween().set_parallel().set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
		_prompt_tw.tween_property(_prompt, "scale", Vector2.ONE, 0.14)
		_prompt_tw.tween_property(_prompt, "modulate:a", 1.0, 0.14)
	_update_interact_prompt()



func hide_interact_prompt() -> void :
	_prompt_target = null
	_prompt_inspect = ""
	if _prompt == null or not _prompt_shown:
		return
	_prompt_shown = false
	if _prompt_tw:
		_prompt_tw.kill()
	_prompt_tw = create_tween()
	_prompt_tw.tween_property(_prompt, "modulate:a", 0.0, 0.1)
	_prompt_tw.tween_callback( func():
		if not _prompt_shown and _prompt:
			_prompt.visible = false)



func interact_prompt_rect() -> Rect2:
	if _prompt == null or not _prompt_shown or not _prompt.visible:
		return Rect2()
	return Rect2(_prompt.position, _prompt.size).grow(8.0)



func interact_available() -> bool:
	return _prompt != null and _prompt_shown and _prompt.visible



func interact_verb() -> String:
	return _prompt_verb



func inspect_available() -> bool:
	return _prompt_inspect != "" and _prompt != null and _prompt_shown




func ride_available() -> bool:
	return _prompt_ride != "" and _prompt != null and _prompt_shown and not _riding and not _piloting


func pilot_available() -> bool:
	return _prompt_pilot and _prompt != null and _prompt_shown and not _riding and not _piloting




func _update_interact_prompt() -> void :
	if _prompt == null or not _prompt_shown:
		return
	if not is_instance_valid(_prompt_target):
		hide_interact_prompt()
		return
	var cam: = get_viewport().get_camera_3d()
	if cam == null:
		return
	var anchor: Vector3 = _prompt_target.global_position + Vector3(0, 2.0, 0)
	if _prompt_target.has_method("prompt_anchor"):
		anchor = _prompt_target.prompt_anchor()
	if cam.is_position_behind(anchor):
		_prompt.visible = false
		return
	_prompt.visible = not _ow_hud_hidden
	var screen: = cam.unproject_position(anchor)
	var sz: = _prompt.size
	var vp: = get_viewport().get_visible_rect().size
	var pos: = Vector2(screen.x - sz.x * 0.5, screen.y - sz.y - PROMPT_LIFT)
	pos.x = clampf(pos.x, 8.0, maxf(8.0, vp.x - sz.x - 8.0))
	pos.y = clampf(pos.y, 8.0, maxf(8.0, vp.y - sz.y - 8.0))
	_prompt.position = pos





func show_message(text: String, secs: = 2.5, kind: = "info") -> void :
	if battle_log.active():
		battle_log.push(text, kind)
		return
	_msg.text = text
	_msg_t = secs


func _party_ring_process() -> void :
	if Battle.is_spar():
		return
	var lan = get_node_or_null("/root/LanCampaign")
	if Battle.challenge and not BattleTower.is_rental(BattleTower.current) and not (lan != null and lan.coop_battle_active()):
		return


	var can_open: = not Game.is_busy()\
	or (Battle.in_battle and not Battle._intro and not Battle._ending and not Battle._switching)
	if not party_ring.is_open and Input.is_action_just_pressed("party_ring") and can_open:
		party_ring.open("battle" if Battle.in_battle else "overworld", 
			Battle.in_battle and Battle.allies.size() >= 2 and not (lan != null and lan.coop_battle_active()))


func _on_party_ring_picked(slot: int) -> void :



	var to_ally: bool = party_ring.target == 1
	if party_ring.pick_mode:
		Game._party_key(slot, false)
		return
	party_ring.close()
	Game._party_key(slot, to_ally)


func _on_party_ring_held(slot: int) -> void :
	Game._party_key(slot, true)
	if not party_ring.pick_mode:
		party_ring.close()


func _process(delta: float) -> void :

	var night: = Game.night_prologue_active()
	if night != _night_hidden:
		_night_hidden = night
		set_overworld_hud_visible( not night)

	SafariGame.tick(delta)
	var safari_txt: String = SafariGame.hud_text()
	if safari_txt != _safari_txt and _loc_panel != null:
		_safari_txt = safari_txt
		_loc_panel.safari_label.text = safari_txt
		_loc_panel.safari_label.visible = safari_txt != ""
		_refresh_location()
	if _msg_t > 0.0:
		_msg_t -= delta
		if _msg_t <= 0.0:
			_msg.text = ""
	_summary_process()
	_bag_process()
	_party_ring_process()
	_hud_corners_process()
	var pl: = Game.get_player()
	var riding: bool = pl != null and pl.get("mount") != null
	var piloting: bool = pl != null and pl.get("pilot") != null
	if riding != _riding or piloting != _piloting:
		_riding = riding
		_piloting = piloting
		_refresh_hint()
	var menu_hint: bool = Game.menu_open and not Battle.in_battle
	if menu_hint != _menu_hint:
		_menu_hint = menu_hint
		_refresh_hint()
	var map_up: = _minimap != null and _minimap.visible
	_minimap.meals = -1 if Game.daily_build else Game.state.meal_charges()
	meal_chip.visible = _loc_panel.visible and not map_up and Game.get_player() != null and not Game.daily_build
	meal_chip.refresh()
	var meal_layout: = Vector3(meal_chip.position.y, meal_chip.size.y, 1.0 if meal_chip.visible else 0.0)
	if meal_layout != _meal_layout:
		_meal_layout = meal_layout
		_refresh_location()
	_update_interact_prompt()

	_status.text = ""
	_ball.text = ""
	var lift: = Battle.in_battle
	_msg.offset_top = -232.0 if lift else -90.0
	_msg.offset_bottom = -172.0 if lift else -30.0
